#pragma once
#include <Arduino.h>

// Self-contained: the controller needs no CDN, NAS or internet to show this UI.
const char WEB_UI[] PROGMEM = R"HTML(<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>培养箱光照控制</title><style>
:root{font-family:system-ui,"Microsoft YaHei",sans-serif;color:#18352b;background:#edf3ef;color-scheme:light}
*{box-sizing:border-box}body{margin:0}main{max-width:980px;margin:auto;padding:24px 16px 48px}
h1{font-size:26px;margin:0 0 6px}h2{font-size:19px;margin:0 0 14px}p{line-height:1.6;margin:10px 0}
.muted{color:#52675e;font-size:14px}.banner{padding:12px 16px;border-radius:10px;background:#fff0cb;margin:16px 0;line-height:1.6}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.card{background:#fff;border:1px solid #d4e0d8;border-radius:14px;padding:20px;margin-top:16px}
.stats{display:flex;gap:26px;flex-wrap:wrap}.value{display:block;font-size:28px;font-weight:650;line-height:1.5}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0}.badge{padding:5px 10px;border-radius:20px;background:#e6eee8;font-size:14px}.on{background:#d5f1d9;color:#245c2d}
label{display:block;font-size:14px;margin:12px 0 6px}input,select{font:inherit;padding:10px;border:1px solid #a5b8ad;border-radius:7px;max-width:100%;width:100%;background:#fff;color:inherit}
button{font:inherit;border:0;padding:10px 16px;border-radius:7px;background:#245b43;color:white;cursor:pointer;min-height:42px}
button.secondary{background:#e5eee8;color:#244d39}button.stop{background:#a93a31}button:disabled{opacity:.45;cursor:default}
.fields{display:grid;grid-template-columns:1fr 1fr;gap:12px}.fields label{margin-top:0}
[hidden]{display:none!important}#message{padding:12px 16px;border-radius:8px;background:#daeede;min-height:44px;line-height:1.5;overflow-wrap:anywhere;margin-top:16px}
#message.error{background:#fce2dd;color:#843328}details summary{cursor:pointer;font-size:18px;font-weight:600}
a{color:#245b43;overflow-wrap:anywhere}code{font-family:ui-monospace,monospace}.footer{margin-top:24px}
@media(max-width:650px){.grid{grid-template-columns:1fr}main{padding-top:18px}.card{padding:16px}.value{font-size:24px}}
</style></head><body><main>
<h1>培养箱光照控制</h1><div class="muted">两组光源 · 本地执行 · 北京时间（UTC+8）</div>
<div class="banner" id="notice">正在读取设备状态…</div>
<section class="card"><div class="stats">
<div><span class="muted">当前时间</span><span class="value" id="clock">--</span><span class="muted" id="clockSource">等待同步</span></div>
<div><span class="muted">温度</span><span class="value" id="temperature">--</span></div>
<div><span class="muted">湿度</span><span class="value" id="humidity">--</span></div>
</div><p class="muted" id="network">正在连接设备…</p>
<div class="row"><button data-command="arm" id="arm" disabled>解锁运行</button>
<button data-command="disarm" class="stop" disabled>关闭并锁定</button>
<button data-command="off all" class="secondary" disabled>两路改为手动关闭</button></div>
<p class="muted">“关闭并锁定”保留模式和参数。解锁会重新起算循环；已到每日开灯时段的光源会开始运行。</p>
<button id="browserClock" class="secondary" disabled>使用手机 / 电脑时间校时</button>
<p class="muted">无网络校时可用时，按此按钮按当前设备的真实时间设置北京时间；联网后自动校时会更新它。</p>
</section>
<div id="message" role="status" aria-live="polite">等待状态读取。</div>
<div class="grid" id="lights"></div>
<section class="card"><details id="wifiDetails"><summary>连接家中 Wi-Fi</summary>
<p class="muted">填写 2.4GHz 的网络名称和密码。先关闭并锁定光源，再保存。配置热点关闭后，手机切回家中 Wi-Fi，使用下方局域网地址访问。</p>
<form id="wifiForm"><label for="ssid">网络名称（SSID）</label><input id="ssid" maxlength="32" autocomplete="off" required>
<label for="password">Wi-Fi 密码</label><input id="password" type="password" minlength="8" maxlength="63" autocomplete="new-password" required>
<div class="row"><button type="submit" id="saveWifi" disabled>保存并连接</button><label style="margin:0"><input type="checkbox" id="showPassword" style="width:auto"> 显示密码</label></div></form>
<p id="lanAddress" class="muted">尚未取得局域网地址。</p>
</details></section>
<p class="muted footer">每次重新上电保持锁定。当前为 Wi-Fi 调试版，蓝牙、智能家居和 NAS 数据记录将在后续加入。开关状态是控制器的输出命令，尚未加入灯带反馈检测。</p>
</main><script>
'use strict';
let csrf='',state=null,polling=false,busy=false,connected=false,readFailed=false;
const $=id=>document.getElementById(id);
const modeLabels={MANUAL:'手动',DAILY:'每日定时',CYCLE:'循环'};
function message(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);}
function card(ch){return `<section class="card"><div class="row"><h2 style="margin:0">光源 ${ch}</h2><span class="badge" id="output${ch}">--</span><span class="muted" id="current${ch}">--</span></div>
<p class="muted" id="detail${ch}">等待读取参数。</p><div class="row"><button data-command="on ${ch}" class="manual-on" disabled>手动开灯</button><button data-command="off ${ch}" class="secondary" disabled>手动关灯</button></div>
<form id="form${ch}" data-channel="${ch}"><label for="mode${ch}">运行模式</label><select id="mode${ch}"><option value="MANUAL">手动</option><option value="DAILY">每日定时</option><option value="CYCLE">循环开关</option></select>
<div id="daily${ch}" class="fields" hidden><div><label for="onTime${ch}">每日开灯</label><input id="onTime${ch}" type="time" value="08:00" step="60" required></div><div><label for="offTime${ch}">每日关灯</label><input id="offTime${ch}" type="time" value="20:00" step="60" required></div></div>
<div id="cycle${ch}" class="fields" hidden><div><label for="onSec${ch}">开灯时长（秒）</label><input id="onSec${ch}" type="number" min="1" max="604800" step="1" value="60" required></div><div><label for="offSec${ch}">关灯时长（秒）</label><input id="offSec${ch}" type="number" min="1" max="604800" step="1" value="60" required></div></div>
<div class="row"><button type="submit" disabled>应用并保存参数</button><span id="edited${ch}" class="muted"></span></div></form></section>`;}
$('lights').innerHTML=card(1)+card(2);
const dirty=[false,false];
function showFields(ch){const m=$('mode'+ch).value;$('daily'+ch).hidden=m!=='DAILY';$('cycle'+ch).hidden=m!=='CYCLE';
 $('daily'+ch).querySelectorAll('input').forEach(i=>i.disabled=m!=='DAILY');$('cycle'+ch).querySelectorAll('input').forEach(i=>i.disabled=m!=='CYCLE');}
for(let ch=1;ch<=2;ch++){$('form'+ch).addEventListener('input',()=>{dirty[ch-1]=true;$('edited'+ch).textContent='有未应用的修改';showFields(ch);});
 $('form'+ch).addEventListener('submit',async e=>{e.preventDefault();const m=$('mode'+ch).value;let cmd;
 if(m==='DAILY'){const a=$('onTime'+ch).value,b=$('offTime'+ch).value;if(a===b){message('每日开灯和关灯时刻必须不同。',true);return;}cmd=`daily ${ch} ${a} ${b}`;}
 else if(m==='CYCLE'){const a=Number($('onSec'+ch).value),b=Number($('offSec'+ch).value);if(!Number.isInteger(a)||!Number.isInteger(b)||a<1||b<1||a>604800||b>604800){message('每段循环时长请输入 1～604800 的整数秒。',true);return;}cmd=`cycle ${ch} ${a} ${b}`;}
 else cmd=`off ${ch}`;
 const ok=await command(cmd);if(ok){dirty[ch-1]=false;$('edited'+ch).textContent='';await refresh();}});showFields(ch);}
function setButtons(){document.querySelectorAll('button').forEach(b=>b.disabled=!connected||busy);
 $('arm').disabled=!connected||busy||!state?.logicPassed||!!state?.armed;
 document.querySelectorAll('.manual-on').forEach(b=>b.disabled=!connected||busy||!state?.armed);
 $('saveWifi').disabled=!connected||busy||!!state?.armed;}
async function fetchJson(path,options={}){const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...options});
 if(r.status===401)throw Error('登录失效，请刷新网页，用户名 admin，密码见串口 wifi info。');
 const j=await r.json();if(!r.ok||j.ok===false)throw Error(translate(j.message)||`请求失败：${r.status}`);return j;}
function translate(t){const messages={'OK ARMED':'已解锁，开始按当前模式运行。','OK LOCKED; settings kept':'已关闭并锁定；模式和参数保留。','OK all OFF MANUAL':'两路已切换为手动并关闭。','OK MANUAL':'已切换为手动，开关命令已执行。','OK settings applied and saved':'参数已应用并保存。','OK clock set UTC+8':'已按手机 / 电脑时间设置北京时间。','ERR locked: use arm after checking wiring':'设备处于锁定状态，请先解锁。','ERR single-channel limit: stop the other channel first':'目前最多开启一组，请先关闭另一组或停用它的自动模式。','OK WiFi saved; connecting shortly':'Wi-Fi 已保存，正在连接。请留在此页等待出现局域网地址。','ERR lock before changing WiFi':'请先点击“关闭并锁定”，再修改 Wi-Fi。'};return messages[t]||t;}
async function post(path,fields){if(!csrf||!connected||busy)return false;busy=true;setButtons();try{const j=await fetchJson(path,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF-Token':csrf},body:new URLSearchParams(fields)});message(translate(j.message));return true;}catch(e){message(e.message,true);return false;}finally{busy=false;setButtons();}}
async function command(cmd){const ok=await post('/api/command',{cmd});await refresh();return ok;}
document.querySelectorAll('[data-command]').forEach(b=>b.addEventListener('click',()=>command(b.dataset.command)));
$('showPassword').addEventListener('change',e=>$('password').type=e.target.checked?'text':'password');
$('wifiForm').addEventListener('submit',async e=>{e.preventDefault();const ssid=$('ssid').value,password=$('password').value;
 if(new TextEncoder().encode(ssid).length>32){message('网络名称不能超过 32 字节（中文会占多个字节）。',true);return;}
 if(new TextEncoder().encode(password).length<8||new TextEncoder().encode(password).length>63){message('Wi-Fi 密码需为 8～63 字节。',true);return;}
 if(await post('/api/wifi',{ssid,password})){$('password').value='';await refresh();}});
$('browserClock').addEventListener('click',()=>{const p=n=>String(n).padStart(2,'0');const t=new Date(Date.now()+8*3600*1000);
 command(`clock ${t.getUTCFullYear()}-${p(t.getUTCMonth()+1)}-${p(t.getUTCDate())} ${p(t.getUTCHours())}:${p(t.getUTCMinutes())}:${p(t.getUTCSeconds())}`);});
function render(s){state=s;csrf=s.csrf;connected=s.snapshotAgeMs<2000;const clockNames={UNSYNC:'尚未校时',MANUAL:'手机 / 电脑 / 串口设时',NTP:'网络自动校时'};
 $('clock').textContent=s.clock||'尚未校时';$('clockSource').textContent=clockNames[s.clockSource]||'尚未校时';
 $('temperature').textContent=s.sensorValid?`${s.temperature.toFixed(1)} °C`:'暂无有效读数';$('humidity').textContent=s.sensorValid?`${s.humidity.toFixed(1)} %`:'暂无有效读数';
 $('notice').textContent=!connected?'状态刷新延迟，请等待或刷新网页。':!s.logicPassed?'灯控逻辑自检未通过，保持锁定。':!s.armed?`输出已锁定；解锁前检查模式和参数。目前最多开启 ${s.limit} 组。`:`已解锁运行；目前最多开启 ${s.limit} 组。两路都请求开灯时，受限制的一路将等待。`;
 if(!s.storageReady)$('notice').textContent+=' 参数存储不可用；当前修改可能无法在重启后保留。';
 $('network').textContent=(s.wifi.connected?`Wi-Fi 已连接 · 信号 ${s.wifi.rssi} dBm`:'Wi-Fi 未连接 / 正在重试')+(s.wifi.apActive?` · 配置热点：${s.wifi.apName}`:'')+' · 蓝牙尚未启用';
 const lan=$('lanAddress');lan.replaceChildren();if(s.wifi.connected){lan.append('局域网访问地址：');const a=document.createElement('a');a.href=`http://${s.wifi.ip}/`;a.textContent=a.href;lan.append(a);lan.append('。手机需连接家中 Wi-Fi。');}else lan.textContent='尚未取得局域网地址；请核对 2.4GHz Wi-Fi 名称、密码和信号。';
 if(!s.wifi.configured)$('wifiDetails').open=true;
 for(let i=0;i<2;i++){const ch=i+1,l=s.lights[i],out=$('output'+ch);out.textContent=l.output?'已开灯':'已关灯';out.classList.toggle('on',l.output);$('current'+ch).textContent=modeLabels[l.mode];
 const params=l.mode==='DAILY'?`每天 ${l.dailyOn} 开灯，${l.dailyOff} 关灯` : l.mode==='CYCLE'?`开 ${l.onSeconds} 秒 / 关 ${l.offSeconds} 秒`+(s.armed?`；当前阶段剩余 ${l.remaining} 秒`:''):'手动控制';
 const reason=!s.armed?'（已锁定）':l.mode==='DAILY'&&s.clockSource==='UNSYNC'?'（等待校时）':l.blocked?'（受电源限制，等待另一组释放）':'';$('detail'+ch).textContent=params+reason;
 if(!dirty[i]){$('mode'+ch).value=l.mode;$('onTime'+ch).value=l.dailyOn;$('offTime'+ch).value=l.dailyOff;$('onSec'+ch).value=l.onSeconds;$('offSec'+ch).value=l.offSeconds;showFields(ch);}}
 setButtons();}
async function refresh(){if(polling)return;polling=true;try{const first=!state;render(await fetchJson('/api/state'));if(readFailed)message('设备连接已恢复。');else if(first)message('设备状态已读取。');readFailed=false;}catch(e){readFailed=true;connected=false;$('notice').textContent='无法读取设备状态。检查网络连接，使用串口或设备按键也可控制。';message(e.message,true);setButtons();}finally{polling=false;}}
refresh();setInterval(refresh,1500);
</script></body></html>)HTML";
