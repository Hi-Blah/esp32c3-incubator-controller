// Stage 2: Wi-Fi web control + provisioning + NTP, retaining local schedules.
// Use two SINGLE-channel MOS switch boards, active HIGH, with hardware pulldowns.
// HTTP runs in a separate task. BLE, MQTT, NAS logging and RTC are not enabled.
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <Preferences.h>
#include <esp_timer.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "light_logic.h"
#include "network_service.h"
#include <stdarg.h>

#if !defined(ARDUINO_USB_CDC_ON_BOOT) || !ARDUINO_USB_CDC_ON_BOOT
#error "Enable Tools > USB CDC On Boot: GPIO21 is DHT DAT, not UART0 TX"
#endif

using incubator::Config;
using incubator::Runtime;
using incubator::Mode;

constexpr uint8_t LIGHT_PIN[2] = {4, 7};
constexpr uint8_t BUTTON_PIN[3] = {0, 1, 10};
constexpr uint8_t DHT_PIN = 21; // UART0 TX reused; use USB CDC Serial, not Serial0.
constexpr uint8_t SDA_PIN = 6;
constexpr uint8_t SCL_PIN = 5;
constexpr int OLED_HEIGHT = 64;  // Change to 32 only for a 128x32 OLED.
constexpr uint8_t MAX_ACTIVE_CHANNELS = 1;  // Set to 2 AFTER fixing power capacity.
static_assert(MAX_ACTIVE_CHANNELS >= 1 && MAX_ACTIVE_CHANNELS <= 2, "Invalid limit");
static_assert(OLED_HEIGHT == 32 || OLED_HEIGHT == 64, "Invalid OLED height");
static_assert(SDA_PIN != SCL_PIN && SDA_PIN != DHT_PIN && SCL_PIN != DHT_PIN,
              "Sensor GPIOs must be different");
static_assert(SDA_PIN != LIGHT_PIN[0] && SDA_PIN != LIGHT_PIN[1] &&
              SCL_PIN != LIGHT_PIN[0] && SCL_PIN != LIGHT_PIN[1] &&
              DHT_PIN != LIGHT_PIN[0] && DHT_PIN != LIGHT_PIN[1],
              "Sensor pins must not overlap light-control pins");

Adafruit_SSD1306 oled(128, OLED_HEIGHT, &Wire, -1);
DHT dht(DHT_PIN, DHT11);
Preferences prefs;
Config config[2] = {
  {Mode::Manual, 480, 1200, 60, 60},
  {Mode::Manual, 480, 1200, 60, 60}
};
Runtime runtime[2] = {{false, 0}, {false, 0}};
bool output[2] = {false, false};
bool want[2] = {false, false};
bool armed = false;
bool clockValid = false;
ClockSource clockSource = ClockSource::Unsynced;
bool logicPassed = false;
bool storageReady = false;
bool oledReady = false;
bool sensorValid = false;
float temperature = NAN;
float humidity = NAN;
uint8_t page = 0;
uint32_t lastSensorMs = 0, lastDisplayMs = 0, lastPageMs = 0;

struct Button {
  uint8_t pin;
  bool raw;
  bool stable;
  uint32_t changedMs;
};
Button buttons[3] = {{0, true, true, 0}, {1, true, true, 0}, {10, true, true, 0}};

// A single NVS blob stores settings; manual ON, time and arming are not stored.
struct SavedSettings {
  uint32_t schema;
  uint8_t mode[2];
  uint16_t onMinute[2];
  uint16_t offMinute[2];
  uint32_t onSeconds[2];
  uint32_t offSeconds[2];
};
constexpr uint32_t SETTINGS_SCHEMA = 0xC3060001UL;

void serialFormat(const char *format, ...) {
  if (!Serial) return;
  char text[384]; va_list args;
  va_start(args, format); vsnprintf(text, sizeof(text), format, args); va_end(args);
  Serial.write(reinterpret_cast<const uint8_t *>(text), strlen(text));
}
void serialLine(const char *text) { serialFormat("%s\n", text); }
void serialLine(const String &text) { serialLine(text.c_str()); }

uint64_t monotonicMs() { return static_cast<uint64_t>(esp_timer_get_time()) / 1000ULL; }

const char *modeName(incubator::Mode m) {
  if (m == Mode::Manual) return "MANUAL";
  if (m == Mode::Daily) return "DAILY";
  if (m == Mode::Cycle) return "CYCLE";
  return "INVALID";
}

bool currentTime(struct tm &t) {
  if (!clockValid) return false;
  const time_t epoch = time(nullptr);
  return localtime_r(&epoch, &t) != nullptr && t.tm_year >= 124 && t.tm_year <= 199;
}

bool saveSettings() {
  if (!storageReady) {
    serialLine("WARN NVS unavailable: settings are not saved");
    return false;
  }
  SavedSettings s = {};
  s.schema = SETTINGS_SCHEMA;
  for (uint8_t i = 0; i < 2; ++i) {
    s.mode[i] = static_cast<uint8_t>(config[i].mode);
    s.onMinute[i] = config[i].onMinute;
    s.offMinute[i] = config[i].offMinute;
    s.onSeconds[i] = config[i].onSeconds;
    s.offSeconds[i] = config[i].offSeconds;
  }
  if (prefs.putBytes("settings", &s, sizeof(s)) != sizeof(s)) {
    serialLine("WARN NVS write failed: running settings are not saved");
    return false;
  }
  return true;
}

void loadSettings() {
  storageReady = prefs.begin("incubator", false);
  if (!storageReady || prefs.getBytesLength("settings") != sizeof(SavedSettings)) return;
  SavedSettings s = {};
  if (prefs.getBytes("settings", &s, sizeof(s)) != sizeof(s) ||
      s.schema != SETTINGS_SCHEMA) return;
  Config loaded[2];
  for (uint8_t i = 0; i < 2; ++i) {
    loaded[i] = {static_cast<Mode>(s.mode[i]), s.onMinute[i], s.offMinute[i],
                 s.onSeconds[i], s.offSeconds[i]};
    if (!incubator::valid(loaded[i])) {
      serialLine("WARN invalid stored settings: using defaults");
      return;
    }
  }
  config[0] = loaded[0]; config[1] = loaded[1];
}

void applyOutputs() {
  struct tm t = {};
  const bool timeOk = currentTime(t);
  const uint16_t minute = static_cast<uint16_t>(t.tm_hour * 60 + t.tm_min);
  const uint64_t now = monotonicMs();
  for (uint8_t i = 0; i < 2; ++i)
    want[i] = incubator::requested(config[i], runtime[i], now, timeOk, minute);
  bool next[2];
  incubator::limitedOutputs(want, output, armed && logicPassed,
                            MAX_ACTIVE_CHANNELS, next);
  // Break before make: never enable a new channel while an old blocked one is ON.
  for (uint8_t i = 0; i < 2; ++i)
    if (!next[i]) digitalWrite(LIGHT_PIN[i], LOW);
  for (uint8_t i = 0; i < 2; ++i)
    if (next[i]) digitalWrite(LIGHT_PIN[i], HIGH);
  for (uint8_t i = 0; i < 2; ++i) {
    if (output[i] != next[i])
      serialFormat("EVENT uptime_ms=%llu light=%u command=%s\n",
                    static_cast<unsigned long long>(now), i + 1, next[i] ? "ON" : "OFF");
    output[i] = next[i];
  }
}

bool manualCommand(uint8_t ch, bool on, String &reply) {
  if (on && !armed) { reply = "ERR locked: use arm after checking wiring"; return false; }
  applyOutputs();
  const uint8_t other = 1 - ch;
  if (on && MAX_ACTIVE_CHANNELS == 1 && (output[other] || want[other])) {
    reply = "ERR single-channel limit: stop the other channel first"; return false;
  }
  const bool changed = config[ch].mode != Mode::Manual;
  config[ch].mode = Mode::Manual;
  runtime[ch].manualOn = on;
  applyOutputs();
  const bool saved = !changed || saveSettings();
  reply = saved ? "OK MANUAL" : "OK MANUAL; WARN not saved";
  return true;
}

void printStatus() {
  struct tm t = {};
  char clockText[32] = "UNSYNC";
  if (currentTime(t)) strftime(clockText, sizeof(clockText), "%Y-%m-%d %H:%M:%S", &t);
  serialFormat("STATUS clock=%s timezone=UTC+8 armed=%u limit=%u logic=%s nvs=%u oled=%u\n",
    clockText, armed, MAX_ACTIVE_CHANNELS, logicPassed ? "PASS" : "FAIL", storageReady, oledReady);
  if (sensorValid) serialFormat("ENV temperature=%.1fC humidity=%.1f%%\n", temperature, humidity);
  else serialLine("ENV invalid: no current valid DHT11 reading");
  for (uint8_t i = 0; i < 2; ++i) {
    serialFormat("LIGHT %u output=%s requested=%s mode=%s blocked=%u daily=%02u:%02u-%02u:%02u cycle=%lus/%lus remaining=%lus\n",
      i + 1, output[i] ? "ON" : "OFF", want[i] ? "ON" : "OFF", modeName(config[i].mode),
      want[i] && !output[i], config[i].onMinute / 60, config[i].onMinute % 60,
      config[i].offMinute / 60, config[i].offMinute % 60,
      static_cast<unsigned long>(config[i].onSeconds), static_cast<unsigned long>(config[i].offSeconds),
      static_cast<unsigned long>(incubator::remainingSeconds(config[i], runtime[i], monotonicMs())));
  }
  const NetworkView net = networkView();
  serialFormat("NETWORK WiFi=%s ip=%s AP=%u ap_ip=%s BLE=not_enabled clock_source=%s\n",
    net.connected ? "CONNECTED" : net.apActive ? "AP/CONNECTING" : "CONNECTING",
    net.ip, net.apActive, net.apIp,
    clockSource == ClockSource::Ntp ? "NTP" : clockSource == ClockSource::Manual ? "MANUAL" : "UNSYNC");
}

void printHelp() {
  serialLine("help | status | arm | disarm | test | scan | page");
  serialLine("on 1 | off 1 | on 2 | off 2 | off all");
  serialLine("daily 1 08:00 20:00 | daily 2 20:00 08:00");
  serialLine("cycle 1 5 3  (ON seconds, OFF seconds; range 1..604800)");
  serialLine("clock 2026-10-11 08:00:00  (China local time; not saved)");
  serialLine("wifi info | wifi ap | wifi forget (forget requires LOCKED)");
  serialLine("WiFi credentials are set in the authenticated web page, never in this source.");
  serialLine("Boot is LOCKED. arm restarts cycle phases. off selects MANUAL.");
}

bool unsignedNumber(const char *s, uint32_t maximum, uint32_t &value) {
  if (!s || !*s) return false;
  uint64_t n = 0;
  for (const char *p = s; *p; ++p) {
    if (*p < '0' || *p > '9') return false;
    n = n * 10ULL + static_cast<uint8_t>(*p - '0');
    if (n > maximum) return false;
  }
  value = static_cast<uint32_t>(n);
  return true;
}

bool parseMinute(const char *s, uint16_t &minute) {
  if (!s || strlen(s) != 5 || s[2] != ':') return false;
  if (s[0] < '0' || s[0] > '9' || s[1] < '0' || s[1] > '9' ||
      s[3] < '0' || s[3] > '9' || s[4] < '0' || s[4] > '9') return false;
  const uint16_t h = (s[0] - '0') * 10 + s[1] - '0';
  const uint16_t m = (s[3] - '0') * 10 + s[4] - '0';
  if (h > 23 || m > 59) return false;
  minute = h * 60 + m;
  return true;
}

bool setClock(const char *date, const char *clock) {
  if (!date || !clock || strlen(date) != 10 || strlen(clock) != 8 ||
      date[4] != '-' || date[7] != '-' || clock[2] != ':' || clock[5] != ':') return false;
  for (uint8_t i = 0; i < 10; ++i)
    if (i != 4 && i != 7 && (date[i] < '0' || date[i] > '9')) return false;
  for (uint8_t i = 0; i < 8; ++i)
    if (i != 2 && i != 5 && (clock[i] < '0' || clock[i] > '9')) return false;
  int year, month, day, hour, minute, second;
  if (sscanf(date, "%d-%d-%d", &year, &month, &day) != 3 ||
      sscanf(clock, "%d:%d:%d", &hour, &minute, &second) != 3) return false;
  if (year < 2024 || year > 2099 || month < 1 || month > 12 || day < 1 || day > 31 ||
      hour > 23 || minute > 59 || second > 59) return false;
  struct tm t = {};
  t.tm_year = year - 1900; t.tm_mon = month - 1; t.tm_mday = day;
  t.tm_hour = hour; t.tm_min = minute; t.tm_sec = second; t.tm_isdst = 0;
  const time_t epoch = mktime(&t);
  struct tm check = {};
  if (epoch == static_cast<time_t>(-1) || !localtime_r(&epoch, &check) ||
      check.tm_year != year - 1900 || check.tm_mon != month - 1 || check.tm_mday != day ||
      check.tm_hour != hour || check.tm_min != minute || check.tm_sec != second) return false;
  struct timeval tv = {};
  tv.tv_sec = epoch;
  if (settimeofday(&tv, nullptr) != 0) return false;
  clockValid = true;
  clockSource = ClockSource::Manual;
  return true;
}

void scanI2C() {
  if (armed) { serialLine("ERR disarm before scan"); return; }
  uint8_t found = 0;
  for (uint8_t a = 1; a < 127; ++a) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) { serialFormat("I2C 0x%02X\n", a); ++found; }
  }
  serialFormat("I2C found=%u\n", found);
}

// Serial and web controls share this exact parser and validation path.
// Diagnostic and network-maintenance commands are handled only by USB below.
bool executeControl(char *line, String &reply) {
  char *tokens[6]; uint8_t count = 0; char *context = nullptr;
  for (char *p = strtok_r(line, " \t", &context); p; p = strtok_r(nullptr, " \t", &context)) {
    if (count >= 6) { reply = "ERR too many arguments"; return false; }
    tokens[count++] = p;
  }
  if (!count) { reply = "ERR empty command"; return false; }
  const char *name = tokens[0];
  if (!strcmp(name, "disarm") && count == 1) {
    armed = false; runtime[0].manualOn = false; runtime[1].manualOn = false;
    applyOutputs(); reply = "OK LOCKED; settings kept"; return true;
  }
  if (!strcmp(name, "arm") && count == 1) {
    if (!logicPassed) { reply = "ERR logic self-test failed"; return false; }
    if (!armed) {
      const uint64_t now = monotonicMs();
      runtime[0].cycleAnchorMs = now; runtime[1].cycleAnchorMs = now;
      armed = true;
    }
    applyOutputs(); reply = "OK ARMED"; return true;
  }
  if (!strcmp(name, "clock") && count == 3) {
    if (!setClock(tokens[1], tokens[2])) { reply = "ERR invalid date/time"; return false; }
    applyOutputs(); reply = "OK clock set UTC+8"; return true;
  }
  if (!strcmp(name, "off") && count == 2 && !strcmp(tokens[1], "all")) {
    const bool changed = config[0].mode != Mode::Manual || config[1].mode != Mode::Manual;
    config[0].mode = Mode::Manual; config[1].mode = Mode::Manual;
    runtime[0].manualOn = false; runtime[1].manualOn = false;
    applyOutputs();
    const bool saved = !changed || saveSettings();
    reply = saved ? "OK all OFF MANUAL" : "OK all OFF MANUAL; WARN not saved";
    return true;
  }
  uint32_t index = 0;
  if (count < 2 || !unsignedNumber(tokens[1], 2, index) || index < 1) {
    reply = "ERR command or channel; use help"; return false;
  }
  const uint8_t ch = static_cast<uint8_t>(index - 1);
  if ((!strcmp(name, "on") || !strcmp(name, "off")) && count == 2)
    return manualCommand(ch, !strcmp(name, "on"), reply);
  Config proposed = config[ch];
  if (!strcmp(name, "daily") && count == 4) {
    if (!parseMinute(tokens[2], proposed.onMinute) || !parseMinute(tokens[3], proposed.offMinute) ||
        proposed.onMinute == proposed.offMinute) {
      reply = "ERR HH:MM required, ON and OFF must differ"; return false;
    }
    proposed.mode = Mode::Daily;
  } else if (!strcmp(name, "cycle") && count == 4) {
    if (!unsignedNumber(tokens[2], incubator::MAX_PHASE_SECONDS, proposed.onSeconds) ||
        !unsignedNumber(tokens[3], incubator::MAX_PHASE_SECONDS, proposed.offSeconds) ||
        proposed.onSeconds == 0 || proposed.offSeconds == 0) {
      reply = "ERR cycle seconds must be 1..604800"; return false;
    }
    proposed.mode = Mode::Cycle;
  } else { reply = "ERR syntax; use help"; return false; }
  if (!incubator::valid(proposed)) { reply = "ERR invalid settings"; return false; }
  config[ch] = proposed;
  runtime[ch].manualOn = false; runtime[ch].cycleAnchorMs = monotonicMs();
  applyOutputs();
  const bool saved = saveSettings();
  reply = saved ? "OK settings applied and saved" : "OK applied; WARN not saved";
  return true;
}

void publishControl() {
  ControlSnapshot s = {};
  const uint64_t now = monotonicMs();
  for (uint8_t i = 0; i < 2; ++i) {
    s.config[i] = config[i]; s.output[i] = output[i]; s.requested[i] = want[i];
    s.remaining[i] = armed ? incubator::remainingSeconds(config[i], runtime[i], now) : 0;
  }
  s.armed = armed; s.logicPassed = logicPassed; s.storageReady = storageReady;
  s.sensorValid = sensorValid; s.oledReady = oledReady; s.limit = MAX_ACTIVE_CHANNELS;
  s.temperature = temperature; s.humidity = humidity; s.clockSource = clockSource;
  s.uptimeMs = now; s.sampledAtMs = now;
  struct tm t = {};
  if (currentTime(t)) strftime(s.clockText, sizeof(s.clockText), "%Y-%m-%d %H:%M:%S", &t);
  else s.clockSource = ClockSource::Unsynced;
  networkPublish(s);
}

void serviceWebCommands() {
  WebCommand request;
  if (!networkTakeCommand(request)) return;
  WebReply reply = {}; reply.id = request.id;
  String message;
  if (monotonicMs() >= request.expiresMs) { reply.ok = false; message = "ERR command expired; no change applied"; }
  else reply.ok = executeControl(request.text, message);
  applyOutputs(); publishControl();
  snprintf(reply.text, sizeof(reply.text), "%s", message.c_str());
  networkAnswer(reply);
}

void command(char *line) {
  String text(line); text.trim();
  if (text.isEmpty()) return;
  if (text == "help") { printHelp(); return; }
  if (text == "status") { applyOutputs(); printStatus(); return; }
  if (text == "scan") { scanI2C(); return; }
  if (text == "page") { page = (page + 1) % 4; lastPageMs = millis(); return; }
  if (text == "test") {
    if (armed) { serialLine("ERR disarm before test"); return; }
    logicPassed = incubator::selfTest();
    serialLine(logicPassed ? "LOGIC PASS" : "LOGIC FAIL"); return;
  }
  if (text == "wifi info" || text == "wifi ap" || text == "wifi forget") {
    if (text == "wifi forget" && armed) { serialLine("ERR disarm before wifi forget"); return; }
    const NetworkAction action = text == "wifi info" ? NetworkAction::Info :
      text == "wifi ap" ? NetworkAction::OpenAp : NetworkAction::Forget;
    serialLine(networkRequestAction(action) ? "OK network request queued" : "ERR network unavailable/busy");
    return;
  }
  char control[96]; text.toCharArray(control, sizeof(control));
  String reply; executeControl(control, reply); serialLine(reply);
}

void serviceSerial() {
  static char line[96]; static size_t used = 0; static bool overflow = false;
  uint8_t budget = 32;
  while (Serial.available() && budget--) {
    const char c = static_cast<char>(Serial.read());
    if (c == '\r') continue;
    if (c == '\n') {
      if (overflow) serialLine("ERR line too long");
      else { line[used] = '\0'; command(line); }
      used = 0; overflow = false;
    } else if (!overflow) {
      if (c < 32 || c > 126 || used >= sizeof(line) - 1) overflow = true;
      else line[used++] = c;
    }
  }
}

void serviceButtons(uint32_t now) {
  for (uint8_t i = 0; i < 3; ++i) {
    Button &b = buttons[i];
    const bool raw = digitalRead(b.pin) != LOW;
    if (raw != b.raw) { b.raw = raw; b.changedMs = now; }
    if (b.stable != b.raw && static_cast<uint32_t>(now - b.changedMs) >= 40) {
      b.stable = b.raw;
      if (!b.stable) {
        if (i < 2) {
          String reply; manualCommand(i, !output[i], reply); serialLine(reply);
        }
        else { page = (page + 1) % 4; lastPageMs = now; }
      }
    }
  }
}

void serviceSensor(uint32_t now) {
  if (static_cast<uint32_t>(now - lastSensorMs) < 5000) return;
  lastSensorMs = now;
  const float h = dht.readHumidity();
  const float t = dht.readTemperature();
  sensorValid = !isnan(h) && !isnan(t);
  humidity = sensorValid ? h : NAN;
  temperature = sensorValid ? t : NAN;
  if (sensorValid) serialFormat("ENV temperature=%.1fC humidity=%.1f%%\n", t, h);
  else serialLine("ENV invalid: check DHT11 power, DAT and pullup");
}

void displayPage(uint32_t now) {
  if (!oledReady || static_cast<uint32_t>(now - lastDisplayMs) < 250) return;
  lastDisplayMs = now;
  if (static_cast<uint32_t>(now - lastPageMs) >= 6000) {
    page = (page + 1) % 4; lastPageMs = now;
  }
  oled.clearDisplay(); oled.setTextSize(1); oled.setTextColor(SSD1306_WHITE); oled.setCursor(0, 0);
  struct tm t = {}; const bool timeOk = currentTime(t);
  char text[24];
  if (page == 0) {
    if (timeOk) { strftime(text, sizeof(text), "%H:%M:%S UTC+8", &t); oled.println(text); }
    else oled.println("TIME UNSYNC");
    if (sensorValid) oled.printf("T:%.1fC H:%.1f%%\n", temperature, humidity);
    else oled.println("DHT11: invalid");
    for (uint8_t i = 0; i < 2; ++i)
      oled.printf("L%u %s %s%s\n", i + 1, output[i] ? "ON " : "OFF", modeName(config[i].mode),
        want[i] && !output[i] ? " !" : "");
  } else if (page == 1 || page == 2) {
    const uint8_t ch = page - 1;
    oled.printf("L%u %s %s\n", ch + 1, output[ch] ? "ON" : "OFF", modeName(config[ch].mode));
    if (config[ch].mode == Mode::Cycle) {
      oled.printf("ON :%lus\n", static_cast<unsigned long>(config[ch].onSeconds));
      oled.printf("OFF:%lus\n", static_cast<unsigned long>(config[ch].offSeconds));
    } else if (config[ch].mode == Mode::Daily) {
      oled.printf("ON :%02u:%02u\n", config[ch].onMinute / 60, config[ch].onMinute % 60);
      oled.printf("OFF:%02u:%02u\n", config[ch].offMinute / 60, config[ch].offMinute % 60);
    } else {
      oled.println("Control: web/key/USB");
      oled.println("Auto: web or USB");
    }
    if (!armed) oled.println("LOCKED: web/USB arm");
    else if (config[ch].mode == Mode::Daily && !timeOk) oled.println("WAIT FOR CLOCK");
    else if (want[ch] && !output[ch]) oled.println("BLOCKED: power limit");
    else if (config[ch].mode == Mode::Cycle)
      oled.printf("Left:%lus\n", static_cast<unsigned long>(incubator::remainingSeconds(config[ch], runtime[ch], monotonicMs())));
    else if (config[ch].mode == Mode::Daily) oled.println("Daily clock active");
    else oled.println("Output command state");
  } else {
    if (timeOk) { strftime(text, sizeof(text), "%Y-%m-%d", &t); oled.println(text); }
    else oled.println("DATE UNSYNC");
    oled.printf("%s MAX:%u\n", armed ? "ARMED" : "LOCKED", MAX_ACTIVE_CHANNELS);
    oled.printf("Logic:%s NVS:%s\n", logicPassed ? "OK" : "FAIL", storageReady ? "OK" : "FAIL");
    const NetworkView net = networkView();
    oled.println(net.connected ? "WiFi: CONNECTED" : net.apActive ? "WiFi: CONFIG AP" : "WiFi: CONNECTING");
    oled.println(net.connected ? net.ip : net.apActive ? net.apIp : "No IP yet");
    oled.println(clockSource == ClockSource::Ntp ? "Clock: NTP" : clockSource == ClockSource::Manual ? "Clock: MANUAL" : "Clock: UNSYNC");
    oled.println("BLE: not enabled");
  }
  oled.display();
}

void setup() {
  for (uint8_t i = 0; i < 2; ++i) { pinMode(LIGHT_PIN[i], OUTPUT); digitalWrite(LIGHT_PIN[i], LOW); }
  Serial.begin(115200);
  Serial.setTxTimeoutMs(5);
  delay(1000);  // Bounded USB startup only, outputs remain OFF.
  setenv("TZ", "CST-8", 1); tzset();
  logicPassed = incubator::selfTest();
  serialLine(logicPassed ? "LOGIC PASS" : "LOGIC FAIL: outputs locked");
  serialFormat("BOARD flash=%u bytes, chip=%s\n", ESP.getFlashChipSize(), ESP.getChipModel());
  loadSettings();
  const uint64_t monoNow = monotonicMs();
  runtime[0].cycleAnchorMs = monoNow; runtime[1].cycleAnchorMs = monoNow;
  for (uint8_t i = 0; i < 3; ++i) {
    buttons[i].pin = BUTTON_PIN[i]; pinMode(buttons[i].pin, INPUT_PULLUP);
    buttons[i].raw = buttons[i].stable = digitalRead(buttons[i].pin) != LOW;
    buttons[i].changedMs = millis();
  }
  const bool wireReady = Wire.begin(SDA_PIN, SCL_PIN, 100000);
  Wire.setTimeOut(50);
  if (wireReady) {
    for (uint8_t address = 0x3C; address <= 0x3D; ++address) {
      Wire.beginTransmission(address);
      if (Wire.endTransmission() == 0) {
        oledReady = oled.begin(SSD1306_SWITCHCAPVCC, address, true, false);
        if (oledReady) { serialFormat("OLED address=0x%02X height=%d\n", address, OLED_HEIGHT); break; }
      }
    }
  }
  if (!oledReady) serialLine("WARN OLED unavailable; serial control still works");
  dht.begin();
  lastSensorMs = millis(); lastDisplayMs = millis() - 250; lastPageMs = millis();
  printHelp(); applyOutputs(); publishControl();
  if (!networkStart()) serialLine("ERR network task unavailable; USB/local control still works");
  printStatus();
}

void loop() {
  const uint32_t now = millis();
  if (networkTakeTimeSync()) {
    struct tm t = {}; const time_t epoch = time(nullptr);
    if (localtime_r(&epoch, &t) && t.tm_year >= 124 && t.tm_year <= 199) {
      clockValid = true; clockSource = ClockSource::Ntp;
      serialLine("TIME SYNC NTP UTC+8");
    }
  }
  serviceSerial();
  serviceWebCommands();
  serviceButtons(now);
  applyOutputs();
  serviceSensor(now);
  displayPage(now);
  static uint32_t lastSnapshotMs = 0;
  if (static_cast<uint32_t>(now - lastSnapshotMs) >= 250) {
    lastSnapshotMs = now; publishControl();
  }
  delay(1);
}
