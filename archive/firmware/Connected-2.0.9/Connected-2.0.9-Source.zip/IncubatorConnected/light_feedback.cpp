#include "module_config.h"
#include "light_feedback.h"
#include <Arduino.h>
#include <Preferences.h>
#if INC_ENABLE_PHOTO
namespace {
constexpr uint32_t SCHEMA=0xC3062801;
struct Settings {uint32_t schema;PhotoChannel channels[2];} config={};
PhotoView view={};portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
uint64_t badAt[2]={};bool previous[2]={};uint32_t lastSample=0;
constexpr uint8_t pins[2]={INC_PHOTO1_PIN,INC_PHOTO2_PIN};
bool save(const Settings&next){Preferences p;bool ok=p.begin("inc-photo",false)&&p.putBytes("config",&next,sizeof(next))==sizeof(next);p.end();return ok;}
}
bool photoStart(){config.schema=SCHEMA;Preferences p;if(p.begin("inc-photo",true)){Settings saved={};if(p.getBytesLength("config")==sizeof(saved)&&p.getBytes("config",&saved,sizeof(saved))==sizeof(saved)&&saved.schema==SCHEMA){bool good=true;for(auto c:saved.channels)if(c.dark>4095||c.bright>4095||c.onThreshold>1000||c.offThreshold>1000)good=false;if(good)config=saved;}p.end();}analogReadResolution(12);for(auto pin:pins){pinMode(pin,INPUT);analogSetPinAttenuation(pin,ADC_11db);}view.compiled=true;return true;}
PhotoView photoView(){PhotoView out;portENTER_CRITICAL(&mux);out=view;portEXIT_CRITICAL(&mux);return out;}
void photoSample(bool a,bool b,uint64_t now){if(uint32_t(millis()-lastSample)<250)return;lastSample=millis();Settings local;portENTER_CRITICAL(&mux);local=config;portEXIT_CRITICAL(&mux);PhotoView next={};next.compiled=true;next.sampledMs=now;bool want[2]={a,b};for(unsigned i=0;i<2;++i){auto&c=next.channels[i];c=local.channels[i];uint32_t sum=0;for(unsigned j=0;j<8;++j)sum+=analogRead(pins[i]);c.raw=sum/8;c.calibrated=photologic::level(c.raw,c.dark,c.bright)>=0;c.valid=c.enabled&&c.calibrated;c.level=c.calibrated?photologic::level(c.raw,c.dark,c.bright):0;c.on=c.valid&&c.level>=c.onThreshold;if(want[i]!=previous[i]){previous[i]=want[i];badAt[i]=0;}bool bad=c.valid&&photologic::mismatch(want[i],c.level,c.onThreshold,c.offThreshold);if(!bad)badAt[i]=0;else if(!badAt[i])badAt[i]=now;c.fault=badAt[i]&&now-badAt[i]>=3000;}portENTER_CRITICAL(&mux);view=next;portEXIT_CRITICAL(&mux);}
bool photoConfigure(uint8_t ch,const char*op,char*reply,unsigned size){if(ch>1)return false;Settings next;PhotoView sampled;portENTER_CRITICAL(&mux);next=config;sampled=view;portEXIT_CRITICAL(&mux);auto&c=next.channels[ch];if(!strcmp(op,"on")){if(photologic::level(0,c.dark,c.bright)<0){snprintf(reply,size,"ERR calibrate dark and bright first (span>=64)");return false;}c.enabled=true;}else if(!strcmp(op,"off"))c.enabled=false;else if(!strcmp(op,"dark")||!strcmp(op,"bright")){if(c.enabled||!sampled.sampledMs){snprintf(reply,size,"ERR photo off and wait for raw sample before calibration");return false;}if(!strcmp(op,"dark"))c.dark=sampled.channels[ch].raw;else c.bright=sampled.channels[ch].raw;}else{snprintf(reply,size,"ERR photo CHANNEL on|off|dark|bright");return false;}if(!save(next)){snprintf(reply,size,"ERR photo settings write failed");return false;}portENTER_CRITICAL(&mux);config=next;portEXIT_CRITICAL(&mux);snprintf(reply,size,"OK photo saved; brightness is relative, not lux");return true;}
bool photoThresholds(uint8_t ch,uint16_t onMin,uint16_t offMax,char*reply,unsigned size){if(ch>1||onMin<1||onMin>offMax||offMax>1000){snprintf(reply,size,"ERR threshold permille: 1<=onMin<=offMax<=1000");return false;}Settings next;portENTER_CRITICAL(&mux);next=config;portEXIT_CRITICAL(&mux);next.channels[ch].onThreshold=onMin;next.channels[ch].offThreshold=offMax;if(!save(next)){snprintf(reply,size,"ERR photo thresholds write failed");return false;}portENTER_CRITICAL(&mux);config=next;portEXIT_CRITICAL(&mux);snprintf(reply,size,"OK relative light thresholds saved");return true;}
#else
bool photoStart(){return true;}void photoSample(bool,bool,uint64_t){}PhotoView photoView(){return {};}
bool photoThresholds(uint8_t,uint16_t,uint16_t,char*r,unsigned n){snprintf(r,n,"ERR photo module disabled");return false;}
bool photoConfigure(uint8_t,const char*,char*r,unsigned n){snprintf(r,n,"ERR photo module disabled at compile time");return false;}
#endif
