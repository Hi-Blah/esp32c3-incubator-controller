#pragma once
#include <stdint.h>
struct PhotoChannel {bool enabled=false,calibrated=false,valid=false,on=false,fault=false;uint16_t raw=0,level=0,dark=0,bright=0,onThreshold=10,offThreshold=50;};
struct PhotoView {bool compiled=false;uint64_t sampledMs=0;PhotoChannel channels[2];};
bool photoStart();void photoSample(bool command1,bool command2,uint64_t now);PhotoView photoView();
bool photoConfigure(uint8_t channel,const char*operation,char*reply,unsigned size);
bool photoThresholds(uint8_t channel,uint16_t onMin,uint16_t offMax,char*reply,unsigned size);
namespace photologic {
constexpr int level(int raw,int dark,int bright){const int span=bright-dark;if(span<64&&span>-64)return -1;int value=(raw-dark)*1000/span;return value<0?0:value>1000?1000:value;}
constexpr bool mismatch(bool expected,int value,int onMin,int offMax){return expected?value<onMin:value>offMax;}
}
