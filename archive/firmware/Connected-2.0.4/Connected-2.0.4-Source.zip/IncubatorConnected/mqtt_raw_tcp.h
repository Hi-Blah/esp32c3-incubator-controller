#pragma once
#include <esp_transport.h>
namespace rawmqtt {esp_transport_handle_t create();bool live(esp_transport_handle_t);int error();void abort();}
