#include "mqtt_raw_tcp.h"
#include <esp_timer.h>
#include <lwip/sockets.h>
#include <lwip/netdb.h>
#include <lwip/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <atomic>
namespace rawmqtt {namespace {
// Only the MQTT worker performs IO. Destroy runs after SDK stop has joined that worker.
struct Context {esp_transport_handle_t handle=nullptr;std::atomic<int> fd{-1};} context;
std::atomic<int> lastError(0);
std::atomic<bool> aborting(false);
int fail(int e){lastError.store(e);errno=e;return -1;}
int64_t ms(){return esp_timer_get_time()/1000;}
int remaining(int64_t deadline){int64_t n=deadline-ms();return n>0?static_cast<int>(n):0;}
int wait(int fd,bool write,int timeout){if(fd<0)return fail(ENOTCONN);const int64_t deadline=ms()+(timeout>0?timeout:0);for(;;){fd_set readSet,writeSet;FD_ZERO(&readSet);FD_ZERO(&writeSet);FD_SET(fd,write?&writeSet:&readSet);int left=remaining(deadline);timeval tv={left/1000,(left%1000)*1000};int n=::select(fd+1,write?nullptr:&readSet,write?&writeSet:nullptr,nullptr,&tv);if(n<0&&errno==EINTR&&remaining(deadline))continue;return n<0?fail(errno):n;}}
int closeSocket(esp_transport_handle_t){int fd=context.fd.exchange(-1);if(fd>=0)::close(fd);return 0;}
int connectSocket(esp_transport_handle_t t,const char*host,int port,int timeout){
 closeSocket(t);lastError.store(0);const int64_t deadline=ms()+(timeout>0?timeout:1);sockaddr_in address={};address.sin_family=AF_INET;address.sin_port=htons(port);
 if(::inet_pton(AF_INET,host,&address.sin_addr)!=1){addrinfo hints={},*result=nullptr;hints.ai_family=AF_INET;hints.ai_socktype=SOCK_STREAM;if(::getaddrinfo(host,nullptr,&hints,&result)!=0||!result){if(result)::freeaddrinfo(result);return fail(EHOSTUNREACH);}address.sin_addr=reinterpret_cast<sockaddr_in*>(result->ai_addr)->sin_addr;::freeaddrinfo(result);}
 if(!remaining(deadline))return fail(ETIMEDOUT);
 int fd=::socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);if(fd<0)return fail(errno);context.fd=fd;
 int flags=::fcntl(fd,F_GETFL,0);if(flags<0||::fcntl(fd,F_SETFL,flags|O_NONBLOCK)<0){int e=errno;closeSocket(t);return fail(e);}
 int result=::connect(fd,reinterpret_cast<sockaddr*>(&address),sizeof(address));
 if(result<0&&errno!=EINPROGRESS&&errno!=EWOULDBLOCK){int e=errno;closeSocket(t);return fail(e);}
 if(result<0){result=wait(fd,true,remaining(deadline));int e=0;socklen_t n=sizeof(e);if(result<=0){e=result==0?ETIMEDOUT:lastError.load();closeSocket(t);return fail(e);}if(::getsockopt(fd,SOL_SOCKET,SO_ERROR,&e,&n)<0)e=errno;if(e){closeSocket(t);return fail(e);}}
 lastError.store(0);return 0;
}
int readSocket(esp_transport_handle_t t,char*buffer,int length,int timeout){if(aborting.load()){closeSocket(t);return fail(ECONNABORTED);}int fd=context.fd.load();int n=wait(fd,false,timeout);if(n<=0){if(n==0&&timeout>0)lastError.store(ETIMEDOUT);return n;}if(aborting.load())return fail(ECONNABORTED);int got=::recv(fd,buffer,length,MSG_DONTWAIT);if(got>0){lastError.store(0);return got;}if(!got)return fail(ECONNRESET);if(errno==EAGAIN||errno==EWOULDBLOCK||errno==EINTR)return 0;return fail(errno);}
int writeSocket(esp_transport_handle_t t,const char*buffer,int length,int timeout){const int64_t deadline=ms()+(timeout>0?timeout:1);int used=0;while(used<length){if(aborting.load()){closeSocket(t);return fail(ECONNABORTED);}int fd=context.fd.load();int n=wait(fd,true,remaining(deadline));if(n<=0)return n<0?-1:fail(ETIMEDOUT);if(aborting.load())return fail(ECONNABORTED);n=::send(fd,buffer+used,length-used,MSG_DONTWAIT);if(n>0){used+=n;continue;}if(n<0&&(errno==EAGAIN||errno==EWOULDBLOCK||errno==EINTR)){if(remaining(deadline))continue;return fail(ETIMEDOUT);}return fail(n<0?errno:ECONNRESET);}return used;}
int pollRead(esp_transport_handle_t t,int timeout){if(aborting.load()){closeSocket(t);return fail(ECONNABORTED);}return wait(context.fd,false,timeout);}
int pollWrite(esp_transport_handle_t,int timeout){return wait(context.fd,true,timeout);}
int destroy(esp_transport_handle_t t){closeSocket(t);context.handle=nullptr;return 0;}
}
esp_transport_handle_t create(){if(context.handle)return nullptr;auto t=esp_transport_init();if(!t)return nullptr;context.handle=t;context.fd=-1;aborting.store(false);lastError.store(0);esp_transport_set_context_data(t,&context);esp_transport_set_func(t,connectSocket,readSocket,writeSocket,closeSocket,pollRead,pollWrite,destroy);esp_transport_set_default_port(t,1883);return t;}
bool live(esp_transport_handle_t t){return context.handle==t;}
int error(){return lastError.load();}
void abort(){aborting.store(true);}
}
