#include "mqtt_publish_flow.h"
#include "pwm_result.h"
namespace {
constexpr bool flowTest(){mqttflow::Flow f;if(!f.ready(0,20000,8192,0))return false;f.accepted(7,mqttflow::Kind::Record,42,0,1);if(f.ready(500,20000,8192,0)||f.acknowledged(8)||!f.acknowledged(7)||f.ordinal!=42)return false;if(!f.expired(30000))return false;f.succeeded(10);if(f.ready(100,20000,8192,0)||!f.ready(210,20000,8192,0))return false;f.failed(300);return !f.ready(799,20000,8192,0)&&f.ready(800,20000,8192,0)&&!f.ready(800,8191,8192,0)&&!f.ready(800,20000,2047,0)&&!f.ready(800,20000,8192,1);}
static_assert(flowTest(),"One QoS1 packet, ACK, timeout and backpressure contract failed");
constexpr bool cappedBackoff(){mqttflow::Flow f;for(unsigned i=0;i<20;++i)f.failed(i*30000);return f.retryMs==30000;}
static_assert(cappedBackoff(),"Retry delay must cap at30s");
static_assert(pwmcheck::accepted(0,50,50)&&pwmcheck::accepted(0,20000,20000),"ESP_OK zero is success, not frequency");
static_assert(!pwmcheck::accepted(258,50,50)&&!pwmcheck::accepted(0,0,50)&&!pwmcheck::accepted(0,100,50),"Reject driver failure or wrong readback");
}
