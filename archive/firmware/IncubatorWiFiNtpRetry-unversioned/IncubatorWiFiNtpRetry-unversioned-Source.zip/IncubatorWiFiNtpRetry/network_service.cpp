#include "network_service.h"
#include "web_ui.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp_random.h>
#include <esp_timer.h>
#include <esp_sntp.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <atomic>
#include <string.h>
#include <sys/time.h>

namespace {
WebServer server(80);
Preferences networkPrefs;
QueueHandle_t commands = nullptr, replies = nullptr, actions = nullptr;
portMUX_TYPE snapshotMux = portMUX_INITIALIZER_UNLOCKED;
ControlSnapshot sharedSnapshot = {};
NetworkView sharedView = {};
std::atomic<bool> timeSyncPending(false);
std::atomic<bool> ntpReplyReceived(false);
std::atomic<uint32_t> ntpReplyCount(0);

// These values belong exclusively to the network task after initialization.
struct WifiCredentials {
  uint32_t schema;
  char ssid[33];
  char password[64];
};
constexpr uint32_t WIFI_SCHEMA = 0xC3061001UL;
WifiCredentials credentials = {};
bool prefsReady = false, configured = false, credentialsSaved = false;
bool apActive = false, wasConnected = false, pendingConnect = false, waitingDisconnect = false;
bool networkRunning = false;
String devicePassword, apName, hostName, csrfToken;
uint32_t connectDueMs = 0, beginDueMs = 0, attemptMs = 0, connectedMs = 0, nextId = 0;
bool ntpStarted = false;
uint8_t ntpFirstServer = 0;
uint32_t ntpAttemptMs = 0, ntpAttempts = 0;
constexpr uint32_t NTP_RETRY_MS = 60000;
constexpr uint32_t NTP_MIN_REQUEST_MS = 15000;
const char *const NTP_SERVERS[3] = {"ntp.aliyun.com", "pool.ntp.org", "time.cloudflare.com"};

void timeAvailable(struct timeval *value) {
  // The callback runs outside the control loop: do not touch GPIO or settings.
  if (!value || value->tv_sec < 1704067200LL || value->tv_sec >= 4102444800LL) return;
  ntpReplyCount.fetch_add(1);
  ntpReplyReceived.store(true);
  timeSyncPending.store(true);
}

void requestTimeSync(bool rotateServer, const char *reason) {
  if (WiFi.status() != WL_CONNECTED) {
    if (Serial) Serial.println("NTP WAIT_WIFI: connect home WiFi first");
    return;
  }
  if (ntpStarted) esp_sntp_stop();
  if (rotateServer) ntpFirstServer = (ntpFirstServer + 1) % 3;
  ntpReplyReceived.store(false);
  esp_sntp_setoperatingmode(ESP_SNTP_OPMODE_POLL);
  for (uint8_t i = 0; i < 3; ++i)
    esp_sntp_setservername(i, NTP_SERVERS[(ntpFirstServer + i) % 3]);
  esp_sntp_set_time_sync_notification_cb(timeAvailable);
  // Use the ESP-IDF thread-safe wrappers. TZ is set once by setup(), so retries
  // do not change the timezone or reset the independent light-cycle anchors.
  ntpAttemptMs = millis(); ++ntpAttempts; ntpStarted = true;
  esp_sntp_init();  // Asynchronous: no waiting for DNS or a time-server reply.
  if (Serial) Serial.printf("NTP REQUEST attempt=%lu primary=%s reason=%s\n",
    static_cast<unsigned long>(ntpAttempts), NTP_SERVERS[ntpFirstServer], reason);
}

void printTimeInfo() {
  if (!Serial) return;
  const bool connected = WiFi.status() == WL_CONNECTED;
  const char *state = !connected ? "WAIT_WIFI" :
    !ntpStarted ? "NOT_STARTED" : ntpReplyReceived.load() ? "SYNCED" : "WAIT_REPLY";
  Serial.printf("NTP firmware=WiFi-v2 state=%s attempts=%lu replies=%lu elapsed=%lus primary=%s\n",
    state, static_cast<unsigned long>(ntpAttempts), static_cast<unsigned long>(ntpReplyCount.load()),
    static_cast<unsigned long>(ntpStarted ? static_cast<uint32_t>(millis() - ntpAttemptMs) / 1000 : 0),
    NTP_SERVERS[ntpFirstServer]);
  if (connected) Serial.printf("NTP NETWORK gateway=%s dns1=%s dns2=%s\n",
    WiFi.gatewayIP().toString().c_str(), WiFi.dnsIP(0).toString().c_str(), WiFi.dnsIP(1).toString().c_str());
}

uint64_t nowMs() { return static_cast<uint64_t>(esp_timer_get_time()) / 1000ULL; }
bool due(uint32_t now, uint32_t deadline) {
  return static_cast<int32_t>(now - deadline) >= 0;
}
void copyText(char *dst, size_t size, const char *src) {
  if (size) snprintf(dst, size, "%s", src ? src : "");
}
ControlSnapshot snapshot() {
  ControlSnapshot result;
  portENTER_CRITICAL(&snapshotMux);
  result = sharedSnapshot;
  portEXIT_CRITICAL(&snapshotMux);
  return result;
}
void publishView(bool ready = true) {
  NetworkView view = {};
  view.ready = ready;
  view.connected = WiFi.status() == WL_CONNECTED;
  view.apActive = apActive;
  view.configured = configured;
  view.credentialsSaved = credentialsSaved;
  view.rssi = view.connected ? WiFi.RSSI() : 0;
  copyText(view.ip, sizeof(view.ip), view.connected ? WiFi.localIP().toString().c_str() : "");
  copyText(view.apIp, sizeof(view.apIp), apActive ? WiFi.softAPIP().toString().c_str() : "");
  copyText(view.apName, sizeof(view.apName), apName.c_str());
  portENTER_CRITICAL(&snapshotMux);
  sharedView = view;
  portEXIT_CRITICAL(&snapshotMux);
}
String randomPassword(size_t length) {
  // Wi-Fi is enabled before this function: esp_random uses RF entropy.
  static const char alphabet[] = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  String result; result.reserve(length);
  for (size_t i = 0; i < length; ++i) {
    const uint32_t ceiling = UINT32_MAX - (UINT32_MAX % (sizeof(alphabet) - 1));
    uint32_t value;
    do { value = esp_random(); } while (value >= ceiling);
    result += alphabet[value % (sizeof(alphabet) - 1)];
  }
  return result;
}
void printInfo() {
  publishView();
  if (!Serial) return;
  Serial.printf("WEB username=admin password=%s\n", devicePassword.c_str());
  if (apActive)
    Serial.printf("AP name=%s password=%s url=http://%s/\n", apName.c_str(),
                  devicePassword.c_str(), WiFi.softAPIP().toString().c_str());
  if (WiFi.status() == WL_CONNECTED)
    Serial.printf("WIFI CONNECTED url=http://%s/ rssi=%d\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
  else Serial.println(configured ? "WIFI connecting/retrying" : "WIFI not configured; join AP to set WiFi");
  if (!prefsReady) Serial.println("WARN network NVS unavailable");
  else if (configured && !credentialsSaved) Serial.println("WARN network settings not saved to NVS");
}
void openAp() {
  if (!apActive) {
    WiFi.mode(WIFI_AP_STA);
    apActive = WiFi.softAP(apName.c_str(), devicePassword.c_str(), 1, false, 2);
    if (!apActive && Serial) Serial.println("ERR configuration AP could not start");
    connectedMs = millis();
  }
  printInfo();
}
void closeAp() {
  if (!apActive) return;
  WiFi.softAPdisconnect(false);
  WiFi.mode(WIFI_STA);
  apActive = false;
  if (Serial) Serial.println("AP closed; use the home WiFi LAN address");
  publishView();
}
bool validCredentials(const WifiCredentials &c) {
  if (c.schema != WIFI_SCHEMA || !memchr(c.ssid, '\0', sizeof(c.ssid)) ||
      !memchr(c.password, '\0', sizeof(c.password))) return false;
  const size_t nameLength = strlen(c.ssid), passwordLength = strlen(c.password);
  if (!nameLength || nameLength > 32 || passwordLength < 8 || passwordLength > 63) return false;
  for (const char *p = c.ssid; *p; ++p)
    if (static_cast<unsigned char>(*p) < 32 || *p == 127) return false;
  for (const char *p = c.password; *p; ++p)
    if (static_cast<unsigned char>(*p) < 32 || *p == 127) return false;
  return true;
}
void loadNetwork() {
  prefsReady = networkPrefs.begin("inc-net", false);
  if (prefsReady) devicePassword = networkPrefs.getString("device-pass", "");
  if (devicePassword.length() != 16) {
    devicePassword = randomPassword(16);
    if (!prefsReady || networkPrefs.putString("device-pass", devicePassword) == 0)
      if (Serial) Serial.println("WARN device password not saved; it will change after reboot");
  }
  csrfToken = randomPassword(32);  // New token after each reboot; never placed in a URL.
  if (prefsReady && networkPrefs.getBytesLength("wifi") == sizeof(credentials)) {
    if (networkPrefs.getBytes("wifi", &credentials, sizeof(credentials)) == sizeof(credentials)
        && validCredentials(credentials)) configured = credentialsSaved = true;
    else credentials = {};
  }
}
String quoted(const String &s) {
  String result = "\""; result.reserve(s.length() + 8);
  static const char hex[] = "0123456789abcdef";
  for (size_t i = 0; i < s.length(); ++i) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    if (c == '"' || c == '\\') { result += '\\'; result += static_cast<char>(c); }
    else if (c < 32) { result += "\\u00"; result += hex[c >> 4]; result += hex[c & 15]; }
    else result += static_cast<char>(c);
  }
  result += '"'; return result;
}
void commonHeaders() {
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("X-Frame-Options", "DENY");
  server.sendHeader("Referrer-Policy", "no-referrer");
  server.sendHeader("Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
    "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
}
void response(int status, bool ok, const String &message) {
  commonHeaders();
  server.send(status, "application/json; charset=utf-8",
    String("{\"ok\":") + (ok ? "true" : "false") + ",\"message\":" + quoted(message) + "}");
}
bool authorized(bool mutation = false) {
  // Accept IP-address access only, preventing arbitrary Host/DNS rebinding.
  String host = server.hostHeader();
  if (host.endsWith(":80")) host.remove(host.length() - 3);
  const bool hostOk = (apActive && host == WiFi.softAPIP().toString()) ||
    (WiFi.status() == WL_CONNECTED && host == WiFi.localIP().toString());
  if (!hostOk) { response(403, false, "ERR access using the device IP address"); return false; }
  if (!server.authenticate("admin", devicePassword.c_str())) {
    commonHeaders();
    server.requestAuthentication(BASIC_AUTH, "Incubator", "Login required");
    return false;
  }
  if (mutation) {
    if (server.clientContentLength() > 512) { response(413, false, "ERR request too large"); return false; }
    if (server.header("X-CSRF-Token") != csrfToken) {
      response(403, false, "ERR refresh page before changing settings"); return false;
    }
    const String origin = server.header("Origin");
    if (origin.length() && origin != String("http://") + server.hostHeader()) {
      response(403, false, "ERR request origin"); return false;
    }
  }
  return true;
}
const char *modeLabel(incubator::Mode mode) {
  if (mode == incubator::Mode::Daily) return "DAILY";
  if (mode == incubator::Mode::Cycle) return "CYCLE";
  return "MANUAL";
}
void stateHandler() {
  if (!authorized()) return;
  const ControlSnapshot s = snapshot();
  const bool wifi = WiFi.status() == WL_CONNECTED;
  const char *clockSource = s.clockSource == ClockSource::Ntp ? "NTP" :
    s.clockSource == ClockSource::Manual ? "MANUAL" : "UNSYNC";
  String j; j.reserve(1800);
  j = String("{\"ok\":true,\"csrf\":") + quoted(csrfToken);
  j += ",\"clock\":" + quoted(s.clockText) + ",\"clockSource\":" + quoted(clockSource);
  j += String(",\"armed\":") + (s.armed ? "true" : "false");
  j += String(",\"logicPassed\":") + (s.logicPassed ? "true" : "false");
  j += String(",\"storageReady\":") + (s.storageReady ? "true" : "false");
  j += String(",\"sensorValid\":") + (s.sensorValid ? "true" : "false");
  j += ",\"limit\":" + String(s.limit);
  j += ",\"temperature\":" + (s.sensorValid ? String(s.temperature, 1) : String("null"));
  j += ",\"humidity\":" + (s.sensorValid ? String(s.humidity, 1) : String("null"));
  const uint64_t age = nowMs() - s.sampledAtMs;
  j += ",\"snapshotAgeMs\":" + String(static_cast<unsigned long>(age > UINT32_MAX ? UINT32_MAX : age));
  j += ",\"uptimeSeconds\":" + String(static_cast<unsigned long>(s.uptimeMs / 1000ULL));
  j += String(",\"wifi\":{\"connected\":") + (wifi ? "true" : "false");
  j += String(",\"configured\":") + (configured ? "true" : "false");
  j += String(",\"credentialsSaved\":") + (credentialsSaved ? "true" : "false");
  j += ",\"ip\":" + quoted(wifi ? WiFi.localIP().toString() : String(""));
  j += ",\"rssi\":" + String(wifi ? WiFi.RSSI() : 0);
  j += String(",\"apActive\":") + (apActive ? "true" : "false");
  j += ",\"apName\":" + quoted(apName) + "},\"lights\":[";
  for (uint8_t i = 0; i < 2; ++i) {
    if (i) j += ',';
    const incubator::Config &c = s.config[i];
    char on[6], off[6];
    snprintf(on, sizeof(on), "%02u:%02u", c.onMinute / 60, c.onMinute % 60);
    snprintf(off, sizeof(off), "%02u:%02u", c.offMinute / 60, c.offMinute % 60);
    j += String("{\"output\":") + (s.output[i] ? "true" : "false");
    j += String(",\"requested\":") + (s.requested[i] ? "true" : "false");
    j += String(",\"blocked\":") + (s.requested[i] && !s.output[i] ? "true" : "false");
    j += ",\"mode\":" + quoted(modeLabel(c.mode));
    j += ",\"dailyOn\":" + quoted(on) + ",\"dailyOff\":" + quoted(off);
    j += ",\"onSeconds\":" + String(c.onSeconds) + ",\"offSeconds\":" + String(c.offSeconds);
    j += ",\"remaining\":" + String(s.remaining[i]) + "}";
  }
  j += "]}";
  commonHeaders(); server.send(200, "application/json; charset=utf-8", j);
}
void commandHandler() {
  if (!authorized(true)) return;
  const String text = server.arg("cmd");
  if (text.isEmpty() || text.length() >= sizeof(WebCommand::text)) {
    response(400, false, "ERR command length"); return;
  }
  for (size_t i = 0; i < text.length(); ++i) {
    if (text[i] < 32 || text[i] > 126) { response(400, false, "ERR command characters"); return; }
  }
  WebCommand request = {};
  request.id = ++nextId;
  request.expiresMs = nowMs() + 800;
  copyText(request.text, sizeof(request.text), text.c_str());
  if (xQueueSend(commands, &request, 0) != pdTRUE) {
    response(503, false, "ERR control busy; query status before retrying"); return;
  }
  WebReply reply;
  const uint64_t deadline = nowMs() + 1200;
  while (nowMs() < deadline) {
    if (xQueueReceive(replies, &reply, pdMS_TO_TICKS(25)) == pdTRUE && reply.id == request.id) {
      response(reply.ok ? 200 : 400, reply.ok, reply.text); return;
    }
  }
  response(503, false, "ERR response timeout; query status before retrying");
}
void wifiHandler() {
  if (!authorized(true)) return;
  if (snapshot().armed) { response(409, false, "ERR lock before changing WiFi"); return; }
  const String ssid = server.arg("ssid"), password = server.arg("password");
  WifiCredentials next = {}; next.schema = WIFI_SCHEMA;
  if (ssid.length() > 32 || password.length() > 63 ||
      ssid.length() != strlen(ssid.c_str()) || password.length() != strlen(password.c_str())) {
    response(400, false, "ERR WiFi name/password length"); return;
  }
  copyText(next.ssid, sizeof(next.ssid), ssid.c_str());
  copyText(next.password, sizeof(next.password), password.c_str());
  if (!validCredentials(next)) { response(400, false, "ERR WiFi requires SSID 1..32 bytes and password 8..63 bytes"); return; }
  // Save a single blob before changing the live connection. Do not echo secrets.
  if (!prefsReady || networkPrefs.putBytes("wifi", &next, sizeof(next)) != sizeof(next)) {
    response(500, false, "ERR network NVS write failed; WiFi unchanged"); return;
  }
  credentials = next; configured = credentialsSaved = true;
  pendingConnect = true; waitingDisconnect = false; connectDueMs = millis() + 1500;
  response(200, true, "OK WiFi saved; connecting shortly");
}
void setupServer() {
  const char *headers[] = {"X-CSRF-Token", "Origin"};
  server.collectHeaders(headers, 2);
  server.on("/", HTTP_GET, []() {
    if (!authorized()) return;
    commonHeaders(); server.send_P(200, "text/html; charset=utf-8", WEB_UI);
  });
  server.on("/api/state", HTTP_GET, stateHandler);
  server.on("/api/command", HTTP_POST, commandHandler);
  server.on("/api/wifi", HTTP_POST, wifiHandler);
  server.onNotFound([]() { response(404, false, "ERR endpoint not found"); });
  server.begin();
}
void startConnection() {
  if (!configured) return;
  WiFi.begin(credentials.ssid, credentials.password);
  attemptMs = millis();
  if (Serial) Serial.println("WIFI connecting (2.4GHz)");
}
void forgetNetwork() {
  if (prefsReady && networkPrefs.isKey("wifi") && !networkPrefs.remove("wifi")) {
    if (Serial) Serial.println("ERR could not remove stored WiFi; configuration kept"); return;
  }
  configured = credentialsSaved = false; credentials = {}; pendingConnect = waitingDisconnect = false;
  WiFi.disconnectAsync(false, true);
  wasConnected = false;
  openAp();
  if (Serial) Serial.println("OK WiFi forgotten; light settings and device password kept");
}
void serviceNetwork() {
  const uint32_t now = millis();
  NetworkAction action;
  if (xQueueReceive(actions, &action, 0) == pdTRUE) {
    if (action == NetworkAction::Info) printInfo();
    else if (action == NetworkAction::OpenAp) openAp();
    else if (action == NetworkAction::Forget) forgetNetwork();
    else if (action == NetworkAction::NtpInfo) printTimeInfo();
    else if (action == NetworkAction::NtpRetry) {
      if (!wasConnected && WiFi.status() == WL_CONNECTED) {
        if (Serial) Serial.println("NTP connection ready; first request starts now");
      } else if (ntpStarted && static_cast<uint32_t>(millis() - ntpAttemptMs) < NTP_MIN_REQUEST_MS) {
        if (Serial) Serial.println("NTP WAIT: allow at least 15s between requests");
      } else requestTimeSync(true, "manual-retry");
    }
  }
  if (pendingConnect && due(now, connectDueMs)) {
    WiFi.disconnectAsync(false, false);
    // Async disconnect needs time to settle before begin with new credentials.
    pendingConnect = false; waitingDisconnect = true; beginDueMs = now + 250;
    wasConnected = false;
  }
  if (waitingDisconnect && due(now, beginDueMs)) {
    waitingDisconnect = false;
    startConnection();
  }
  const bool connected = WiFi.status() == WL_CONNECTED;
  if (connected && !wasConnected) {
    connectedMs = now;
    if (Serial) Serial.printf("WIFI CONNECTED url=http://%s/ rssi=%d\n",
                              WiFi.localIP().toString().c_str(), WiFi.RSSI());
    requestTimeSync(false, "wifi-connected");
  }
  if (!connected && wasConnected) {
    attemptMs = now;
    if (Serial) Serial.println("WIFI disconnected; local schedules continue");
  }
  wasConnected = connected;
  if (connected && ntpStarted && !ntpReplyReceived.load() &&
      static_cast<uint32_t>(millis() - ntpAttemptMs) >= NTP_RETRY_MS)
    requestTimeSync(true, "no-reply-retry");
  if (configured && !connected && !pendingConnect && !waitingDisconnect &&
      static_cast<uint32_t>(millis() - attemptMs) >= 30000) {
    if (!apActive) openAp();
    startConnection();
  }
  if (apActive && connected && static_cast<uint32_t>(millis() - connectedMs) >= 60000 &&
      (WiFi.softAPgetStationNum() == 0 || static_cast<uint32_t>(millis() - connectedMs) >= 900000)) closeAp();
  publishView();
}
void networkTask(void *) {
  char suffix[7];
  snprintf(suffix, sizeof(suffix), "%06lX", static_cast<unsigned long>(ESP.getEfuseMac() & 0xFFFFFFULL));
  apName = String("Incubator-") + suffix;
  hostName = String("incubator-") + suffix;
  WiFi.persistent(false);
  WiFi.setHostname(hostName.c_str());
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  loadNetwork(); setupServer();
  if (configured) { startConnection(); printInfo(); }
  else openAp();
  for (;;) {
    serviceNetwork();
    server.handleClient();  // May wait for HTTP data, but never runs in loop().
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}
}  // namespace

bool networkStart() {
  commands = xQueueCreate(4, sizeof(WebCommand));
  replies = xQueueCreate(4, sizeof(WebReply));
  actions = xQueueCreate(4, sizeof(NetworkAction));
  if (!commands || !replies || !actions) {
    if (commands) vQueueDelete(commands);
    if (replies) vQueueDelete(replies);
    if (actions) vQueueDelete(actions);
    commands = replies = actions = nullptr;
    return false;
  }
  // SNTP starts in serviceNetwork() after the station has an IP address.
  networkRunning = xTaskCreate(networkTask, "incubator-http", 8192, nullptr, 1, nullptr) == pdPASS;
  return networkRunning;
}
void networkPublish(const ControlSnapshot &s) {
  portENTER_CRITICAL(&snapshotMux);
  sharedSnapshot = s;
  portEXIT_CRITICAL(&snapshotMux);
}
NetworkView networkView() {
  NetworkView view;
  portENTER_CRITICAL(&snapshotMux);
  view = sharedView;
  portEXIT_CRITICAL(&snapshotMux);
  return view;
}
bool networkTakeCommand(WebCommand &request) {
  return commands && xQueueReceive(commands, &request, 0) == pdTRUE;
}
void networkAnswer(const WebReply &reply) {
  if (replies) xQueueSend(replies, &reply, 0);
}
bool networkTakeTimeSync() { return timeSyncPending.exchange(false); }
bool networkRequestAction(NetworkAction action) {
  return networkRunning && actions && xQueueSend(actions, &action, 0) == pdTRUE;
}
