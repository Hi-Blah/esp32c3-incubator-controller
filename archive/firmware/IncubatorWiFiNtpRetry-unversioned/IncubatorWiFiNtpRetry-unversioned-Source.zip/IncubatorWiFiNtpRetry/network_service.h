#pragma once
#include <Arduino.h>
#include "light_logic.h"

// Only loop() owns light configuration, runtime and GPIO writes. The HTTP task
// exchanges bounded messages and immutable snapshots with it.
enum class ClockSource : uint8_t { Unsynced = 0, Manual = 1, Ntp = 2 };
enum class NetworkAction : uint8_t { Info, OpenAp, Forget, NtpInfo, NtpRetry };
struct ControlSnapshot {
  incubator::Config config[2];
  bool output[2], requested[2];
  uint32_t remaining[2];
  bool armed, logicPassed, storageReady, sensorValid, oledReady;
  uint8_t limit;
  ClockSource clockSource;
  float temperature, humidity;
  uint64_t uptimeMs, sampledAtMs;
  char clockText[24];
};
struct NetworkView {
  bool ready, connected, apActive, configured, credentialsSaved;
  int16_t rssi;
  char ip[16], apIp[16], apName[25];
};
struct WebCommand {
  uint32_t id;
  uint64_t expiresMs;
  char text[96];
};
struct WebReply {
  uint32_t id;
  bool ok;
  char text[128];
};

bool networkStart();
void networkPublish(const ControlSnapshot &snapshot);
NetworkView networkView();
bool networkTakeCommand(WebCommand &request);
void networkAnswer(const WebReply &reply);
bool networkTakeTimeSync();
bool networkRequestAction(NetworkAction action);
