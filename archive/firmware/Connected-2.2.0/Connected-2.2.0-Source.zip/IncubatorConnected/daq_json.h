#pragma once
#include "control_service.h"
#include "event_log.h"
#include "light_feedback.h"
namespace daqjson {
template<class J>constexpr void emit(J&j,const ControlSnapshot&s,const PhotoView&p,const EventLogView&d,const char*t,const char*h,uint64_t now){
 j.raw("{\"firmware\":\"Connected-2.2.0\",\"boot_id\":").quoted(d.bootId).raw(",\"time\":");if(s.clockText[0])j.quoted(s.clockText);else j.raw("null");
 j.raw(",\"time_source\":").quoted(s.clockSource==ClockSource::Ntp?"NTP":s.clockSource==ClockSource::Manual?"MANUAL":"UNSYNC").raw(",\"uptime_ms\":").number(now).raw(",\"armed\":").boolean(s.armed).raw(",\"limit\":").number(s.limit).raw(",\"config_revision\":").number(s.configRevision);
 const char*output[]={",\"l1\":",",\"l2\":"},*enabled[]={",\"enabled1\":",",\"enabled2\":"},*mode[]={",\"mode1\":",",\"mode2\":"},*step[]={",\"step1\":",",\"step2\":"},*rounds[]={",\"rounds1\":",",\"rounds2\":"},*left[]={",\"left1_ms\":",",\"left2_ms\":"},*pwm[]={",\"pwm1\":",",\"pwm2\":"},*frequency[]={",\"frequency1\":",",\"frequency2\":"},*actual[]={",\"actual_frequency1\":",",\"actual_frequency2\":"},*duty[]={",\"duty1\":",",\"duty2\":"};
 for(unsigned i=0;i<2;i++){j.raw(output[i]).boolean(s.output[i]).raw(enabled[i]).boolean(s.channelEnabled[i]).raw(mode[i]).number(static_cast<unsigned>(s.config[i].mode)).raw(step[i]).number(s.progress[i].row+1).raw(rounds[i]).number(s.progress[i].completed).raw(left[i]).number(s.progress[i].remainingMs).raw(pwm[i]).boolean(s.config[i].pwm).raw(frequency[i]).number(s.config[i].frequency).raw(actual[i]).number(s.actualFrequency[i]).raw(duty[i]).number(s.config[i].duty);}
 j.raw(",\"sensor_valid\":").boolean(s.sensorValid).raw(",\"temperature\":").raw(t).raw(",\"humidity\":").raw(h).raw(",\"sampled_uptime_ms\":").number(s.sampledAtMs).raw(",\"sample_epoch_ms\":").number(s.sampleEpochMs).raw(",\"sample_time_trusted\":").boolean(s.sampleTimeTrusted).raw(",\"reset_reason\":").quoted(d.resetReason).raw(",\"boot_count\":").number(d.bootCount).raw(",\"power_or_external_count\":").number(d.powerLikeStarts).raw(",\"watchdog_count\":").number(d.watchdogStarts).raw(",\"log_ready\":").boolean(d.ready).raw(",\"pending_events\":").number(d.pending).raw(",\"dropped_events\":").number(d.dropped).raw(",\"log_write_failures\":").number(d.writeFailures).raw(",\"last_saved_epoch_ms\":").number(s.checkpointEpochMs).raw(",\"estimated_gap_ms\":").number(s.recoveryGapMs);
 j.raw(",\"transitions1\":").number(s.transitions[0]).raw(",\"transitions2\":").number(s.transitions[1]).raw(",\"last_switch1_ms\":").number(s.lastSwitchMs[0]).raw(",\"last_switch2_ms\":").number(s.lastSwitchMs[1]);
 uint64_t epoch=0;if(s.epochMs&&p.sampledMs<=now){epoch=p.sampledMs>=s.uptimeMs?s.epochMs+(p.sampledMs-s.uptimeMs):s.epochMs-(s.uptimeMs-p.sampledMs);}
 j.raw(",\"photo_epoch_ms\":").number(epoch).raw(",\"photo_time_trusted\":").boolean(epoch&&s.clockSource==ClockSource::Ntp).raw(",\"photo\":{\"schema\":\"raw-v2\",\"compiled\":").boolean(p.compiled).raw(",\"sampled_ms\":").number(p.sampledMs).raw(",\"channels\":[");
 for(unsigned i=0;i<2;i++){if(i)j.raw(",");j.raw("{\"raw\":").number(p.channels[i].raw).raw(",\"valid\":").boolean(p.channels[i].valid).raw("}");}j.raw("],\"automatic\":{\"active\":").boolean(p.automatic.active).raw(",\"completed\":").number(p.automatic.completed).raw(",\"total\":").number(p.automatic.total).raw("}}}");
}
}
