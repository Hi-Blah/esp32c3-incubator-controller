#pragma once
// Edit this one file before Arduino compilation. Existing pin wiring stays unchanged.
#ifndef INC_ENABLE_BLE
#define INC_ENABLE_BLE 1
#endif
#ifndef INC_ENABLE_DHT
#define INC_ENABLE_DHT 1
#endif
#ifndef INC_ENABLE_OLED
#define INC_ENABLE_OLED 1
#endif
#ifndef INC_ENABLE_PHOTO
#define INC_ENABLE_PHOTO 1
#endif
// Photo inputs are ADC1 GPIO0/1. GPIO0/1 buttons are omitted when photo support is compiled.
#define INC_PHOTO1_PIN 0
#define INC_PHOTO2_PIN 1
#define INC_PAGE_BUTTON_PIN 10
#if (INC_ENABLE_BLE != 0 && INC_ENABLE_BLE != 1) || (INC_ENABLE_DHT != 0 && INC_ENABLE_DHT != 1) || (INC_ENABLE_OLED != 0 && INC_ENABLE_OLED != 1) || (INC_ENABLE_PHOTO != 0 && INC_ENABLE_PHOTO != 1)
#error "Feature options must be 0 or 1"
#endif
