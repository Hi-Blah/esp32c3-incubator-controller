#include "photo_model.h"
#include "auto_calibration.h"
#include "channel_recovery.h"
namespace{
constexpr photomodel::Model grid(bool inverse){photomodel::Model m;m.complete=true;m.dark=inverse?4000:0;m.bright=inverse?0:4000;for(unsigned f=0;f<photomodel::FREQUENCIES;++f)for(unsigned d=0;d<photomodel::DUTIES;++d)m.adc[f][d]=inverse?4000-40*photomodel::duty[d]:40*photomodel::duty[d];m.adc[6][2]=inverse?3200:800;m.adc[6][3]=inverse?2400:1600;m.adc[7][2]=inverse?2800:1200;m.adc[7][3]=inverse?1600:2400;return m;}
static_assert(photomodel::expected(grid(false),1800,30)==420,"2D interpolation expected420permille");
static_assert(photomodel::expected(grid(true),1800,30)==420,"ADC polarity must not change relative estimate");
static_assert(photomodel::expected(grid(false),20000,90)==900,"last grid frequency boundary");
static_assert(photomodel::expected(grid(false),39,30)==-1,"do not extrapolate frequency below grid");
static_assert(photomodel::expected(photomodel::Model{},1800,30)==-1,"uncalibrated PWM cannot claim linear brightness");
static_assert(!photomodel::reliable(1)&&!photomodel::reliable(9)&&photomodel::reliable(10),"low-duty estimate must not trigger dim fault");
static_assert(photomodel::level(20,100,110)==-1,"insufficient optical dynamic range");
static_assert(autocal::pointCount(3)==172&&autocal::pointCount(1)==86,"all requested grid points");
static_assert(autocal::point(3,0).dark&&autocal::point(3,1).full&&autocal::point(3,85).frequencyIndex==11&&autocal::point(3,85).dutyIndex==7,"channel1 path");
static_assert(autocal::point(3,86).dark&&autocal::point(3,86).channel==1&&autocal::point(3,172).done,"channel2 path and completion");
constexpr bool policyTest(){channelpolicy::Preferences p[2]={{{true,false,3600,10},true,true},{{true,true,30,60},false,false}};bool running[2]={true,true};program::Config c[2]={program::defaults(),program::defaults()};c[0].mode=program::Mode::Manual;c[1].mode=program::Mode::Cycle;return channelpolicy::resumeMask(p,true,running,c)==2&&channelpolicy::checkpointInterval(p,running)==10&&!channelpolicy::anyNAS(p,2)&&channelpolicy::anyNAS(p,1)&&channelpolicy::anyManual(p);}
static_assert(policyTest(),"per-channel manual/cycle/NAS policies must remain independent");
}
