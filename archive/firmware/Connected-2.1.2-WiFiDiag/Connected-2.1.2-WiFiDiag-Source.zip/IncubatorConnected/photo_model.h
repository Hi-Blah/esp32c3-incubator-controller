#pragma once
#include <stdint.h>
namespace photomodel {
constexpr unsigned FREQUENCIES=12,DUTIES=9;
constexpr uint16_t frequency[FREQUENCIES]={40,50,60,100,200,500,1000,2000,5000,10000,15000,20000};
constexpr uint8_t duty[DUTIES]={0,10,20,40,50,60,80,90,100};
constexpr uint32_t SCHEMA=0xC3064101;
struct Model {uint32_t schema=SCHEMA,generation=0;uint16_t dark=0,bright=0;bool complete=false;uint16_t adc[FREQUENCIES][DUTIES]={};};
constexpr int level(int raw,int dark,int bright){const int span=bright-dark;if(span<64&&span>-64)return -1;const int value=(raw-dark)*1000/span;return value<0?0:value>1000?1000:value;}
constexpr int mix(int a,int b,unsigned pos,unsigned width){return width?a+static_cast<int>(static_cast<int64_t>(b-a)*pos/width):a;}
constexpr int expected(const Model&m,uint16_t hz,uint8_t percent){if(!m.complete||m.schema!=SCHEMA||level(m.dark,m.dark,m.bright)<0||hz<frequency[0]||hz>frequency[FREQUENCIES-1]||percent>100)return -1;unsigned fi=0,di=0;while(fi+1<FREQUENCIES&&frequency[fi+1]<=hz)++fi;while(di+1<DUTIES&&duty[di+1]<=percent)++di;const unsigned fj=fi+1<FREQUENCIES?fi+1:fi,dj=di+1<DUTIES?di+1:di;const int low=mix(m.adc[fi][di],m.adc[fi][dj],percent-duty[di],duty[dj]-duty[di]);const int high=mix(m.adc[fj][di],m.adc[fj][dj],percent-duty[di],duty[dj]-duty[di]);return level(mix(low,high,hz-frequency[fi],frequency[fj]-frequency[fi]),m.dark,m.bright);}
constexpr bool reliable(uint8_t percent){return percent==0||percent>=10;}
}
