#include "light_feedback.h"
static_assert(photologic::level(500,100,900)==500,"positive calibration");
static_assert(photologic::level(500,900,100)==500,"inverse calibration");
static_assert(photologic::level(50,100,900)==0,"clamp dark");
static_assert(photologic::level(4095,100,900)==1000,"clamp bright");
static_assert(photologic::level(20,10,30)==-1,"reject floating/no calibration range");
static_assert(photologic::mismatch(true,0,10,50),"on without observed light");
static_assert(!photologic::mismatch(false,20,10,50),"off tolerates ambient");

#include "manual_recovery.h"
static_assert(manualrecovery::mask(false,true,5,5,3,3,false)==0,"manual recovery default off");
static_assert(manualrecovery::mask(true,true,5,5,3,3,false)==3,"both manual ON authorized");
static_assert(manualrecovery::mask(true,false,5,5,3,3,false)==0,"locked snapshot never restores");
static_assert(manualrecovery::mask(true,true,4,5,3,3,false)==0,"program edit invalidates old snapshot");
static_assert(manualrecovery::mask(true,true,5,5,3,1,false)==1,"cycle or daily must not use manual snapshot");
static_assert(manualrecovery::mask(true,true,5,5,3,3,true)==0,"abnormal reset never restores");
static_assert(manualrecovery::mask(true,true,5,5,0,3,false)==0,"previous OFF stays OFF");
