#pragma once
#include <Arduino.h>
#include "program_logic.h"
enum class ClockSource : uint8_t { Unsynced, Manual, Ntp };
enum class NetworkAction : uint8_t { Info, OpenAp, Forget, Secrets };
enum class Origin : uint8_t { Web, Ble, Usb, Button, Mqtt };
struct RecoveryPolicy {
  bool enabled, countOutage;
  uint32_t restartAfterSeconds, checkpointSeconds;
};
struct ControlSnapshot {
  program::Config config[2];
  program::Progress progress[2];
  bool output[2], armed, logicPassed, storageReady, sensorValid, oledReady;
  bool resumeWaiting, recovered;
  uint8_t limit;
  ClockSource clockSource;
  RecoveryPolicy recovery;
  float temperature, humidity;
  uint64_t uptimeMs, sampledAtMs, sampleEpochMs, checkpointEpochMs, recoveryGapMs;
  bool sampleTimeTrusted;
  char clockText[24];
};
struct NetworkView {
  bool ready, connected, apActive, configured, credentialsSaved;
  int16_t rssi;
  char ip[16], apIp[16], apName[25], ssid[33];
};
struct ControlCommand {
  Origin origin;
  uint32_t id;
  uint64_t expiresMs;
  char text[1024];
};
struct ControlReply {
  uint32_t id;
  bool ok;
  char text[768];
};
struct BleView { bool ready, connected, secure; uint32_t passkey; char name[25]; };

bool controlEnqueue(const ControlCommand &command);
ControlSnapshot controlSnapshot();
void controlSensor(float temperature, float humidity, bool valid, bool oledReady);
bool networkStart();
NetworkView networkView();
void networkAnswer(const ControlReply &reply);
bool networkTakeTimeSync();
bool networkRequestAction(NetworkAction action);
bool bleStart();
BleView bleView();
void bleAnswer(const ControlReply &reply);
