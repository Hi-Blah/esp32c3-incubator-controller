#include "control_service.h"
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>
#include <BLESecurity.h>
#include <Preferences.h>
#include <esp_random.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <atomic>

namespace {
// Nordic UART UUIDs; ASCII commands end in LF (0x0a).
constexpr const char *SERVICE="6e400001-b5a3-f393-e0a9-e50e24dcca9e";
constexpr const char *BLE_RX_UUID="6e400002-b5a3-f393-e0a9-e50e24dcca9e";
constexpr const char *BLE_TX_UUID="6e400003-b5a3-f393-e0a9-e50e24dcca9e";
BLECharacteristic *tx=nullptr;
QueueHandle_t replyQueue=nullptr;
std::atomic<bool> connected(false),secure(false),restartAdvertising(false);
std::atomic<bool> ready(false),identityReady(false);
uint32_t passkey=0;
char name[25]={};
char input[1024]={};size_t used=0;bool overflow=false;uint32_t lastInput=0,nextId=0;
uint64_t monoMs(){return static_cast<uint64_t>(esp_timer_get_time())/1000ULL;}
void message(const char *text){ControlReply r={};snprintf(r.text,sizeof(r.text),"%s",text);if(replyQueue)xQueueSend(replyQueue,&r,0);}
class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    if(server->getConnectedCount()>1){server->disconnect(server->getConnId());return;}
    used=0;overflow=false;secure.store(false);connected.store(true);
  }
  void onDisconnect(BLEServer *) override {used=0;overflow=false;connected.store(false);secure.store(false);restartAdvertising.store(true);}
};
class SecurityCallbacks : public BLESecurityCallbacks {
  uint32_t onPassKeyRequest() override {return passkey;}
  void onPassKeyNotify(uint32_t) override {if(Serial)Serial.println("BLE pairing; see local OLED PIN or USB ble info");}
  bool onSecurityRequest() override {return true;}
  bool onConfirmPIN(uint32_t) override {return false;} // Display-only passkey entry.
#if defined(CONFIG_BLUEDROID_ENABLED)
  void onAuthenticationComplete(esp_ble_auth_cmpl_t desc) override {
    secure.store(desc.success && (desc.auth_mode & ESP_LE_AUTH_REQ_MITM));
  }
#elif defined(CONFIG_NIMBLE_ENABLED)
  void onAuthenticationComplete(ble_gap_conn_desc *desc,int status) override {
    secure.store(status==0 && desc->sec_state.encrypted && desc->sec_state.authenticated);
  }
#endif
};
class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    if(!secure.load())return;
    const String value=characteristic->getValue();
    if(static_cast<uint32_t>(millis()-lastInput)>10000){used=0;overflow=false;}
    lastInput=millis();
    for(size_t i=0;i<value.length();++i){char c=value[i];if(c=='\r')continue;
      if(c=='\n'){
        input[used]=0;
        if(overflow)message("ERR line too long or non-ASCII");
        else if(used){ControlCommand request={};request.origin=Origin::Ble;request.id=++nextId;request.expiresMs=monoMs()+2000;snprintf(request.text,sizeof(request.text),"%s",input);
          if(!controlEnqueue(request))message("ERR command queue busy");}
        used=0;overflow=false;
      }else if(!overflow){if(c<32||c>126||used>=sizeof(input)-1)overflow=true;else input[used++]=c;}
    }
  }
};
void worker(void *){
  ControlReply reply={};size_t offset=0,length=0;
  for(;;){
    if(restartAdvertising.exchange(false)){vTaskDelay(pdMS_TO_TICKS(200));BLEDevice::startAdvertising();}
    if(!connected.load()||!secure.load()){offset=length=0;while(xQueueReceive(replyQueue,&reply,0)==pdTRUE){};}
    else {
      if(offset>=length&&xQueueReceive(replyQueue,&reply,0)==pdTRUE){length=strlen(reply.text);if(length<sizeof(reply.text)-1){reply.text[length++]='\n';reply.text[length]=0;}offset=0;}
      if(offset<length){size_t n=length-offset>20?20:length-offset;
        if(offset+n<length)while(n && (static_cast<uint8_t>(reply.text[offset+n])&0xc0)==0x80)--n;
        tx->setValue(reinterpret_cast<const uint8_t *>(reply.text+offset),n);tx->notify();offset+=n;}
    }
    vTaskDelay(pdMS_TO_TICKS(40));
  }
}
}
bool bleStart(){
  char suffix[7];snprintf(suffix,sizeof(suffix),"%06lX",static_cast<unsigned long>(ESP.getEfuseMac()&0xffffff));snprintf(name,sizeof(name),"Incubator-BLE-%s",suffix);
  replyQueue=xQueueCreate(3,sizeof(ControlReply));if(!replyQueue)return false;
  BLEDevice::init(name);
  Preferences prefs;if(prefs.begin("inc-ble",false)){passkey=prefs.getUInt("passkey",0);if(passkey<100000||passkey>999999){passkey=100000+esp_random()%900000;prefs.putUInt("passkey",passkey);}prefs.end();}
  else return false;
  identityReady.store(true);
  BLEDevice::setSecurityCallbacks(new SecurityCallbacks());
  BLESecurity::setAuthenticationMode(true,true,true); // Bonding + MITM + Secure Connections.
  BLESecurity::setCapability(ESP_IO_CAP_OUT);BLESecurity::setPassKey(true,passkey);
  auto server=BLEDevice::createServer();server->setCallbacks(new ServerCallbacks());
  auto service=server->createService(SERVICE);
  auto rx=service->createCharacteristic(BLE_RX_UUID,BLECharacteristic::PROPERTY_WRITE|BLECharacteristic::PROPERTY_WRITE_ENC|BLECharacteristic::PROPERTY_WRITE_AUTHEN);
  rx->setAccessPermissions(ESP_GATT_PERM_WRITE_ENC_MITM);rx->setCallbacks(new RxCallbacks());
  tx=service->createCharacteristic(BLE_TX_UUID,BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_NOTIFY|BLECharacteristic::PROPERTY_READ_ENC|BLECharacteristic::PROPERTY_READ_AUTHEN);
  tx->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
#if defined(CONFIG_BLUEDROID_ENABLED)
  auto descriptor=new BLE2902();descriptor->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM|ESP_GATT_PERM_WRITE_ENC_MITM);tx->addDescriptor(descriptor);
#endif
  service->start();auto advertising=BLEDevice::getAdvertising();advertising->addServiceUUID(SERVICE);advertising->setScanResponse(true);BLEDevice::startAdvertising();
  ready=xTaskCreate(worker,"inc-ble",4096,nullptr,1,nullptr)==pdPASS;
  if(Serial)Serial.printf("BLE name=%s ready=%u (PIN hidden; USB ble info)\n",name,ready.load());return ready;
}
BleView bleView(){BleView b={};b.ready=ready.load();b.connected=connected.load();b.secure=secure.load();if(identityReady.load()){b.passkey=passkey;snprintf(b.name,sizeof(b.name),"%s",name);}return b;}
void bleAnswer(const ControlReply &r){if(replyQueue)xQueueSend(replyQueue,&r,0);}
