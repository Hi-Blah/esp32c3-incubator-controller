#include "control_service.h"
#include "web_ui.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp_random.h>
#include <esp_timer.h>
#include <esp_sntp.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <atomic>

namespace {
constexpr uint8_t MAX_WIFI = 8;
constexpr uint32_t LIST_SCHEMA = 0xC3062101UL;
struct Credentials { char ssid[33], password[64]; };
struct WifiList { uint32_t schema; uint8_t count; Credentials items[MAX_WIFI]; } list = {};
WebServer server(80); Preferences prefs;
QueueHandle_t replies = nullptr, actions = nullptr;
portMUX_TYPE viewMux = portMUX_INITIALIZER_UNLOCKED;
NetworkView sharedView = {};
std::atomic<bool> synced(false),everSynced(false);
bool prefsReady=false,saved=false,apActive=false,wasConnected=false,waiting=false;
String password,apName,csrf;
uint8_t activeIndex=0;
uint32_t attemptAt=0,beginAt=0,connectedAt=0,ntpAt=0,nextId=0;
uint64_t monoMs(){return static_cast<uint64_t>(esp_timer_get_time())/1000ULL;}
bool due(uint32_t now,uint32_t deadline){return static_cast<int32_t>(now-deadline)>=0;}
String quoted(const String &s){String r="\"";const char *hex="0123456789abcdef";for(size_t i=0;i<s.length();++i){uint8_t c=s[i];if(c=='"'||c=='\\'){r+='\\';r+=char(c);}else if(c<32){r+="\\u00";r+=hex[c>>4];r+=hex[c&15];}else r+=char(c);}return r+'"';}
String randomText(size_t n){const char a[]="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";String s;for(size_t i=0;i<n;++i)s+=a[esp_random()%(sizeof(a)-1)];return s;}
bool validCredential(const Credentials &c){
  if(!memchr(c.ssid,0,sizeof(c.ssid))||!memchr(c.password,0,sizeof(c.password)))return false;
  if(!strlen(c.ssid)||strlen(c.password)<8)return false;
  for(const char *p=c.ssid;*p;++p)if(static_cast<uint8_t>(*p)<32||*p==127)return false;
  for(const char *p=c.password;*p;++p)if(static_cast<uint8_t>(*p)<32||*p==127)return false;return true;
}
bool validList(const WifiList &l){if(l.schema!=LIST_SCHEMA||l.count>MAX_WIFI)return false;for(uint8_t i=0;i<l.count;++i){if(!validCredential(l.items[i]))return false;for(uint8_t j=0;j<i;++j)if(!strcmp(l.items[i].ssid,l.items[j].ssid))return false;}return true;}
void publish(){NetworkView n={};n.ready=true;n.connected=WiFi.status()==WL_CONNECTED;n.apActive=apActive;n.configured=list.count;n.credentialsSaved=saved;n.rssi=n.connected?WiFi.RSSI():0;
  snprintf(n.ip,sizeof(n.ip),"%s",n.connected?WiFi.localIP().toString().c_str():"");snprintf(n.ssid,sizeof(n.ssid),"%s",n.connected?WiFi.SSID().c_str():"");
  snprintf(n.apIp,sizeof(n.apIp),"%s",apActive?WiFi.softAPIP().toString().c_str():"");snprintf(n.apName,sizeof(n.apName),"%s",apName.c_str());
  portENTER_CRITICAL(&viewMux);sharedView=n;portEXIT_CRITICAL(&viewMux);
}
void info(){if(!Serial)return;Serial.printf("WEB username=admin password=%s\n",password.c_str());if(apActive)Serial.printf("AP name=%s password=%s url=http://%s/\n",apName.c_str(),password.c_str(),WiFi.softAPIP().toString().c_str());
  if(WiFi.status()==WL_CONNECTED)Serial.printf("WIFI SSID=%s url=http://%s/\n",WiFi.SSID().c_str(),WiFi.localIP().toString().c_str());Serial.printf("WIFI saved_profiles=%u nvs=%u\n",list.count,saved);
}
void openAp(){if(!apActive){WiFi.mode(WIFI_AP_STA);apActive=WiFi.softAP(apName.c_str(),password.c_str(),1,false,2);connectedAt=millis();}info();}
bool saveList(const WifiList &l){return prefsReady&&prefs.putBytes("wifi-list",&l,sizeof(l))==sizeof(l);}
void load(){prefsReady=prefs.begin("inc-net",false);if(prefsReady)password=prefs.getString("device-pass","");if(password.length()!=16){password=randomText(16);if(prefsReady)prefs.putString("device-pass",password);}csrf=randomText(32);list.schema=LIST_SCHEMA;
  WifiList candidate={};if(prefsReady&&prefs.getBytesLength("wifi-list")==sizeof(candidate)&&prefs.getBytes("wifi-list",&candidate,sizeof(candidate))==sizeof(candidate)&&validList(candidate)){list=candidate;saved=true;return;}
  struct Legacy {uint32_t schema;char ssid[33],password[64];} old={};
  if(prefsReady&&prefs.getBytesLength("wifi")==sizeof(old)&&prefs.getBytes("wifi",&old,sizeof(old))==sizeof(old)&&old.schema==0xC3061001UL){Credentials c={};memcpy(c.ssid,old.ssid,sizeof(c.ssid));memcpy(c.password,old.password,sizeof(c.password));if(validCredential(c)){list.count=1;list.items[0]=c;saved=saveList(list);}}
}
void headers(){server.sendHeader("Cache-Control","no-store");server.sendHeader("X-Content-Type-Options","nosniff");server.sendHeader("X-Frame-Options","DENY");server.sendHeader("Referrer-Policy","no-referrer");server.sendHeader("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");}
void response(int code,bool ok,const String &message){headers();server.send(code,"application/json; charset=utf-8",String("{\"ok\":")+(ok?"true":"false")+",\"message\":"+quoted(message)+"}");}
bool authorized(bool mutation=false){String host=server.hostHeader();if(host.endsWith(":80"))host.remove(host.length()-3);
  if(!((apActive&&host==WiFi.softAPIP().toString())||(WiFi.status()==WL_CONNECTED&&host==WiFi.localIP().toString()))){response(403,false,"ERR use device IP");return false;}
  if(!server.authenticate("admin",password.c_str())){headers();server.requestAuthentication(BASIC_AUTH,"Incubator","Login required");return false;}
  if(mutation){if(server.clientContentLength()>4096){response(413,false,"ERR request too large");return false;}if(server.header("X-CSRF-Token")!=csrf){response(403,false,"ERR refresh page");return false;}
    String origin=server.header("Origin");if(origin.length()&&origin!=String("http://")+server.hostHeader()){response(403,false,"ERR origin");return false;}}return true;
}
const char *mode(program::Mode m){return m==program::Mode::Daily?"DAILY":m==program::Mode::Cycle?"CYCLE":"MANUAL";}
void state(){if(!authorized())return;const auto s=controlSnapshot();const auto b=bleView();const bool wifi=WiFi.status()==WL_CONNECTED;
  String j;j.reserve(5500);j=String("{\"ok\":true,\"firmware\":\"Advanced-1\",\"csrf\":")+quoted(csrf);
  j+=",\"clock\":"+quoted(s.clockText)+",\"clockSource\":"+quoted(s.clockSource==ClockSource::Ntp?"NTP":s.clockSource==ClockSource::Manual?"MANUAL":"UNSYNC");
  j+=String(",\"armed\":")+(s.armed?"true":"false")+",\"limit\":"+String(s.limit);
  j+=String(",\"logicPassed\":")+(s.logicPassed?"true":"false")+",\"storageReady\":"+(s.storageReady?"true":"false");
  j+=",\"temperature\":"+(s.sensorValid?String(s.temperature,1):String("null"))+",\"humidity\":"+(s.sensorValid?String(s.humidity,1):String("null"));
  j+=",\"uptimeSeconds\":"+String(static_cast<unsigned long>(s.uptimeMs/1000));
  j+=String(",\"wifi\":{\"connected\":")+(wifi?"true":"false")+",\"ssid\":"+quoted(wifi?WiFi.SSID():String(""))+",\"ip\":"+quoted(wifi?WiFi.localIP().toString():String(""));
  j+=String(",\"apActive\":")+(apActive?"true":"false")+",\"apIp\":"+quoted(apActive?WiFi.softAPIP().toString():String(""))+",\"profiles\":[";
  for(uint8_t i=0;i<list.count;++i){if(i)j+=',';j+=quoted(list.items[i].ssid);}j+="]}";
  j+=String(",\"ble\":{\"ready\":")+(b.ready?"true":"false")+",\"connected\":"+(b.connected?"true":"false")+",\"secure\":"+(b.secure?"true":"false")+",\"name\":"+quoted(b.name)+"}";
  j+=String(",\"recovery\":{\"enabled\":")+(s.recovery.enabled?"true":"false")+",\"countOutage\":"+(s.recovery.countOutage?"true":"false");
  j+=",\"restartAfterSeconds\":"+String(s.recovery.restartAfterSeconds)+",\"checkpointSeconds\":"+String(s.recovery.checkpointSeconds);
  j+=String(",\"waiting\":")+(s.resumeWaiting?"true":"false")+",\"recovered\":"+(s.recovered?"true":"false");
  j+=",\"checkpointEpochMs\":"+String(static_cast<double>(s.checkpointEpochMs),0)+",\"gapMs\":"+String(static_cast<double>(s.recoveryGapMs),0)+"},\"lights\":[";
  for(uint8_t ch=0;ch<2;++ch){if(ch)j+=',';const auto &c=s.config[ch];const auto &p=s.progress[ch];
    j+=String("{\"output\":")+(s.output[ch]?"true":"false")+",\"requested\":"+(p.requested?"true":"false")+",\"mode\":"+quoted(mode(c.mode));
    j+=String(",\"finished\":")+(p.finished?"true":"false")+",\"row\":"+String(p.row)+",\"completed\":"+String(static_cast<double>(p.completed),0)+",\"remainingMs\":"+String(static_cast<double>(p.remainingMs),0);
    j+=",\"repeats\":"+String(c.repeats)+",\"daily\":[";
    for(uint8_t i=0;i<c.dailyCount;++i){if(i)j+=',';j+="["+String(c.daily[i].on)+","+String(c.daily[i].off)+"]";}j+="],\"steps\":[";
    for(uint8_t i=0;i<c.stepCount;++i){if(i)j+=',';j+="["+String(c.steps[i].onMs)+","+String(c.steps[i].offMs)+"]";}j+="]";
    j+=String(",\"pwm\":")+(c.pwm?"true":"false")+",\"frequency\":"+String(c.frequency)+",\"duty\":"+String(c.duty)+"}";
  }j+="]}";headers();server.send(200,"application/json; charset=utf-8",j);
}
void command(){if(!authorized(true))return;String text=server.arg("cmd");if(text.isEmpty()||text.length()>=sizeof(ControlCommand::text)){response(400,false,"ERR command length");return;}
  for(size_t i=0;i<text.length();++i)if(text[i]<32||text[i]>126){response(400,false,"ERR command characters");return;}
  ControlCommand c={};c.origin=Origin::Web;c.id=++nextId;c.expiresMs=monoMs()+2000;snprintf(c.text,sizeof(c.text),"%s",text.c_str());
  if(!controlEnqueue(c)){response(503,false,"ERR busy");return;}ControlReply r;uint64_t deadline=monoMs()+2500;
  while(monoMs()<deadline)if(xQueueReceive(replies,&r,pdMS_TO_TICKS(20))==pdTRUE&&r.id==c.id){response(r.ok?200:400,r.ok,r.text);return;}
  response(503,false,"ERR timeout; query status before retrying");
}
void scheduleConnection(uint8_t index){activeIndex=index;WiFi.disconnectAsync(false,false);waiting=true;beginAt=millis()+300;attemptAt=millis();wasConnected=false;}
void wifiHandler(){if(!authorized(true))return;if(controlSnapshot().armed){response(409,false,"ERR lock before changing WiFi");return;}
  String op=server.arg("op");if(op=="connect"||op=="remove"){
    String value=server.arg("index");char *end=nullptr;long index=strtol(value.c_str(),&end,10);
    if(!value.length()||*end||index<0||index>=list.count){response(400,false,"ERR profile index");return;}
    if(op=="connect"){response(200,true,"OK switching profile");scheduleConnection(index);return;}
    WifiList next=list;for(uint8_t i=index;i+1<next.count;++i)next.items[i]=next.items[i+1];--next.count;next.items[next.count]={};
    if(!saveList(next)){response(500,false,"ERR NVS write failed");return;}bool removingCurrent=WiFi.status()==WL_CONNECTED&&WiFi.SSID()==list.items[index].ssid;list=next;saved=true;
    response(200,true,"OK profile removed");if(removingCurrent){if(list.count)scheduleConnection(0);else{WiFi.disconnectAsync(false,false);waiting=false;openAp();}}else if(activeIndex>=list.count)activeIndex=0;return;
  }
  if(op!="add"){response(400,false,"ERR WiFi operation");return;}
  String ssid=server.arg("ssid"),key=server.arg("password");Credentials next={};
  if(ssid.length()>32||key.length()>63||ssid.length()!=strlen(ssid.c_str())||key.length()!=strlen(key.c_str())){response(400,false,"ERR WiFi length");return;}
  snprintf(next.ssid,sizeof(next.ssid),"%s",ssid.c_str());snprintf(next.password,sizeof(next.password),"%s",key.c_str());
  if(!validCredential(next)){response(400,false,"ERR SSID 1..32 bytes; password 8..63 bytes");return;}
  WifiList updated=list;uint8_t index=updated.count;for(uint8_t i=0;i<updated.count;++i)if(ssid==updated.items[i].ssid)index=i;
  if(index==updated.count){if(updated.count==MAX_WIFI){response(400,false,"ERR maximum 8 WiFi profiles");return;}++updated.count;}updated.items[index]=next;
  if(!saveList(updated)){response(500,false,"ERR NVS write failed");return;}list=updated;saved=true;response(200,true,"OK WiFi saved; passwords are never returned");
  if(WiFi.status()!=WL_CONNECTED&&!waiting)scheduleConnection(index);
}
void setupServer(){const char *h[]={"X-CSRF-Token","Origin"};server.collectHeaders(h,2);server.on("/",HTTP_GET,[]{if(authorized()){headers();server.send_P(200,"text/html; charset=utf-8",WEB_UI);}});
  server.on("/api/state",HTTP_GET,state);server.on("/api/command",HTTP_POST,command);server.on("/api/wifi",HTTP_POST,wifiHandler);server.onNotFound([]{response(404,false,"ERR not found");});server.begin();
}
void timeAvailable(timeval *){time_t e=time(nullptr);if(e>=1704067200LL&&e<4102444800LL){everSynced.store(true);synced.store(true);}}
void startNtp(){esp_sntp_stop();esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);esp_sntp_setservername(0,"ntp.aliyun.com");esp_sntp_setservername(1,"pool.ntp.org");esp_sntp_setservername(2,"time.cloudflare.com");esp_sntp_init();ntpAt=millis();}
void worker(void *){
  char suffix[7];snprintf(suffix,sizeof(suffix),"%06lX",static_cast<unsigned long>(ESP.getEfuseMac()&0xffffff));apName=String("Incubator-")+suffix;
  WiFi.persistent(false);WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);load();setupServer();
  if(list.count)scheduleConnection(0);else openAp();info();
  for(;;){uint32_t now=millis();NetworkAction action;
    if(xQueueReceive(actions,&action,0)==pdTRUE){if(action==NetworkAction::Info)info();else if(action==NetworkAction::OpenAp)openAp();else if(!controlSnapshot().armed){WifiList empty={};empty.schema=LIST_SCHEMA;if(saveList(empty)){list=empty;saved=true;waiting=false;WiFi.disconnectAsync(false,true);openAp();}else if(Serial)Serial.println("ERR WiFi forget write failed");}}
    if(waiting&&due(now,beginAt)){waiting=false;if(list.count){if(activeIndex>=list.count)activeIndex=0;WiFi.begin(list.items[activeIndex].ssid,list.items[activeIndex].password);attemptAt=millis();}}
    bool connected=WiFi.status()==WL_CONNECTED;
    if(connected&&!wasConnected){connectedAt=millis();startNtp();info();}
    if(!connected&&wasConnected)attemptAt=millis();wasConnected=connected;
    if(list.count&&!connected&&!waiting&&static_cast<uint32_t>(millis()-attemptAt)>=12000){if(!apActive)openAp();scheduleConnection((activeIndex+1)%list.count);}
    if(connected&&!everSynced.load()&&static_cast<uint32_t>(millis()-ntpAt)>=60000)startNtp();
    if(apActive&&connected&&static_cast<uint32_t>(millis()-connectedAt)>=60000&&(WiFi.softAPgetStationNum()==0||static_cast<uint32_t>(millis()-connectedAt)>=900000)){WiFi.softAPdisconnect(false);WiFi.mode(WIFI_STA);apActive=false;}
    publish();server.handleClient();vTaskDelay(pdMS_TO_TICKS(10));
  }
}
}
bool networkStart(){replies=xQueueCreate(4,sizeof(ControlReply));actions=xQueueCreate(4,sizeof(NetworkAction));sntp_set_time_sync_notification_cb(timeAvailable);return replies&&actions&&xTaskCreate(worker,"inc-http",12288,nullptr,1,nullptr)==pdPASS;}
NetworkView networkView(){NetworkView v;portENTER_CRITICAL(&viewMux);v=sharedView;portEXIT_CRITICAL(&viewMux);return v;}
void networkAnswer(const ControlReply &r){if(replies)xQueueSend(replies,&r,0);}
bool networkTakeTimeSync(){return synced.exchange(false);}
bool networkRequestAction(NetworkAction a){return actions&&xQueueSend(actions,&a,0)==pdTRUE;}
