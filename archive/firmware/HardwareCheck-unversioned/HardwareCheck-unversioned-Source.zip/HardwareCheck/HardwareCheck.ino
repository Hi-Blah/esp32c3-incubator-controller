// ESP32-C3 SuperMini: USB serial + SSD1306 + DHT11 hardware check.
// Arduino ESP32 core 3.x. No Wi-Fi, BLE, INA226 or light-control dependency.
// Power the controller by USB only during this test. Leave 24 V loads disconnected.
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <math.h>

#if !defined(ARDUINO_USB_CDC_ON_BOOT) || !ARDUINO_USB_CDC_ON_BOOT
#error "Enable Tools > USB CDC On Boot: GPIO21 is DHT DAT, not UART0 TX"
#endif

// GPIO numbers printed on the board, not physical pin positions.
constexpr int PIN_SDA = 6;
constexpr int PIN_SCL = 5;
constexpr int PIN_DHT = 21; // UART0 TX reused; use USB CDC Serial, not Serial0.
constexpr int PIN_LIGHT1 = 4;
constexpr int PIN_LIGHT2 = 7;
constexpr int OLED_HEIGHT = 64; // Change to 32 only for a 128 x 32 display.
static_assert(PIN_SDA != PIN_SCL && PIN_SDA != PIN_DHT && PIN_SCL != PIN_DHT,
              "SDA, SCL and DHT must use different GPIOs");
static_assert(PIN_SDA != PIN_LIGHT1 && PIN_SDA != PIN_LIGHT2 &&
              PIN_SCL != PIN_LIGHT1 && PIN_SCL != PIN_LIGHT2 &&
              PIN_DHT != PIN_LIGHT1 && PIN_DHT != PIN_LIGHT2,
              "Sensor pins must not overlap light-control pins");

Adafruit_SSD1306 display(128, OLED_HEIGHT, &Wire, -1);
DHT dht(PIN_DHT, DHT11);
bool oledReady = false;
bool envValid = false;
uint8_t oledAddress = 0;
float temperature = NAN;
float humidity = NAN;
uint32_t lastStatus = 0;
uint32_t lastSample = 0;
uint32_t lastDraw = 0;
bool sampled = false;

bool responds(uint8_t address) {
  Wire.beginTransmission(address);
  return Wire.endTransmission() == 0;
}

void scanBus() {
  Serial.printf("I2C scan: SDA=%d SCL=%d\n", PIN_SDA, PIN_SCL);
  unsigned int found = 0;
  for (uint8_t address = 1; address < 127; ++address) {
    if (responds(address)) {
      Serial.printf("  I2C device: 0x%02X\n", address);
      ++found;
    }
  }
  Serial.printf("I2C devices found: %u\n", found);
}

void printStatus() {
  Serial.printf("ALIVE uptime=%lu s | SDA=%d SCL=%d DAT=%d | OLED=%s",
                (unsigned long)(millis() / 1000), PIN_SDA, PIN_SCL, PIN_DHT,
                oledReady ? "OK" : "NOT FOUND");
  if (oledReady) Serial.printf(" (0x%02X)", oledAddress);
  if (envValid) Serial.printf(" | DHT11=OK T=%.1f C RH=%.1f %%\n", temperature, humidity);
  else Serial.println(sampled ? " | DHT11=INVALID" : " | DHT11=WAIT (first sample after 5 s)");
}

void drawStatus() {
  if (!oledReady) return;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("C3 CHECK ");
  display.print(millis() / 1000);
  display.println("s");
  display.printf("I2C %02X SDA%d SCL%d\n", oledAddress, PIN_SDA, PIN_SCL);
  if (envValid) {
    display.printf("T: %.1f C\n", temperature);
    display.printf("RH: %.1f %%\n", humidity);
  } else {
    display.println(sampled ? "DHT11 INVALID" : "DHT11 WAIT");
    display.printf("DAT GPIO%d\n", PIN_DHT);
  }
  display.display();
}

void setup() {
  // The purchased MOS module is used as active HIGH, with external 10k pulldowns.
  digitalWrite(PIN_LIGHT1, LOW);
  digitalWrite(PIN_LIGHT2, LOW);
  pinMode(PIN_LIGHT1, OUTPUT);
  pinMode(PIN_LIGHT2, OUTPUT);
  Serial.begin(115200);
  delay(1500); // Bounded wait; do not hang if the serial monitor is closed.
  Serial.println("\nESP32-C3 HardwareCheck | lights OFF");
  Serial.println("Commands: s + Send = scan I2C; p + Send = print status");
  Serial.printf("Chip: %s | flash: %lu bytes\n", ESP.getChipModel(),
                (unsigned long)ESP.getFlashChipSize());
  if (Wire.begin(PIN_SDA, PIN_SCL, 100000)) {
    Wire.setTimeOut(50);
    scanBus();
    if (responds(0x3C)) oledAddress = 0x3C;
    else if (responds(0x3D)) oledAddress = 0x3D;
    if (oledAddress) {
      // Wire was configured above; prevent the display library from using default pins.
      oledReady = display.begin(SSD1306_SWITCHCAPVCC, oledAddress, true, false);
      Serial.println(oledReady ? "OLED initialized" : "OLED allocation/init failed");
    } else Serial.println("OLED not found at 0x3C / 0x3D");
  } else Serial.println("I2C begin failed: check GPIO definitions");
  dht.begin();
  lastSample = millis();
  printStatus();
  drawStatus();
}

void loop() {
  while (Serial.available()) {
    const char command = Serial.read();
    if (command == 's' || command == 'S') scanBus();
    else if (command == 'p' || command == 'P') printStatus();
  }
  const uint32_t now = millis();
  if ((uint32_t)(now - lastSample) >= 5000) {
    lastSample = now;
    humidity = dht.readHumidity();
    temperature = dht.readTemperature();
    envValid = isfinite(temperature) && isfinite(humidity);
    sampled = true;
    if (envValid) Serial.printf("ENV T=%.1f C RH=%.1f %%\n", temperature, humidity);
    else Serial.printf("ENV INVALID: check DHT11 VCC/DAT/GND and GPIO%d\n", PIN_DHT);
  }
  if ((uint32_t)(now - lastStatus) >= 2000) {
    lastStatus = now;
    printStatus();
  }
  if ((uint32_t)(now - lastDraw) >= 1000) {
    lastDraw = now;
    drawStatus();
  }
  delay(2);
}
