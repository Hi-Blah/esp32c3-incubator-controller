#include "mqtt_service.h"
#include "event_log.h"
#include "format_decimal.h"
#include "mqtt_raw_tcp.h"
#include "mqtt_publish_flow.h"
#include "photo_json.h"
#include "json_stream.h"
#include <freertos/task.h>
#include <mqtt_client.h>
#include <Preferences.h>
#include <esp_timer.h>

#include <atomic>
#include <math.h>
#include <WiFi.h>
#include <NetworkClient.h>
namespace {
constexpr uint32_t SCHEMA=0xC3064001;
struct Config { uint32_t schema; bool enabled; uint16_t port; char host[97],username[33],password[128]; };
Config stored={},active={};
portMUX_TYPE configMux=portMUX_INITIALIZER_UNLOCKED,viewMux=portMUX_INITIALIZER_UNLOCKED;
MqttView view={};
MqttLifecycle lifecycle={0,0,0,"none"};
std::atomic<bool> changed(false),connected(false),announce(false),probeRequested(false);
esp_mqtt_client_handle_t client=nullptr;
std::atomic<int> lastAck(0);
std::atomic<uint32_t> connectionEpoch(0);
mqttflow::Flow flow;
mqttflow::RoutineScheduler routine;
uint32_t clientRetryAt=0,networkGeneration=0;
char suffix[7]={},base[40]={},stateTopic[64]={},availability[64]={},commandsTopic[64]={},clientId[40]={},progressTopic[64]={},requestTopic[64]={},replyTopic[64]={};
constexpr uint8_t DISCOVERY_COUNT=25;
uint8_t discoveryIndex=0;
uint32_t nextCommand=0,lastState=0,lastEnvironment=0,lastAttempt=0,lastProgress=0,lastRecoveryRequest=0;

uint32_t signature=0;
bool announced=false;
// Discovery and state publishing run serially on Arduino loopTask; enqueue copies the payload.
ControlSnapshot mqttSnapshot={};
char publishBuffer[3072]={},discoveryOptions[768]={};
uint64_t monoMs(){return static_cast<uint64_t>(esp_timer_get_time())/1000;}
void setReply(const char *text){portENTER_CRITICAL(&viewMux);snprintf(view.lastReply,sizeof(view.lastReply),"%s",text);portEXIT_CRITICAL(&viewMux);}
bool valid(const Config &c){
  if(c.schema!=SCHEMA||!c.port||!memchr(c.host,0,sizeof(c.host))||!memchr(c.username,0,sizeof(c.username))||!memchr(c.password,0,sizeof(c.password))||!c.host[0])return false;
  for(const char *p=c.host;*p;++p)if(!isalnum(static_cast<unsigned char>(*p))&&*p!='.'&&*p!='-')return false;
  for(const char *p=c.username;*p;++p)if(static_cast<unsigned char>(*p)<32||*p==127)return false;
  return !c.enabled || (c.username[0]&&c.password[0]);
}
void incoming(esp_mqtt_event_handle_t event){
  static char topic[96]={},payload[512]={};static size_t received=0,total=0;static bool retained=false;
  if(event->current_data_offset==0){
    received=total=0;
    if(!event->topic||event->topic_len<=0||event->topic_len>=static_cast<int>(sizeof(topic))||event->total_data_len<=0||event->total_data_len>=static_cast<int>(sizeof(payload)))return;
    memcpy(topic,event->topic,event->topic_len);topic[event->topic_len]=0;total=event->total_data_len;retained=event->retain;
  }
  if(!total||event->current_data_offset!=static_cast<int>(received)||event->data_len<0||received+event->data_len>total){total=0;return;}
  memcpy(payload+received,event->data,event->data_len);received+=event->data_len;if(received!=total)return;payload[total]=0;total=0;
  if(!strcmp(topic,"homeassistant/status")){if(!strcmp(payload,"online"))announce.store(true);return;}
  if(!strcmp(topic,replyTopic)){
    if(retained){setReply("ERR retained recovery response ignored");return;}
    ControlCommand c={};c.origin=Origin::Recovery;c.id=++nextCommand;c.expiresMs=monoMs()+2000;snprintf(c.text,sizeof(c.text),"%s",payload);if(!controlEnqueue(c))setReply("ERR recovery queue busy");return;
  }
  const size_t baseLength=strlen(base);if(strncmp(topic,base,baseLength)||strncmp(topic+baseLength,"/command/",9))return;
  if(retained){portENTER_CRITICAL(&viewMux);++view.retainedCommandsRejected;portEXIT_CRITICAL(&viewMux);setReply("ERR retained command ignored");return;}
  const char *target=topic+baseLength+9;ControlCommand c={};c.origin=Origin::Mqtt;c.id=++nextCommand;c.expiresMs=monoMs()+2000;
  const bool binary=!strcmp(payload,"ON")||!strcmp(payload,"OFF");
  if(!strcmp(target,"light1")||!strcmp(target,"light2")){if(!binary){setReply("ERR ON|OFF required");return;}snprintf(c.text,sizeof(c.text),"%s %u",!strcmp(payload,"ON")?"on":"off",target[5]=='1'?1:2);}
  else if(!strcmp(target,"arm")){if(!binary){setReply("ERR ON|OFF required");return;}snprintf(c.text,sizeof(c.text),"%s",!strcmp(payload,"ON")?"arm":"disarm");}
  else if(!strcmp(target,"pwm1")||!strcmp(target,"pwm2")){if(!binary){setReply("ERR PWM ON|OFF required");return;}snprintf(c.text,sizeof(c.text),"pwmset %u enable %s",target[3]=='1'?1:2,!strcmp(payload,"ON")?"ON":"OFF");}
  else{
    const bool duty=!strcmp(target,"duty1")||!strcmp(target,"duty2"),frequency=!strcmp(target,"frequency1")||!strcmp(target,"frequency2");
    if(!duty&&!frequency)return;uint32_t value=0;for(const char*p=payload;*p;++p){if(*p<'0'||*p>'9'||value>20000){setReply("ERR PWM integer required");return;}value=value*10+(*p-'0');}
    if((duty&&(value<1||value>99))||(frequency&&(value<40||value>20000))){setReply("ERR PWM value out of range");return;}
    snprintf(c.text,sizeof(c.text),"pwmset %u %s %lu",target[strlen(target)-1]=='1'?1:2,duty?"duty":"frequency",static_cast<unsigned long>(value));
  }
  if(!controlEnqueue(c))setReply("ERR controller queue busy");
}
void callback(void *,esp_event_base_t,int32_t id,void *data){
  auto e=static_cast<esp_mqtt_event_handle_t>(data);
  uint32_t stack=uxTaskGetStackHighWaterMark(nullptr),heapAtEvent=ESP.getFreeHeap();portENTER_CRITICAL(&viewMux);if(!view.stackMinimum||stack<view.stackMinimum)view.stackMinimum=stack;portEXIT_CRITICAL(&viewMux);
  if(id==MQTT_EVENT_BEFORE_CONNECT){portENTER_CRITICAL(&viewMux);++view.connectionAttempts;portEXIT_CRITICAL(&viewMux);}
  else if(id==MQTT_EVENT_CONNECTED){connected.store(true);announce.store(true);connectionEpoch.fetch_add(1);portENTER_CRITICAL(&viewMux);view.heapAfterConnect=heapAtEvent;view.lastError=view.errorType=view.transportError=view.socketError=0;portEXIT_CRITICAL(&viewMux);esp_mqtt_client_subscribe(client,commandsTopic,1);esp_mqtt_client_subscribe(client,"homeassistant/status",1);esp_mqtt_client_subscribe(client,replyTopic,1);setReply("OK MQTT connected; publishing discovery");}
  else if(id==MQTT_EVENT_DISCONNECTED)connected.store(false);
  else if(id==MQTT_EVENT_DATA)incoming(e);
  else if(id==MQTT_EVENT_PUBLISHED){lastAck.store(e->msg_id);}
  else if(id==MQTT_EVENT_ERROR){int error=-1,type=-1,tls=0,socket=0;if(e->error_handle){auto h=e->error_handle;type=h->error_type;tls=h->esp_tls_last_esp_err;socket=rawmqtt::error()?rawmqtt::error():h->esp_transport_sock_errno;if(type==MQTT_ERROR_TYPE_CONNECTION_REFUSED)error=h->connect_return_code;else if(socket)error=socket;else if(tls)error=tls;else if(h->esp_tls_stack_err)error=h->esp_tls_stack_err;}if(!error)error=-1;portENTER_CRITICAL(&viewMux);view.lastError=error;view.errorType=type;view.transportError=tls;view.socketError=socket;portEXIT_CRITICAL(&viewMux);char reply[96];snprintf(reply,sizeof(reply),"ERR MQTT code=%d type=%d transport=%d errno=%d",error,type,tls,socket);setReply(reply);}
}
int enqueue(const char *topic,const char *payload,mqttflow::Kind kind,bool retain,uint64_t ordinal=0){
 if(!client||!connected.load())return -1;uint32_t now=millis();int outbox=esp_mqtt_client_get_outbox_size(client);
 if(!flow.ready(now,ESP.getFreeHeap(),ESP.getMaxAllocHeap(),outbox)){flow.nextAt=now+500;portENTER_CRITICAL(&viewMux);++view.memoryDeferrals;portEXIT_CRITICAL(&viewMux);return -1;}
 int id=esp_mqtt_client_enqueue(client,topic,payload,0,1,retain,true);
 if(id>0){flow.accepted(id,kind,ordinal,now,connectionEpoch.load());portENTER_CRITICAL(&viewMux);view.inflightId=id;portEXIT_CRITICAL(&viewMux);}
 else{flow.failed(now);portENTER_CRITICAL(&viewMux);++view.publishFailures;portEXIT_CRITICAL(&viewMux);}
 return id;
}
// Keep the packet buffer in a separate frame; snapshots and packets need not overlap on the loop stack.
__attribute__((noinline)) int publishRecord(uint32_t now){
 lastAttempt=now;EventPacket packet={};if(!eventPeek(packet))return 0;
 char topic[64];snprintf(topic,sizeof(topic),"%s/%s",base,strstr(packet.json,R"JSON("kind":"environment")JSON")?"telemetry":"events");
 return enqueue(topic,packet.json,mqttflow::Kind::Record,false,packet.ordinal);
}

__attribute__((noinline)) bool discover(unsigned index){
  if(index>=11){
    const unsigned ch=(index-11)/7,metric=(index-11)%7;
    const char*obj[]={"raw","level","expected","ratio","on","fault","status_text"};
    const char*label[]={"ADC","相对亮度","预期相对亮度","亮度达标率","有光","光反馈异常","光反馈状态"};
    const char*component=metric==4||metric==5?"binary_sensor":"sensor";
    const char*condition=(metric==0||metric==6)?"true":metric==2?"c.expected_valid":metric==5?"c.enabled and c.calibrated":"c.calibrated";
    char topic[96],object[24],conditionText[192];snprintf(object,sizeof(object),"photo%u_%s",ch+1,obj[metric]);snprintf(topic,sizeof(topic),"homeassistant/%s/incubator_%s/%s/config",component,suffix,object);
    snprintf(conditionText,sizeof(conditionText),"{{ 'online' if value_json.photo.compiled and (%s) else 'offline' }}",metric==0?"true":metric==2?ch?"value_json.photo.channels[1].expected_valid":"value_json.photo.channels[0].expected_valid":metric==3?ch?"value_json.photo.channels[1].expected_valid and value_json.photo.channels[1].expected>0":"value_json.photo.channels[0].expected_valid and value_json.photo.channels[0].expected>0":metric==5?ch?"value_json.photo.channels[1].enabled and value_json.photo.channels[1].calibrated":"value_json.photo.channels[0].enabled and value_json.photo.channels[0].calibrated":ch?"value_json.photo.channels[1].calibrated":"value_json.photo.channels[0].calibrated");(void)condition;
    snprintf(discoveryOptions,sizeof(discoveryOptions),R"JSON("state_topic":"%s","value_template":"{{ %svalue_json.photo.channels[%u].%s%s }}",%s"availability_mode":"all","availability":[{"topic":"%s","payload_available":"online","payload_not_available":"offline"},{"topic":"%s","value_template":"%s","payload_available":"online","payload_not_available":"offline"}])JSON",stateTopic,metric==4||metric==5?"'ON' if ":"",ch,obj[metric],metric==4||metric==5?" else 'OFF'":metric>0&&metric<4?" / 10":"",metric==5?"\"device_class\":\"problem\",":metric>0&&metric<4?"\"state_class\":\"measurement\",\"unit_of_measurement\":\"%\",":"",availability,stateTopic,conditionText);
    int n=snprintf(publishBuffer,sizeof(publishBuffer),R"JSON({"name":"光源%u %s","unique_id":"incubator_%s_%s",%s,"device":{"identifiers":["incubator_%s"],"name":"光照培养箱","manufacturer":"DIY","model":"ESP32-C3 SuperMini","sw_version":"Connected-2.1.2"}})JSON",ch+1,label[metric],suffix,object,discoveryOptions,suffix);
    return n>0&&size_t(n)<sizeof(publishBuffer)&&enqueue(topic,publishBuffer,mqttflow::Kind::Discovery,true)>0;
  }
  const char *components[]={"light","light","sensor","sensor","switch","switch","number","number","switch","number","number"};
  const char *names[]={"光源1","光源2","温度","湿度","运行许可","光源1 PWM","光源1 占空比","光源1 PWM频率","光源2 PWM","光源2 占空比","光源2 PWM频率"};
  const char *objects[]={"light1","light2","temperature","humidity","arm","pwm1","duty1","frequency1","pwm2","duty2","frequency2"};
  char topic[96];auto &options=discoveryOptions;auto &payload=publishBuffer;options[0]=0;
  snprintf(topic,sizeof(topic),"homeassistant/%s/incubator_%s/%s/config",components[index],suffix,objects[index]);
  if(index<2||index==4||index==5||index==8){
    const char *field=index==4?"armed":index==0?"l1":index==1?"l2":objects[index];
    snprintf(options,sizeof(options),R"JSON("command_topic":"%s/command/%s","state_topic":"%s","%s":"{{ 'ON' if value_json.%s else 'OFF' }}","payload_on":"ON","payload_off":"OFF","qos":1,"retain":false,"availability_topic":"%s","payload_available":"online","payload_not_available":"offline")JSON",base,objects[index],stateTopic,index<2?"state_value_template":"value_template",field,availability);
  }else if(index==2||index==3){
    snprintf(options,sizeof(options),R"JSON("state_topic":"%s","value_template":"{{ value_json.%s }}","device_class":"%s","state_class":"measurement","unit_of_measurement":"%s","availability_mode":"all","availability":[{"topic":"%s","payload_available":"online","payload_not_available":"offline"},{"topic":"%s","value_template":"{{ 'online' if value_json.sensor_valid else 'offline' }}","payload_available":"online","payload_not_available":"offline"}])JSON",stateTopic,objects[index],objects[index],index==2?"°C":"%",availability,stateTopic);
  }
  if(index==6||index==7||index==9||index==10){const bool duty=index==6||index==9;
    snprintf(options,sizeof(options),R"JSON("min":%u,"max":%u,"step":1,"mode":"%s","unit_of_measurement":"%s","command_topic":"%s/command/%s","command_template":"{{ value | int }}","state_topic":"%s","value_template":"{{ value_json.%s }}","qos":1,"retain":false,"availability_topic":"%s","payload_available":"online","payload_not_available":"offline")JSON",duty?1:40,duty?99:20000,duty?"slider":"box",duty?"%":"Hz",base,objects[index],stateTopic,objects[index],availability);
  }
  int n=snprintf(payload,sizeof(payload),R"JSON({"name":"%s","unique_id":"incubator_%s_%s",%s,"device":{"identifiers":["incubator_%s"],"name":"光照培养箱","manufacturer":"DIY","model":"ESP32-C3 SuperMini","sw_version":"Connected-2.1.2"}})JSON",names[index],suffix,objects[index],options,suffix);
  return n>0&&static_cast<size_t>(n)<sizeof(payload)&&enqueue(topic,payload,mqttflow::Kind::Discovery,true)>0;
}
__attribute__((noinline)) bool publishState(const ControlSnapshot &s){
  auto log=eventLogView();char t[20],h[20];decimal::sample(t,sizeof(t),s.temperature,s.sensorValid);decimal::sample(h,sizeof(h),s.humidity,s.sensorValid);
  char time[32]="null";if(s.clockText[0])snprintf(time,sizeof(time),R"JSON("%s")JSON",s.clockText);
  auto &payload=publishBuffer;int n=snprintf(payload,sizeof(payload),R"JSON({"firmware":"Connected-2.1.2","boot_id":"%s","time":%s,"time_source":"%s","uptime_ms":%llu,"armed":%s,"limit":%u,"l1":%s,"l2":%s,"mode1":%u,"mode2":%u,"step1":%u,"step2":%u,"rounds1":%llu,"rounds2":%llu,"left1_ms":%llu,"left2_ms":%llu,"pwm1":%s,"pwm2":%s,"frequency1":%u,"frequency2":%u,"duty1":%u,"duty2":%u,"sensor_valid":%s,"temperature":%s,"humidity":%s,"sampled_uptime_ms":%llu,"sample_epoch_ms":%llu,"sample_time_trusted":%s,"reset_reason":"%s","boot_count":%lu,"power_or_external_count":%lu,"watchdog_count":%lu,"log_ready":%s,"pending_events":%u,"dropped_events":%lu,"log_write_failures":%lu,"last_saved_epoch_ms":%llu,"estimated_gap_ms":%llu})JSON",log.bootId,time,s.clockSource==ClockSource::Ntp?"NTP":s.clockSource==ClockSource::Manual?"MANUAL":"UNSYNC",s.uptimeMs,s.armed?"true":"false",s.limit,s.output[0]?"true":"false",s.output[1]?"true":"false",static_cast<unsigned>(s.config[0].mode),static_cast<unsigned>(s.config[1].mode),s.progress[0].row+1,s.progress[1].row+1,s.progress[0].completed,s.progress[1].completed,s.progress[0].remainingMs,s.progress[1].remainingMs,s.config[0].pwm?"true":"false",s.config[1].pwm?"true":"false",s.config[0].frequency,s.config[1].frequency,s.config[0].duty,s.config[1].duty,s.sensorValid?"true":"false",t,h,s.sampledAtMs,s.sampleEpochMs,s.sampleTimeTrusted?"true":"false",log.resetReason,static_cast<unsigned long>(log.bootCount),static_cast<unsigned long>(log.powerLikeStarts),static_cast<unsigned long>(log.watchdogStarts),log.ready?"true":"false",log.pending,static_cast<unsigned long>(log.dropped),static_cast<unsigned long>(log.writeFailures),s.checkpointEpochMs,s.recoveryGapMs);
  if(n<=0||size_t(n)>=sizeof(payload))return false;
  struct Sink{char*data;size_t used,capacity;bool write(const char*p,size_t count){if(used+count>=capacity)return false;memcpy(data+used,p,count);used+=count;data[used]=0;return true;}} sink={payload,size_t(n)-1,sizeof(payload)};
  jsonstream::Writer<Sink> j(sink);const auto p=photoView();j.raw(",\"photo\":");photojson::emit(j,p);
  const int64_t delta=static_cast<int64_t>(p.sampledMs)-static_cast<int64_t>(s.uptimeMs);const bool trusted=s.clockSource==ClockSource::Ntp&&s.epochMs&&delta>-10000&&delta<10000;
  j.raw(",\"photo_epoch_ms\":").number(trusted?s.epochMs+delta:0).raw(",\"photo_time_trusted\":").boolean(trusted).raw("}");
  return j.ok()&&enqueue(stateTopic,payload,mqttflow::Kind::State,true)>0;
}
__attribute__((noinline)) bool publishProgress(const ControlSnapshot&s){
 auto log=eventLogView();const uint8_t mask=(s.cycleRunning[0]?1:0)|(s.cycleRunning[1]?2:0);auto&payload=publishBuffer;
 const int n=snprintf(payload,sizeof(payload),R"JSON({"v":1,"boot":"%s","cfg":%lu,"seq":%llu,"epoch_ms":%llu,"trusted":%s,"waiting":%s,"armed":%s,"running":%u,"elapsed1_ms":"%llu","elapsed2_ms":"%llu","recovery_source":"%s","recovery_req":"%s","estimated_outage_ms":%llu,"startup_wait_ms":%llu,"reset_reason":"%s"})JSON",log.bootId,static_cast<unsigned long>(s.configRevision),s.uptimeMs,s.epochMs,s.clockSource==ClockSource::Ntp?"true":"false",s.resumeWaiting?"true":"false",s.armed?"true":"false",mask,s.progress[0].elapsedMs,s.progress[1].elapsedMs,s.recoverySource,s.recoveryReq,s.estimatedOutageMs,s.startupWaitMs,log.resetReason);
 return n>0&&static_cast<size_t>(n)<sizeof(payload)&&enqueue(progressTopic,payload,mqttflow::Kind::Progress,false)>0;
}
bool requestRecovery(const ControlSnapshot&s){auto log=eventLogView();auto&payload=publishBuffer;
 const int n=snprintf(payload,sizeof(payload),R"JSON({"v":1,"req":"%s","boot":"%s","previous":"%s","cfg":%lu,"min_epoch_ms":%llu})JSON",s.recoveryReq,log.bootId,s.previousBoot,static_cast<unsigned long>(s.configRevision),s.checkpointEpochMs);
 return n>0&&static_cast<size_t>(n)<sizeof(payload)&&enqueue(requestTopic,payload,mqttflow::Kind::RecoveryRequest,false)>0;
}
void runProbe(){
  if(mqttView().enabled||controlSnapshot().armed){if(Serial)Serial.println("ERR mqtt probe requires locked and MQTT disabled");return;}
  if(WiFi.status()!=WL_CONNECTED){if(Serial)Serial.println("ERR mqtt probe WiFi disconnected");return;}
  NetworkClient socket;IPAddress address;uint32_t started=millis();int ok=address.fromString(active.host)?socket.connect(address,active.port,3000):socket.connect(active.host,active.port,3000);uint32_t elapsed=millis()-started;socket.stop();
  if(Serial)Serial.printf("MQTT_PROBE host=%s port=%u connected=%u elapsed_ms=%lu local_ip=%s gateway=%s rssi=%ld heap_free=%lu heap_largest=%lu\n",active.host,active.port,ok?1:0,static_cast<unsigned long>(elapsed),WiFi.localIP().toString().c_str(),WiFi.gatewayIP().toString().c_str(),static_cast<long>(WiFi.RSSI()),static_cast<unsigned long>(ESP.getFreeHeap()),static_cast<unsigned long>(ESP.getMaxAllocHeap()));
}
void releaseClient(const char*reason){
 portENTER_CRITICAL(&viewMux);snprintf(lifecycle.lastStop,sizeof(lifecycle.lastStop),"%s",reason);portEXIT_CRITICAL(&viewMux);
 if(client){if(!strcmp(reason,"disabled")&&connected.load()&&ESP.getFreeHeap()>12288&&ESP.getMaxAllocHeap()>4096)esp_mqtt_client_publish(client,availability,"offline",0,0,1);rawmqtt::abort();esp_mqtt_client_stop(client);esp_mqtt_client_destroy(client);client=nullptr;}
 connected.store(false);lastAck.store(0);flow={};routine={};flow.nextAt=millis();announced=false;discoveryIndex=0;portENTER_CRITICAL(&viewMux);view.outboxBytes=view.inflightId=0;portEXIT_CRITICAL(&viewMux);
}
__attribute__((noinline)) void startClient(){
 const auto net=networkView();if(!net.connected||!net.ip[0]){clientRetryAt=millis()+1000;setReply("WAIT WiFi IP before MQTT startup");return;}networkGeneration=net.generation;
 uint32_t free=ESP.getFreeHeap(),largest=ESP.getMaxAllocHeap();if(free<24576||largest<8192){clientRetryAt=millis()+30000;setReply("WAIT MQTT startup memory; client not started");portENTER_CRITICAL(&viewMux);++view.memoryDeferrals;portEXIT_CRITICAL(&viewMux);return;}
 esp_mqtt_client_config_t c={};c.broker.address.hostname=active.host;c.broker.address.port=active.port;c.broker.address.transport=MQTT_TRANSPORT_OVER_TCP;
 c.credentials.username=active.username;c.credentials.authentication.password=active.password;c.credentials.client_id=clientId;
 c.session.protocol_ver=MQTT_PROTOCOL_V_3_1_1;c.session.keepalive=45;c.session.last_will.topic=availability;c.session.last_will.msg="offline";c.session.last_will.qos=1;c.session.last_will.retain=1;
 c.network.timeout_ms=4000;c.network.reconnect_timeout_ms=15000;c.network.transport=rawmqtt::create();c.task.stack_size=6144;c.task.priority=1;c.buffer.size=512;c.buffer.out_size=1024;c.outbox.limit=4096;
 auto transport=c.network.transport;portENTER_CRITICAL(&viewMux);view.heapBefore=free;portEXIT_CRITICAL(&viewMux);
 client=transport?esp_mqtt_client_init(&c):nullptr;
 if(client){portENTER_CRITICAL(&viewMux);++lifecycle.creations;portEXIT_CRITICAL(&viewMux);}
 if(!client&&transport&&rawmqtt::live(transport))esp_transport_destroy(transport);
 uint32_t heapAfterInit=ESP.getFreeHeap();portENTER_CRITICAL(&viewMux);view.heapAfterInit=heapAfterInit;portEXIT_CRITICAL(&viewMux);
 esp_err_t result=client?esp_mqtt_client_register_event(client,static_cast<esp_mqtt_event_id_t>(ESP_EVENT_ANY_ID),callback,nullptr):ESP_ERR_NO_MEM;
 if(result==ESP_OK)result=esp_mqtt_client_start(client);
 uint32_t heapAfterStart=ESP.getFreeHeap();portENTER_CRITICAL(&viewMux);view.heapAfterStart=heapAfterStart;portEXIT_CRITICAL(&viewMux);
 if(result!=ESP_OK){releaseClient("init_failed");portENTER_CRITICAL(&viewMux);view.lastError=result;view.errorType=-1;portEXIT_CRITICAL(&viewMux);clientRetryAt=millis()+30000;setReply("ERR MQTT initialization failed; retry after30s");}
}
void applyConfiguration(){bool enabled;portENTER_CRITICAL(&configMux);enabled=stored.enabled;portEXIT_CRITICAL(&configMux);releaseClient(enabled?"config_apply":"disabled");portENTER_CRITICAL(&configMux);active=stored;portEXIT_CRITICAL(&configMux);clientRetryAt=millis();if(active.enabled)startClient();}

}
bool mqttStart(){

  snprintf(suffix,sizeof(suffix),"%06lx",static_cast<unsigned long>(ESP.getEfuseMac()&0xffffff));snprintf(base,sizeof(base),"incubator/%s",suffix);snprintf(stateTopic,sizeof(stateTopic),"%s/state",base);snprintf(availability,sizeof(availability),"%s/availability",base);snprintf(commandsTopic,sizeof(commandsTopic),"%s/command/#",base);snprintf(clientId,sizeof(clientId),"incubator-%s",suffix);snprintf(progressTopic,sizeof(progressTopic),"%s/progress",base);snprintf(requestTopic,sizeof(requestTopic),"%s/recovery/request",base);snprintf(replyTopic,sizeof(replyTopic),"%s/recovery/reply",base);
  stored.schema=SCHEMA;stored.port=1883;snprintf(stored.host,sizeof(stored.host),"192.0.2.10");snprintf(stored.username,sizeof(stored.username),"incubator_device");
  Preferences p;if(p.begin("inc-mqtt",true)){Config saved={};if(p.getBytesLength("config")==sizeof(saved)&&p.getBytes("config",&saved,sizeof(saved))==sizeof(saved)&&valid(saved))stored=saved;p.end();}
  view.enabled=stored.enabled;view.port=stored.port;view.credentialsSaved=stored.password[0];snprintf(view.host,sizeof(view.host),"%s",stored.host);snprintf(view.username,sizeof(view.username),"%s",stored.username);changed.store(true);return true;
}
MqttLifecycle mqttLifecycleView(){MqttLifecycle result;portENTER_CRITICAL(&viewMux);result=lifecycle;portEXIT_CRITICAL(&viewMux);return result;}
MqttView mqttView(){MqttView v;portENTER_CRITICAL(&viewMux);v=view;portEXIT_CRITICAL(&viewMux);v.connected=connected.load();return v;}
bool mqttConfigure(bool enabled,const char *host,uint16_t port,const char *username,const char *password,char *error,size_t size){
  Config next;portENTER_CRITICAL(&configMux);next=stored;portEXIT_CRITICAL(&configMux);
  if(!host||!username||!password||strlen(host)>=sizeof(next.host)||strlen(username)>=sizeof(next.username)||strlen(password)>=sizeof(next.password)){snprintf(error,size,"ERR MQTT field length");return false;}
  next.enabled=enabled;next.port=port;snprintf(next.host,sizeof(next.host),"%s",host);snprintf(next.username,sizeof(next.username),"%s",username);if(*password)snprintf(next.password,sizeof(next.password),"%s",password);
  if(!valid(next)){snprintf(error,size,"ERR broker host, port, username or password");return false;}
  Preferences p;bool ok=p.begin("inc-mqtt",false)&&p.putBytes("config",&next,sizeof(next))==sizeof(next);p.end();if(!ok){snprintf(error,size,"ERR MQTT config write failed");return false;}
  portENTER_CRITICAL(&configMux);stored=next;portEXIT_CRITICAL(&configMux);
  portENTER_CRITICAL(&viewMux);view.enabled=next.enabled;view.port=next.port;view.credentialsSaved=next.password[0];snprintf(view.host,sizeof(view.host),"%s",next.host);snprintf(view.username,sizeof(view.username),"%s",next.username);portEXIT_CRITICAL(&viewMux);changed.store(true);return true;
}
void mqttAnswer(const ControlReply &r){setReply(r.text);if(Serial)Serial.printf("MQTT command %s\n",r.text);}
void mqttService(){
 if(changed.exchange(false))applyConfiguration();if(probeRequested.exchange(false))runProbe();const uint32_t now=millis();
 const auto net=networkView();if(client&&(!net.connected||net.generation!=networkGeneration)){releaseClient("network_changed");clientRetryAt=now+1000;}
 if(active.enabled&&!client&&static_cast<int32_t>(now-clientRetryAt)>=0)startClient();
 if(client){int bytes=esp_mqtt_client_get_outbox_size(client);portENTER_CRITICAL(&viewMux);view.outboxBytes=bytes>0?bytes:0;portEXIT_CRITICAL(&viewMux);}
 controlRead(mqttSnapshot);const auto&s=mqttSnapshot;if(static_cast<uint32_t>(now-lastEnvironment)>=60000){lastEnvironment=now;eventEmit("environment","sample",s,false);}
 const bool memoryLow=client&&(ESP.getFreeHeap()<8192||ESP.getMaxAllocHeap()<2048),ackExpired=client&&flow.expired(now);
 if(memoryLow||ackExpired){portENTER_CRITICAL(&viewMux);if(memoryLow)++lifecycle.memoryStops;if(ackExpired)++lifecycle.ackTimeoutStops;portEXIT_CRITICAL(&viewMux);releaseClient(memoryLow?"low_memory":"puback_timeout");clientRetryAt=now+120000;setReply(memoryLow?"WAIT MQTT low memory; released client, retry after120s":"WAIT MQTT PUBACK timeout; released client, retry after120s");portENTER_CRITICAL(&viewMux);++view.memoryDeferrals;portEXIT_CRITICAL(&viewMux);return;}
 int ack=lastAck.exchange(0);if(flow.acknowledged(ack)){auto kind=flow.kind;uint64_t ordinal=flow.ordinal;bool sameEpoch=flow.epoch==connectionEpoch.load();flow.succeeded(now);portENTER_CRITICAL(&viewMux);view.inflightId=0;portEXIT_CRITICAL(&viewMux);if(kind==mqttflow::Kind::Record&&ordinal)eventAck(ordinal);else if(kind==mqttflow::Kind::Discovery&&sameEpoch)++discoveryIndex;else if(kind==mqttflow::Kind::Availability&&sameEpoch)announced=true;}
 if(!connected.load())return;if(announce.exchange(false)){discoveryIndex=0;announced=false;lastState=0;}
 if(flow.id||static_cast<int32_t>(now-flow.nextAt)<0)return;
 if(ESP.getFreeHeap()<8192||ESP.getMaxAllocHeap()<2048){flow.nextAt=now+1000;portENTER_CRITICAL(&viewMux);++view.memoryDeferrals;portEXIT_CRITICAL(&viewMux);return;}
 if(s.nasWaiting){if(!lastRecoveryRequest||static_cast<uint32_t>(now-lastRecoveryRequest)>=2000){if(requestRecovery(s))lastRecoveryRequest=now;}return;}
 if(!announced){if(discoveryIndex<DISCOVERY_COUNT){discover(discoveryIndex);return;}enqueue(availability,"online",mqttflow::Kind::Availability,true);return;}
 uint32_t current=s.output[0]|(s.output[1]<<1)|(s.armed<<2)|(s.sensorValid<<3);current=current*31+s.config[0].frequency+s.config[0].duty*20001UL+s.config[0].pwm;current=current*31+s.config[1].frequency+s.config[1].duty*20001UL+s.config[1].pwm;
 if(s.sensorValid)current=current*31+static_cast<uint32_t>((s.temperature+100)*10)+static_cast<uint32_t>(s.humidity*10);
 const bool progressDue=static_cast<uint32_t>(now-lastProgress)>=2000;
 const bool stateDue=static_cast<uint32_t>(now-lastState)>=2000||current!=signature;
 const auto logs=eventLogView();bool recordDue=logs.ready&&logs.pending&&static_cast<uint32_t>(now-lastAttempt)>=500;
 for(uint8_t attempt=0;attempt<2;++attempt){
  const auto kind=routine.choose(progressDue,stateDue,recordDue);
  if(kind==mqttflow::Kind::Progress){if(publishProgress(s)){lastProgress=now;routine.accepted(kind);}return;}
  if(kind==mqttflow::Kind::State){if(publishState(s)){lastState=now;signature=current;routine.accepted(kind);}return;}
  if(kind==mqttflow::Kind::Record){const int id=publishRecord(now);if(id>0){routine.accepted(kind);return;}if(id<0)return;recordDue=false;continue;}
  return;
 }
}
void mqttRequestProbe(){probeRequested.store(true);}
