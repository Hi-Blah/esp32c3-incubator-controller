#include "mqtt_publish_flow.h"
#include "pwm_result.h"
#include "http_authority.h"
#include <initializer_list>
namespace {
constexpr bool authorityTest(){
 for(const char*s: {"192.168.4.1","192.168.124.106:80","192.0.2.10:18080","255.255.255.255:65535","0.0.0.0:1"})if(!httpaccess::ipv4Authority(s))return false;
 for(const char*s: {"","incubator.test","localhost","192.168.1.1.evil.test","256.1.1.1","1.2.3","1.2.3.4.5","01.2.3.4","1.2.3.4:","1.2.3.4:0","1.2.3.4:65536","1.2.3.4:00080","http://1.2.3.4","user@1.2.3.4","1.2.3.4/path","[::1]","1.2.3.4:80 junk","1.2.3.4\r\nX: value"})if(httpaccess::ipv4Authority(s))return false;
 return !httpaccess::ipv4Authority(nullptr);
}
static_assert(authorityTest(),"LAN/NAT HTTP authority validation failed");
constexpr bool flowTest(){mqttflow::Flow f;if(!f.ready(0,20000,8192,0))return false;f.accepted(7,mqttflow::Kind::Record,42,0,1);if(f.ready(500,20000,8192,0)||f.acknowledged(8)||!f.acknowledged(7)||f.ordinal!=42)return false;if(!f.expired(30000))return false;f.succeeded(10);if(f.ready(100,20000,8192,0)||!f.ready(210,20000,8192,0))return false;f.failed(300);return !f.ready(799,20000,8192,0)&&f.ready(800,20000,8192,0)&&!f.ready(800,8191,8192,0)&&!f.ready(800,20000,2047,0)&&!f.ready(800,20000,8192,1);}
static_assert(flowTest(),"One QoS1 packet, ACK, timeout and backpressure contract failed");
constexpr bool cappedBackoff(){mqttflow::Flow f;for(unsigned i=0;i<20;++i)f.failed(i*30000);return f.retryMs==30000;}
static_assert(cappedBackoff(),"Retry delay must cap at30s");
static_assert(pwmcheck::accepted(0,50,50)&&pwmcheck::accepted(0,20000,20000),"ESP_OK zero is success, not frequency");
static_assert(!pwmcheck::accepted(258,50,50)&&!pwmcheck::accepted(0,0,50)&&!pwmcheck::accepted(0,100,50),"Reject driver failure or wrong readback");
}
