#include "control_service.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <U8g2_for_Adafruit_GFX.h>
#include "bounded_dht.h"
#include "event_log.h"
#include "mqtt_service.h"
#include "mqtt_raw_tcp.h"
#include "format_decimal.h"
#include "pwm_result.h"
#include "recovery_protocol.h"
#include <esp_random.h>
#include <Preferences.h>
#include <esp_system.h>
#include <driver/ledc.h>
#include <driver/gpio.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <stdarg.h>

#if !defined(ARDUINO_USB_CDC_ON_BOOT) || !ARDUINO_USB_CDC_ON_BOOT
#error "Enable USB CDC On Boot: GPIO21 is DHT DAT, not UART0 TX"
#endif

namespace {
constexpr uint8_t LIGHT_PIN[2] = {4,7}, BUTTON_PIN[3] = {0,1,10};
constexpr uint8_t MAX_ACTIVE_CHANNELS = 2; // User-requested dual-channel operation; PSU rating is shared by both outputs.
constexpr uint32_t SETTINGS_SCHEMA = 0xC3062001UL, JOURNAL_SCHEMA = 0xC3062002UL;
Preferences settingsPrefs;
struct Settings {
  uint32_t schema, revision;
  RecoveryPolicy recovery;
  program::Config config[2];
} settings = {};
// Commands execute serially on inc-controller; rollback storage must not occupy its stack.
Settings settingsBeforeEdit={};
TaskHandle_t loopTask=nullptr;
struct Journal {
  uint32_t schema, revision;
  uint64_t epochMs, elapsed[2];
  bool armed, running[2];
} journal = {};
struct JournalTag {uint32_t schema;Journal saved;char boot[40];};
constexpr uint32_t JOURNAL_TAG_SCHEMA=0xC3062003;
bool nasRecoveryEnabled=false,nasWaiting=false,nasTried=false;
uint64_t nasDeadline=0,estimatedOutageMs=0,startupWaitMs=0;
char previousBoot[40]={},currentBoot[40]={},recoveryReq[17]={},recoverySource[16]="NONE";
program::Runtime runtime[2] = {};
program::Progress progress[2] = {};
bool output[2] = {}, enabled[2] = {true,true};
bool armed = false, logicPassed = false, storageReady = false;
bool resumeWaiting = false, recovered = false, checkpointDirty = false;
uint64_t checkpointEpochMs = 0, recoveryGapMs = 0, lastCheckpointMono = 0;
ClockSource clockSource = ClockSource::Unsynced;
QueueHandle_t commands = nullptr;
portMUX_TYPE stateMux = portMUX_INITIALIZER_UNLOCKED;
ControlSnapshot shared = {};
struct Sensor { float t, h; bool valid, oled; uint64_t sampledAtMs, sampleEpochMs; bool timeTrusted; } sensor = {};
bool pwmReady[2] = {};
uint8_t currentDuty[2] = {};
bool pwmSettingsDirty = false;
uint64_t pwmChangedAt = 0;
void publish();
bool finishedReported[2] = {};
Adafruit_SSD1306 oled(128,64,&Wire,-1);
U8G2_FOR_ADAFRUIT_GFX unicode;
BoundedDht11 dht;
bool oledReady = false;
uint8_t page = 0;
uint32_t lastSensor = 0, lastDisplay = 0, lastPage = 0;
uint64_t monoMs() { return static_cast<uint64_t>(esp_timer_get_time())/1000ULL; }
uint64_t epochMs() { timeval tv = {}; gettimeofday(&tv,nullptr); return static_cast<uint64_t>(tv.tv_sec)*1000ULL+tv.tv_usec/1000; }
void usb(const char *format, ...) {
  if (!Serial) return;
  char b[1024]; va_list args; va_start(args,format); vsnprintf(b,sizeof(b),format,args); va_end(args);
  Serial.write(reinterpret_cast<uint8_t *>(b),strlen(b));
}
const char *modeName(program::Mode m) { return m == program::Mode::Daily ? "DAILY" : m == program::Mode::Cycle ? "CYCLE" : "MANUAL"; }
bool clockOk(tm &t) {
  time_t epoch = time(nullptr);
  return clockSource != ClockSource::Unsynced && localtime_r(&epoch,&t) && t.tm_year >= 124 && t.tm_year <= 199;
}
bool validPolicy(RecoveryPolicy p) {
  return p.checkpointSeconds >= 10 && p.checkpointSeconds <= 3600 && p.restartAfterSeconds <= 604800;
}
bool saveSettings() {
  bool ok=storageReady && settingsPrefs.putBytes("settings",&settings,sizeof(settings)) == sizeof(settings);
  if(ok)pwmSettingsDirty=false;
  return ok;
}
void loadSettings() {
  settings.schema = SETTINGS_SCHEMA; settings.revision = 1;
  settings.recovery = {false,true,0,60};
  settings.config[0] = settings.config[1] = program::defaults();
  storageReady = settingsPrefs.begin("inc-con",false);
  Settings saved = {};
  if (storageReady && settingsPrefs.getBytesLength("settings") == sizeof(saved) &&
      settingsPrefs.getBytes("settings",&saved,sizeof(saved)) == sizeof(saved) &&
      saved.schema == SETTINGS_SCHEMA && validPolicy(saved.recovery) &&
      program::valid(saved.config[0]) && program::valid(saved.config[1])) settings = saved;
  else {
    // Migrate configuration only. The first Connected boot remains locked.
    bool migrated=false;
    Preferences previous;
    Settings prior={};
    if(previous.begin("inc-adv",true)){
      if(previous.getBytesLength("settings")==sizeof(prior)&&previous.getBytes("settings",&prior,sizeof(prior))==sizeof(prior)&&prior.schema==SETTINGS_SCHEMA&&validPolicy(prior.recovery)&&program::valid(prior.config[0])&&program::valid(prior.config[1])){settings=prior;migrated=true;}
      previous.end();
    }
    // Read the earlier format without modifying its keys, preserving rollback.
    struct Legacy { uint32_t schema; uint8_t mode[2]; uint16_t onMinute[2],offMinute[2]; uint32_t onSeconds[2],offSeconds[2]; } old = {};
    Preferences legacy;
    if (!migrated && legacy.begin("incubator",true)) {
      if (legacy.getBytesLength("settings") == sizeof(old) && legacy.getBytes("settings",&old,sizeof(old)) == sizeof(old) && old.schema == 0xC3060001UL) {
        for (uint8_t i=0;i<2;++i) {
          auto c = program::defaults(); c.mode = static_cast<program::Mode>(old.mode[i]);
          c.daily[0] = {static_cast<uint32_t>(old.onMinute[i])*60,static_cast<uint32_t>(old.offMinute[i])*60};
          c.steps[0] = {old.onSeconds[i]*1000UL,old.offSeconds[i]*1000UL};
          if (program::valid(c)) settings.config[i] = c;
        }
      }
      legacy.end();
    }
    saveSettings();
  }
  if (storageReady && settingsPrefs.getBytesLength("journal") == sizeof(journal) &&
      settingsPrefs.getBytes("journal",&journal,sizeof(journal)) == sizeof(journal) &&
      journal.schema == JOURNAL_SCHEMA && journal.revision == settings.revision &&
      journal.epochMs >= 1704067200000ULL) {
    for (uint8_t i=0;i<2;++i) if (settings.recovery.enabled && journal.armed && journal.running[i] && settings.config[i].mode == program::Mode::Cycle) resumeWaiting = true;
    checkpointEpochMs = journal.epochMs;
  }
  nasRecoveryEnabled=storageReady&&settingsPrefs.getBool("nas-resume",false);
  JournalTag tag={};
  if(storageReady&&settingsPrefs.getBytesLength("journal-nas")==sizeof(tag)&&settingsPrefs.getBytes("journal-nas",&tag,sizeof(tag))==sizeof(tag)&&tag.schema==JOURNAL_TAG_SCHEMA&&
     tag.saved.schema==journal.schema&&tag.saved.revision==journal.revision&&tag.saved.epochMs==journal.epochMs&&tag.saved.armed==journal.armed&&
     tag.saved.elapsed[0]==journal.elapsed[0]&&tag.saved.elapsed[1]==journal.elapsed[1]&&tag.saved.running[0]==journal.running[0]&&tag.saved.running[1]==journal.running[1]&&
     memchr(tag.boot,0,sizeof(tag.boot))&&recovery::token(tag.boot,10,39))snprintf(previousBoot,sizeof(previousBoot),"%s",tag.boot);
  // First boot of the stack fix discards resume authorization, preserving all configured programs.
  if(storageReady&&settingsPrefs.getUInt("stackfix",0)!=1){
    resumeWaiting=false;journal={};checkpointEpochMs=0;
    bool resetOk=settingsPrefs.putBytes("journal",&journal,sizeof(journal))==sizeof(journal);
    if(!resetOk||settingsPrefs.putUInt("stackfix",1)!=sizeof(uint32_t))storageReady=false;
  }
  auto reset=esp_reset_reason();
  if(reset==ESP_RST_PANIC||reset==ESP_RST_INT_WDT||reset==ESP_RST_TASK_WDT||reset==ESP_RST_WDT){resumeWaiting=false;checkpointDirty=true;}
}
bool checkpoint() {
  tm t = {};
  if (!storageReady) return false;
  // Only inc-controller invokes checkpoints; fixed buffers keep NVS paths within stack budget.
  static Journal next={};static JournalTag tag={};
  next={}; next.schema = JOURNAL_SCHEMA; next.revision = settings.revision;
  next.epochMs = clockOk(t) ? epochMs() : 0; next.armed = armed;
  for (uint8_t i=0;i<2;++i) {
    const auto p = program::evaluate(settings.config[i],runtime[i],monoMs(),true,0);
    next.elapsed[i] = p.elapsedMs;
    next.running[i] = enabled[i] && runtime[i].running && !p.finished && settings.config[i].mode == program::Mode::Cycle;
  }
  if (settingsPrefs.putBytes("journal",&next,sizeof(next)) != sizeof(next)) return false;
  tag={};tag.schema=JOURNAL_TAG_SCHEMA;tag.saved=next;snprintf(tag.boot,sizeof(tag.boot),"%s",currentBoot);
  if(recovery::token(tag.boot,10,39)&&settingsPrefs.putBytes("journal-nas",&tag,sizeof(tag))!=sizeof(tag))usb("WARN NAS checkpoint identity write failed; local progress saved\n");
  journal = next; checkpointEpochMs = next.epochMs; lastCheckpointMono = monoMs(); checkpointDirty = false;
  publish();eventEmit("checkpoint","progress_saved",controlSnapshot(),false);
  return true;
}
bool configurePwm(uint8_t ch) {
  const auto &c = settings.config[ch];
  if (!c.pwm) return true;
  // Use a dedicated IDF timer per channel: frequencies can change independently.
  ledc_timer_config_t timer = {};
  timer.speed_mode = LEDC_LOW_SPEED_MODE; timer.timer_num = static_cast<ledc_timer_t>(ch);
  timer.duty_resolution = LEDC_TIMER_10_BIT; timer.freq_hz = c.frequency; timer.clk_cfg = LEDC_USE_XTAL_CLK;
  esp_err_t timerResult=ledc_timer_config(&timer);if(timerResult!=ESP_OK){usb("PWM_DIAG light=%u stage=timer error=%s (%d)\n",ch+1,esp_err_to_name(timerResult),timerResult);return false;}
  ledc_channel_config_t channel = {};
  channel.gpio_num = LIGHT_PIN[ch]; channel.speed_mode = LEDC_LOW_SPEED_MODE;
  channel.channel = static_cast<ledc_channel_t>(ch); channel.timer_sel = static_cast<ledc_timer_t>(ch);
  channel.duty = 0; channel.hpoint = 0; channel.intr_type = LEDC_INTR_DISABLE;
  esp_err_t channelResult=ledc_channel_config(&channel);pwmReady[ch]=channelResult==ESP_OK;if(!pwmReady[ch])usb("PWM_DIAG light=%u stage=channel error=%s (%d)\n",ch+1,esp_err_to_name(channelResult),channelResult);
  currentDuty[ch]=0;
  return pwmReady[ch];
}
bool drive(uint8_t ch, bool on) {
  const auto &c = settings.config[ch];
  if (c.pwm && pwmReady[ch]) {
    const uint8_t duty = on ? c.duty : 0;
    if (currentDuty[ch] != duty) {
      if (!on) {
        // Disable the waveform immediately; zero duty may wait for a PWM period.
        if (ledc_stop(LEDC_LOW_SPEED_MODE,static_cast<ledc_channel_t>(ch),0) != ESP_OK) return false;
      } else if (ledc_set_duty(LEDC_LOW_SPEED_MODE,static_cast<ledc_channel_t>(ch),(1024UL*duty+50)/100) != ESP_OK ||
                 ledc_update_duty(LEDC_LOW_SPEED_MODE,static_cast<ledc_channel_t>(ch)) != ESP_OK) return false;
      currentDuty[ch] = duty;
    }
  } else {
    if (c.pwm && on) return false;
    if (pwmReady[ch]) { ledc_stop(LEDC_LOW_SPEED_MODE,static_cast<ledc_channel_t>(ch),0);gpio_reset_pin(static_cast<gpio_num_t>(LIGHT_PIN[ch]));pinMode(LIGHT_PIN[ch],OUTPUT);digitalWrite(LIGHT_PIN[ch],LOW);currentDuty[ch]=0;pwmReady[ch]=false; }
    const uint8_t duty = on?100:0;
    if(currentDuty[ch]!=duty){pinMode(LIGHT_PIN[ch],OUTPUT);digitalWrite(LIGHT_PIN[ch],on?HIGH:LOW);currentDuty[ch]=duty;}
  }
  return true;
}
void applyOutputs() {
  tm t = {}; bool timeValid = clockOk(t);
  const uint32_t sec = t.tm_hour*3600+t.tm_min*60+t.tm_sec;
  bool want[2]; const uint64_t now = monoMs();
  bool changed[2]={};
  for (uint8_t i=0;i<2;++i) {
    progress[i] = program::evaluate(settings.config[i],runtime[i],now,timeValid,sec);
    if(!enabled[i])progress[i].requested=false;
    want[i] = progress[i].requested;
    if (progress[i].finished && !finishedReported[i]) { finishedReported[i] = true; checkpointDirty = true; }
  }
  bool next[2]; program::limited(want,output,armed&&logicPassed,MAX_ACTIVE_CHANNELS,next);
  bool ok = true;
  for (uint8_t i=0;i<2;++i) if (!next[i] && !drive(i,false)) ok = false; // Break before make.
  if (ok) for (uint8_t i=0;i<2;++i) if (next[i] && !drive(i,true)) ok = false;
  if (!ok) {
    armed = false; checkpointDirty = true;
    for (uint8_t i=0;i<2;++i) { ledc_stop(LEDC_LOW_SPEED_MODE,static_cast<ledc_channel_t>(i),0);gpio_reset_pin(static_cast<gpio_num_t>(LIGHT_PIN[i]));pinMode(LIGHT_PIN[i],OUTPUT);digitalWrite(LIGHT_PIN[i],LOW);currentDuty[i]=0;pwmReady[i]=false;next[i]=false; }
    usb("ERR PWM output failed; LOCKED\n");
  }
  for (uint8_t i=0;i<2;++i) {
    if (output[i] != next[i]) usb("EVENT uptime_ms=%llu light=%u command=%s pwm=%u\n",now,i+1,next[i]?"ON":"OFF",settings.config[i].pwm);
    changed[i]=output[i]!=next[i];output[i] = next[i];
  }
  if(changed[0]||changed[1]){publish();for(uint8_t i=0;i<2;++i)if(changed[i])eventEmit("light_output",i==0?"light1":"light2",controlSnapshot(),false);}
}
void publish() {
  ControlSnapshot s = {};
  for (uint8_t i=0;i<2;++i) { s.config[i] = settings.config[i]; s.progress[i] = progress[i]; s.output[i] = output[i]; }
  s.armed = armed; s.logicPassed = logicPassed; s.storageReady = storageReady;
  s.resumeWaiting = resumeWaiting; s.recovered = recovered; s.recovery = settings.recovery;
  s.limit = MAX_ACTIVE_CHANNELS; s.clockSource = clockSource;
  s.uptimeMs = monoMs(); s.checkpointEpochMs = checkpointEpochMs; s.recoveryGapMs = recoveryGapMs;
  tm t = {}; if (clockOk(t)) strftime(s.clockText,sizeof(s.clockText),"%Y-%m-%d %H:%M:%S",&t);
  s.configRevision=settings.revision;s.epochMs=clockSource==ClockSource::Ntp?epochMs():0;
  s.estimatedOutageMs=estimatedOutageMs;s.startupWaitMs=startupWaitMs;s.nasRecoveryEnabled=nasRecoveryEnabled;s.nasWaiting=nasWaiting&&resumeWaiting;
  for(uint8_t i=0;i<2;++i)s.cycleRunning[i]=armed&&enabled[i]&&runtime[i].running&&!progress[i].finished&&settings.config[i].mode==program::Mode::Cycle;
  snprintf(s.previousBoot,sizeof(s.previousBoot),"%s",previousBoot);snprintf(s.recoveryReq,sizeof(s.recoveryReq),"%s",recoveryReq);snprintf(s.recoverySource,sizeof(s.recoverySource),"%s",recoverySource);
  portENTER_CRITICAL(&stateMux);
  s.temperature = sensor.t; s.humidity = sensor.h; s.sensorValid = sensor.valid && s.uptimeMs>=sensor.sampledAtMs && s.uptimeMs-sensor.sampledAtMs<15000; s.oledReady = sensor.oled;s.sampledAtMs=sensor.sampledAtMs;s.sampleEpochMs=sensor.sampleEpochMs;s.sampleTimeTrusted=sensor.timeTrusted;
  shared = s;
  portEXIT_CRITICAL(&stateMux);
}
bool number(const char *s,uint32_t max,uint32_t &n) {
  if (!s||!*s) return false; uint64_t v=0;
  for (const char *p=s;*p;++p) { if (*p<'0'||*p>'9') return false; v=v*10+(*p-'0'); if(v>max)return false; }
  n=static_cast<uint32_t>(v);return true;
}
bool seconds(const char *s,uint32_t &ms) {
  if (!s||!*s) return false;
  char b[16]; if(strlen(s)>=sizeof(b))return false; snprintf(b,sizeof(b),"%s",s);
  char *dot=strchr(b,'.');uint32_t whole=0,frac=0;
  if(dot) { *dot=0; if(strlen(dot+1)!=1||!number(dot+1,9,frac))return false; }
  if(!number(b,604800,whole))return false;
  const uint64_t v=static_cast<uint64_t>(whole)*1000+frac*100;
  if(v<program::MIN_MS||v>program::MAX_MS)return false;ms=v;return true;
}
bool daySecond(const char *s,uint32_t &n) {
  if(!s||(strlen(s)!=5&&strlen(s)!=8)||s[2]!=':'||(strlen(s)==8&&s[5]!=':'))return false;
  char b[3]={s[0],s[1],0};uint32_t h,m,sec=0;
  if(!number(b,23,h))return false;b[0]=s[3];b[1]=s[4];if(!number(b,59,m))return false;
  if(strlen(s)==8){b[0]=s[6];b[1]=s[7];if(!number(b,59,sec))return false;}
  n=h*3600+m*60+sec;return true;
}
bool setClock(const char *date,const char *clock) {
  if(strlen(date)!=10||date[4]!='-'||date[7]!='-'||strlen(clock)!=8)return false;
  uint32_t sec;if(!daySecond(clock,sec))return false;
  char y[5]={};memcpy(y,date,4);uint32_t year;if(!number(y,2099,year)||year<2024)return false;
  char b[3]={date[5],date[6],0};uint32_t month,day;
  if(!number(b,12,month)||!month)return false;b[0]=date[8];b[1]=date[9];if(!number(b,31,day)||!day)return false;
  tm t={};t.tm_year=year-1900;t.tm_mon=month-1;t.tm_mday=day;t.tm_hour=sec/3600;t.tm_min=(sec/60)%60;t.tm_sec=sec%60;
  time_t epoch=mktime(&t);tm check={};if(!localtime_r(&epoch,&check)||check.tm_year!=static_cast<int>(year-1900)||check.tm_mon!=static_cast<int>(month-1)||check.tm_mday!=static_cast<int>(day))return false;
  timeval tv={};tv.tv_sec=epoch;if(settimeofday(&tv,nullptr))return false;clockSource=ClockSource::Manual;return true;
}
__attribute__((noinline)) void finishRecovery(const Journal&saved,bool remote){
 const uint64_t now=epochMs(),uptime=monoMs();const auto plan=recovery::plan(saved.epochMs,saved.elapsed,now,uptime,settings.recovery.countOutage,settings.recovery.restartAfterSeconds,remote);
 nasWaiting=false;
 if(!plan.valid){resumeWaiting=false;armed=false;checkpointDirty=true;snprintf(recoverySource,sizeof(recoverySource),"CLOCK_ERROR");usb("ERR recovery clock/offset invalid; remains LOCKED\n");publish();return;}
 recoveryGapMs=plan.gap;estimatedOutageMs=plan.outage;startupWaitMs=plan.startup;bool any=false;
 for(uint8_t i=0;i<2;++i){enabled[i]=saved.armed&&saved.running[i]&&settings.config[i].mode==program::Mode::Cycle;runtime[i].manualOn=false;runtime[i].running=enabled[i];runtime[i].anchorMs=uptime;runtime[i].offsetMs=plan.offset[i];if(enabled[i]&&!program::evaluate(settings.config[i],runtime[i],uptime,true,0).finished)any=true;}
 armed=any&&logicPassed;resumeWaiting=false;recovered=true;checkpointDirty=true;
 snprintf(recoverySource,sizeof(recoverySource),"%s",remote?"NAS":"LOCAL");
 usb("RECOVERY source=%s estimated_outage_ms=%llu startup_wait_ms=%llu gap_ms=%llu rule=%s armed=%u\n",recoverySource,estimatedOutageMs,startupWaitMs,recoveryGapMs,plan.restart?"RESTART":settings.recovery.countOutage?"ADVANCE":"PAUSE",armed);
 applyOutputs();publish();eventEmit("recovery",remote?"NAS_RESTORED":"LOCAL_RESTORED",controlSnapshot(),true);
}
void recover(){
 if(!resumeWaiting||clockSource!=ClockSource::Ntp)return;
 if(nasRecoveryEnabled&&mqttView().enabled&&!nasTried&&previousBoot[0]){
  nasTried=true;nasWaiting=true;nasDeadline=monoMs()+15000;snprintf(recoveryReq,sizeof(recoveryReq),"%08lx%08lx",static_cast<unsigned long>(esp_random()),static_cast<unsigned long>(esp_random()));snprintf(recoverySource,sizeof(recoverySource),"WAIT_NAS");publish();usb("RECOVERY waiting for NAS backup (max15s); outputs LOCKED\n");return;
 }
 if(nasWaiting&&monoMs()<nasDeadline)return;
 if(nasWaiting)usb("RECOVERY NAS timeout; using local checkpoint\n");finishRecovery(journal,false);
}
__attribute__((noinline)) bool acceptRecovery(const char*payload,char*reply,size_t size){
 recovery::Reply r={};
 if(!resumeWaiting||!nasWaiting||monoMs()>=nasDeadline||clockSource!=ClockSource::Ntp){snprintf(reply,size,"ERR recovery response no longer pending");return false;}
 if(!recovery::parse(payload,r)){snprintf(reply,size,"ERR invalid recovery response");return false;}
 if(!recovery::matches(r,recoveryReq,currentBoot,previousBoot,settings.revision)){snprintf(reply,size,"ERR recovery identity/config mismatch");return false;}
 if(!recovery::usable(r,journal.epochMs,epochMs(),monoMs())){finishRecovery(journal,false);snprintf(reply,size,"OK local fallback; NAS absent/older/invalid time");return true;}
 Journal saved=journal;saved.epochMs=r.epochMs;saved.elapsed[0]=r.elapsed[0];saved.elapsed[1]=r.elapsed[1];saved.armed=r.armed;
 for(uint8_t i=0;i<2;++i)saved.running[i]=journal.running[i]&&bool(r.running&(1U<<i));
 finishRecovery(saved,true);snprintf(reply,size,"OK NAS recovery applied once");return true;
}
void status(char *b,size_t size) {
  const auto net=networkView();const auto ble=bleView();tm t={};char clock[24]="UNSYNC";
  Sensor current;portENTER_CRITICAL(&stateMux);current=sensor;portEXIT_CRITICAL(&stateMux);
  if(clockOk(t))strftime(clock,sizeof(clock),"%Y-%m-%d %H:%M:%S",&t);
  char temperature[20],humidity[20];decimal::sample(temperature,sizeof(temperature),current.t,current.valid);decimal::sample(humidity,sizeof(humidity),current.h,current.valid);
  snprintf(b,size,"STATUS firmware=Connected-2.0.7 clock=%s source=%s armed=%u limit=%u logic=%s nvs=%u\nENV %sC %s%% valid=%u\nL1 %s %s row=%u rounds=%llu left_ms=%llu\nL2 %s %s row=%u rounds=%llu left_ms=%llu\nNETWORK WiFi=%s SSID=%s ip=%s BLE=%s secure=%u\nRECOVERY enabled=%u count_outage=%u threshold_s=%lu checkpoint_s=%lu waiting=%u gap_ms=%llu",
    clock,clockSource==ClockSource::Ntp?"NTP":clockSource==ClockSource::Manual?"MANUAL":"UNSYNC",armed,MAX_ACTIVE_CHANNELS,logicPassed?"PASS":"FAIL",storageReady,
    temperature,humidity,current.valid,output[0]?"ON":"OFF",modeName(settings.config[0].mode),progress[0].row+1,progress[0].completed,progress[0].remainingMs,
    output[1]?"ON":"OFF",modeName(settings.config[1].mode),progress[1].row+1,progress[1].completed,progress[1].remainingMs,
    net.connected?"CONNECTED":"DISCONNECTED",net.ssid,net.ip,ble.connected?"CONNECTED":"READY",ble.secure,
    settings.recovery.enabled,settings.recovery.countOutage,static_cast<unsigned long>(settings.recovery.restartAfterSeconds),static_cast<unsigned long>(settings.recovery.checkpointSeconds),resumeWaiting,recoveryGapMs);
  size_t usedNAS=strlen(b);if(usedNAS<size)snprintf(b+usedNAS,size-usedNAS,"\nNAS enabled=%u waiting=%u source=%s outage_ms=%llu startup_ms=%llu",nasRecoveryEnabled,nasWaiting&&resumeWaiting,recoverySource,estimatedOutageMs,startupWaitMs);
  auto m=mqttView();auto d=eventLogView();size_t used=strlen(b);if(used<size)snprintf(b+used,size-used,"\nMQTT enabled=%u connected=%u host=%s:%u\nLOG ready=%u boot=%lu reason=%s",m.enabled,m.connected,m.host,m.port,d.ready,static_cast<unsigned long>(d.bootCount),d.resetReason);
}
__attribute__((noinline)) bool execute(char *line,char *reply,size_t size) {
  char *tokens[6],*context=nullptr;uint8_t count=0;
  for(char *p=strtok_r(line," \t",&context);p;p=strtok_r(nullptr," \t",&context)) {if(count==6){snprintf(reply,size,"ERR too many arguments");return false;}tokens[count++]=p;}
  auto fail=[&](const char *m){snprintf(reply,size,"ERR %s",m);return false;};
  auto ok=[&](const char *m){snprintf(reply,size,"OK %s",m);return true;};
  if(!count)return fail("empty command");const char *name=tokens[0];
  if(!strcmp(name,"status")&&count==1){status(reply,size);return true;}
  if(!strcmp(name,"diag")&&count==1){auto d=eventLogView();auto m=mqttView();auto n=networkView();snprintf(reply,size,"DIAG boot_id=%s reason=%s uptime_ms=%llu heap_free=%lu heap_min=%lu heap_largest=%lu controller_stack=%lu log_stack=%lu loop_stack=%lu\nLOG ready=%u pending=%u dropped=%lu write_failures=%lu boot_count=%lu power_or_external=%lu known_wdt=%lu\nMQTT enabled=%u connected=%u host=%s port=%u error=%d retained_rejected=%lu\nWEB http_stack=%lu requests=%lu command_timeouts=%lu write_failures=%lu",d.bootId,d.resetReason,monoMs(),static_cast<unsigned long>(ESP.getFreeHeap()),static_cast<unsigned long>(ESP.getMinFreeHeap()),static_cast<unsigned long>(ESP.getMaxAllocHeap()),static_cast<unsigned long>(uxTaskGetStackHighWaterMark(nullptr)),static_cast<unsigned long>(d.stackMinimum),static_cast<unsigned long>(loopTask?uxTaskGetStackHighWaterMark(loopTask):0),d.ready,d.pending,static_cast<unsigned long>(d.dropped),static_cast<unsigned long>(d.writeFailures),static_cast<unsigned long>(d.bootCount),static_cast<unsigned long>(d.powerLikeStarts),static_cast<unsigned long>(d.watchdogStarts),m.enabled,m.connected,m.host,m.port,m.lastError,static_cast<unsigned long>(m.retainedCommandsRejected),static_cast<unsigned long>(n.httpStackMinimum),static_cast<unsigned long>(n.stateRequests),static_cast<unsigned long>(n.commandTimeouts),static_cast<unsigned long>(n.responseWriteFailures));if(strlen(reply)+70<size)snprintf(reply+strlen(reply),size-strlen(reply),"\nLOG_IO stage=%s errno=%d",d.lastFailure[0]?d.lastFailure:"none",d.lastError);return true;}
  if(!strcmp(name,"mqtt")&&count==2&&(!strcmp(tokens[1],"on")||!strcmp(tokens[1],"off"))){if(armed)return fail("lock before changing MQTT");auto m=mqttView();if(!mqttConfigure(!strcmp(tokens[1],"on"),m.host,m.port,m.username,"",reply,size))return false;return ok("MQTT configuration saved; asynchronous apply");}
  if(!strcmp(name,"nasresume")&&count==2){
    if(armed)return fail("lock before changing NAS recovery");if(strcmp(tokens[1],"on")&&strcmp(tokens[1],"off"))return fail("nasresume on|off");bool on=!strcmp(tokens[1],"on");if(!storageReady||settingsPrefs.putBool("nas-resume",on)!=1)return fail("NAS recovery setting write failed");nasRecoveryEnabled=on;if(!on){nasWaiting=false;nasTried=true;}publish();return ok("NAS recovery preference saved");
  }
  if(!strcmp(name,"logs")&&count==1){eventLogPrint();return ok("recent diagnostic log requested on USB");}
  if(!strcmp(name,"logs")&&count==2&&!strcmp(tokens[1],"init")){if(armed)return fail("lock before initializing log filesystem");eventLogInitialize();return ok("log filesystem initialization requested; see LOG_STORAGE");}
  if(!strcmp(name,"disarm")&&count==1){armed=false;resumeWaiting=false;for(auto &r:runtime){r.manualOn=false;r.running=false;}applyOutputs();checkpointDirty=true;
    if(pwmSettingsDirty&&!saveSettings())return fail("LOCKED but PWM settings write failed");
    if(settings.recovery.enabled&&!checkpoint())return fail("LOCKED but recovery record write failed");publish();eventEmit("stop","LOCKED",controlSnapshot(),true);return ok("LOCKED; settings kept");}
  if(!strcmp(name,"arm")&&count==1){
    if(!logicPassed)return fail("logic self-test failed");
    if(pwmSettingsDirty&&!saveSettings())return fail("PWM settings write failed; remains LOCKED");
    tm t={};if(settings.recovery.enabled&&!clockOk(t))return fail("set clock before arming with recovery enabled");
    if(!armed){resumeWaiting=false;for(uint8_t i=0;i<2;++i){runtime[i].running=true;runtime[i].offsetMs=0;runtime[i].anchorMs=monoMs();enabled[i]=true;finishedReported[i]=false;}armed=true;
      if(settings.recovery.enabled&&!checkpoint()){armed=false;return fail("recovery record write failed; remains LOCKED");}}
    applyOutputs();return ok("ARMED; cycle starts from first row");}
  if(!strcmp(name,"off")&&count==2&&!strcmp(tokens[1],"all")){
    settingsBeforeEdit=settings;for(uint8_t i=0;i<2;++i){settings.config[i].mode=program::Mode::Manual;runtime[i].manualOn=false;runtime[i].running=false;}++settings.revision;
    applyOutputs();checkpointDirty=true;if(!saveSettings()){settings=settingsBeforeEdit;armed=false;applyOutputs();return fail("outputs locked; settings write failed");}return ok("all OFF MANUAL");}
  if(!strcmp(name,"clock")&&count==3){if(armed)return fail("lock before setting clock");if(!setClock(tokens[1],tokens[2]))return fail("invalid date/time");return ok("clock UTC+8 MANUAL");}
  if(!strcmp(name,"resume")&&count==5){
    if(armed)return fail("lock before changing recovery");uint32_t on,threshold,interval;
    if(!number(tokens[1],1,on)||!number(tokens[3],604800,threshold)||!number(tokens[4],3600,interval)||interval<10||
       (strcmp(tokens[2],"advance")&&strcmp(tokens[2],"pause")))return fail("resume 0|1 advance|pause threshold_seconds checkpoint_seconds (10..3600)");
    settingsBeforeEdit=settings;settings.recovery={bool(on),!strcmp(tokens[2],"advance"),threshold,interval};++settings.revision;
    if(!saveSettings()){settings=settingsBeforeEdit;return fail("settings write failed");}resumeWaiting=false;checkpointDirty=true;return ok("recovery policy saved");}
  if(!strcmp(name,"test")&&count==1){if(armed)return fail("lock before test");logicPassed=program::selfTest();return logicPassed?ok("LOGIC PASS"):fail("LOGIC FAIL");}
  uint32_t index;if(count<2||!number(tokens[1],2,index)||!index)return fail("unknown command or channel");uint8_t ch=index-1;
  if(!strcmp(name,"show")&&count==2){
    const auto &c=settings.config[ch];String s="CONFIG ";s+=String(index)+" daily=";
    char pair[32];for(uint8_t i=0;i<c.dailyCount;++i){snprintf(pair,sizeof(pair),"%02lu:%02lu:%02lu-%02lu:%02lu:%02lu",c.daily[i].on/3600,(c.daily[i].on/60)%60,c.daily[i].on%60,c.daily[i].off/3600,(c.daily[i].off/60)%60,c.daily[i].off%60);if(i)s+=',';s+=pair;}
    s+=" cycle=";s+=String(c.repeats)+" ";for(uint8_t i=0;i<c.stepCount;++i){char on[20],off[20];decimal::seconds(on,sizeof(on),c.steps[i].onMs);decimal::seconds(off,sizeof(off),c.steps[i].offMs);if(i)s+=',';s+=String(on)+"/"+off;}s+=" pwm=";s+=c.pwm?String(c.frequency)+"Hz "+String(c.duty)+"%":"off";
    snprintf(reply,size,"%s",s.c_str());return true;
  }
  if((!strcmp(name,"on")||!strcmp(name,"off"))&&count==2){
    bool on=!strcmp(name,"on");if(on&&!armed)return fail("locked");
    if(on&&MAX_ACTIVE_CHANNELS==1&&(output[1-ch]||progress[1-ch].requested))return fail("stop other channel first");
    settingsBeforeEdit=settings;bool changed=settings.config[ch].mode!=program::Mode::Manual;settings.config[ch].mode=program::Mode::Manual;
    runtime[ch].manualOn=on;runtime[ch].running=false;enabled[ch]=true;
    if(changed){++settings.revision;if(!saveSettings()){settings=settingsBeforeEdit;runtime[ch].manualOn=false;armed=false;applyOutputs();return fail("settings write failed; LOCKED");}}
    checkpointDirty=true;applyOutputs();return ok("MANUAL");}
  if((!strcmp(name,"pwm")&&(count==3||count==4))||(!strcmp(name,"pwmset")&&count==4)){
    auto old=settings.config[ch], proposed=old;
    if(!strcmp(name,"pwmset")){
      uint32_t value;if(!strcmp(tokens[2],"enable")){if(strcmp(tokens[3],"ON")&&strcmp(tokens[3],"OFF"))return fail("PWM enable ON|OFF");proposed.pwm=!strcmp(tokens[3],"ON");}
      else if(!strcmp(tokens[2],"duty")){if(!number(tokens[3],99,value)||!value)return fail("PWM duty1..99");proposed.duty=value;}
      else if(!strcmp(tokens[2],"frequency")){if(!number(tokens[3],20000,value)||value<40)return fail("PWM frequency40..20000");proposed.frequency=value;}
      else return fail("PWM parameter enable|duty|frequency");
    }
    else if(count==3&&!strcmp(tokens[2],"off"))proposed.pwm=false;
    else{uint32_t hz,duty;if(count!=4||!number(tokens[2],20000,hz)||hz<40||!number(tokens[3],99,duty)||!duty)return fail("pwm CHANNEL HZ(40..20000) DUTY(1..99), or pwm CHANNEL off");proposed.pwm=true;proposed.frequency=hz;proposed.duty=duty;}
    if(!storageReady)return fail("configuration storage unavailable");
    settings.config[ch]=proposed;
    bool timerOk=true;esp_err_t frequencyResult=ESP_OK;uint32_t actualFrequency=0;
    if(proposed.pwm){if(old.pwm&&pwmReady[ch]){frequencyResult=ledc_set_freq(LEDC_LOW_SPEED_MODE,static_cast<ledc_timer_t>(ch),proposed.frequency);actualFrequency=ledc_get_freq(LEDC_LOW_SPEED_MODE,static_cast<ledc_timer_t>(ch));timerOk=pwmcheck::accepted(frequencyResult,actualFrequency,proposed.frequency);}else{timerOk=configurePwm(ch);actualFrequency=ledc_get_freq(LEDC_LOW_SPEED_MODE,static_cast<ledc_timer_t>(ch));frequencyResult=timerOk?ESP_OK:ESP_FAIL;timerOk=timerOk&&pwmcheck::accepted(frequencyResult,actualFrequency,proposed.frequency);}}
    if(!timerOk){settings.config[ch]=old;if(old.pwm&&!configurePwm(ch)){armed=false;applyOutputs();}snprintf(reply,size,"ERR PWM frequency: %s (%d); requested=%lu actual=%lu",esp_err_to_name(frequencyResult),frequencyResult,static_cast<unsigned long>(proposed.frequency),static_cast<unsigned long>(actualFrequency));return false;}
    currentDuty[ch]=255;pwmSettingsDirty=true;pwmChangedAt=monoMs();applyOutputs();publish();eventEmit("pwm",ch==0?"light1":"light2",controlSnapshot(),true);return ok("PWM applied; progress kept; save after 2s");
  }
  if(armed)return fail("lock before editing program");
  auto proposed=settings.config[ch];char *rowContext=nullptr;
  if(!strcmp(name,"daily")&&count==3){
    proposed.dailyCount=0;
    for(char *row=strtok_r(tokens[2],",",&rowContext);row;row=strtok_r(nullptr,",",&rowContext)){
      char *dash=strchr(row,'-');if(!dash||proposed.dailyCount==program::MAX_ROWS)return fail("daily rows: max 16; HH:MM:SS-HH:MM:SS");*dash=0;
      auto &w=proposed.daily[proposed.dailyCount++];if(!daySecond(row,w.on)||!daySecond(dash+1,w.off))return fail("invalid daily time");
    }
    proposed.mode=program::Mode::Daily;
  }else if(!strcmp(name,"cycle")&&count==4){
    if(!number(tokens[2],program::MAX_REPEATS,proposed.repeats))return fail("repeat count 0..1000000 (0 infinite)");proposed.stepCount=0;
    for(char *row=strtok_r(tokens[3],",",&rowContext);row;row=strtok_r(nullptr,",",&rowContext)){
      char *slash=strchr(row,'/');if(!slash||proposed.stepCount==program::MAX_ROWS)return fail("cycle rows: max 16; ON/OFF in seconds");*slash=0;
      auto &s=proposed.steps[proposed.stepCount++];if(!seconds(row,s.onMs)||!seconds(slash+1,s.offMs))return fail("phase seconds 0.1..604800, one decimal place");
    }proposed.mode=program::Mode::Cycle;
  }else return fail("syntax; use status/show/daily/cycle/pwm/resume");
  if(!program::valid(proposed))return fail("invalid or overlapping rows");
  settingsBeforeEdit=settings;settings.config[ch]=proposed;++settings.revision;
  if(!configurePwm(ch)){settings=settingsBeforeEdit;configurePwm(ch);return fail("PWM timer configuration");}
  if(!saveSettings()){settings=settingsBeforeEdit;configurePwm(ch);return fail("settings write failed");}
  runtime[ch]={false,false,monoMs(),0};finishedReported[ch]=false;enabled[ch]=true;resumeWaiting=false;checkpointDirty=true;
  applyOutputs();return ok("program saved; remains LOCKED");
}
void controllerTask(void *) {
  TickType_t wake=xTaskGetTickCount();uint32_t lastPublish=0;
  for(;;){
    if(!resumeWaiting)nasWaiting=false;
    if(networkTakeTimeSync()){tm t={};time_t epoch=time(nullptr);if(localtime_r(&epoch,&t)&&t.tm_year>=124&&t.tm_year<=199){bool first=clockSource!=ClockSource::Ntp;clockSource=ClockSource::Ntp;if(first&&journal.epochMs&&epochMs()>=journal.epochMs)recoveryGapMs=epochMs()-journal.epochMs;recover();publish();if(first)eventEmit("time_sync","NTP",controlSnapshot(),true);usb("TIME SYNC NTP\n");}}
    static ControlCommand request={};static ControlReply reply={};
    if(xQueueReceive(commands,&request,0)==pdTRUE){reply={};reply.id=request.id;
      if(monoMs()>=request.expiresMs){reply.ok=false;snprintf(reply.text,sizeof(reply.text),"ERR expired; no change applied");}
      else if(request.origin==Origin::Recovery)reply.ok=acceptRecovery(request.text,reply.text,sizeof(reply.text));
      else reply.ok=execute(request.text,reply.text,sizeof(reply.text));
      applyOutputs();publish();
      if(request.origin==Origin::Web)networkAnswer(reply);else if(request.origin==Origin::Ble)bleAnswer(reply);else if(request.origin==Origin::Mqtt||request.origin==Origin::Recovery)mqttAnswer(reply);else usb("%s\n",reply.text);
      if(request.origin==Origin::Mqtt)eventEmit("command_result",reply.ok?"MQTT_OK":"MQTT_REJECTED",controlSnapshot(),true);
    }
    recover();applyOutputs();
    if(pwmSettingsDirty&&monoMs()-pwmChangedAt>=2000&&!saveSettings()){armed=false;pwmSettingsDirty=false;applyOutputs();usb("ERR PWM settings persistence failed; LOCKED\n");}
    if(checkpointDirty||(settings.recovery.enabled&&armed&&monoMs()-lastCheckpointMono>=static_cast<uint64_t>(settings.recovery.checkpointSeconds)*1000)){
      if(!resumeWaiting && (settings.recovery.enabled || checkpointDirty)){
        if(!checkpoint()){checkpointDirty=false;lastCheckpointMono=monoMs();if(settings.recovery.enabled){armed=false;applyOutputs();usb("ERR checkpoint failed; LOCKED\n");}}
      }
    }
    if(static_cast<uint32_t>(millis()-lastPublish)>=100){lastPublish=millis();publish();}
    vTaskDelayUntil(&wake,pdMS_TO_TICKS(5));
  }
}
bool submit(const char *text,Origin origin) {ControlCommand c={};c.origin=origin;c.expiresMs=monoMs()+2000;snprintf(c.text,sizeof(c.text),"%s",text);return controlEnqueue(c);}
void serviceSerial() {
  static char line[sizeof(ControlCommand::text)];static size_t used=0;static bool overflow=false;uint8_t budget=64;
  while(Serial.available()&&budget--){char c=Serial.read();if(c=='\r')continue;
    if(c=='\n'){
      line[used]=0;
      if(overflow)usb("ERR line too long\n");
      else if(!strcmp(line,"wifi info"))networkRequestAction(NetworkAction::Info);
      else if(!strcmp(line,"wifi radio"))networkRequestAction(NetworkAction::RadioInfo);
      else if(!strcmp(line,"wifi sleep off")||!strcmp(line,"wifi sleep on")){if(controlSnapshot().armed)usb("ERR lock before WiFi sleep setting\n");else if(!networkRequestAction(!strcmp(line,"wifi sleep on")?NetworkAction::SleepOn:NetworkAction::SleepOff))usb("ERR network action queue busy\n");}
      else if(!strcmp(line,"wifi key"))networkRequestAction(NetworkAction::Secrets);
      else if(!strcmp(line,"mqtt info")){auto m=mqttView();usb("MQTT enabled=%u connected=%u host=%s port=%u username=%s error=%d type=%d tls=%d errno=%d attempts=%lu outbox=%lu\nMQTT_MEMORY inflight=%lu failures=%lu deferred=%lu stack=%lu before=%lu init=%lu start=%lu connect=%lu\n",m.enabled,m.connected,m.host,m.port,m.username,m.lastError,m.errorType,m.transportError,m.socketError,static_cast<unsigned long>(m.connectionAttempts),static_cast<unsigned long>(m.outboxBytes),static_cast<unsigned long>(m.inflightId),static_cast<unsigned long>(m.publishFailures),static_cast<unsigned long>(m.memoryDeferrals),static_cast<unsigned long>(m.stackMinimum),static_cast<unsigned long>(m.heapBefore),static_cast<unsigned long>(m.heapAfterInit),static_cast<unsigned long>(m.heapAfterStart),static_cast<unsigned long>(m.heapAfterConnect));const auto life=mqttLifecycleView();const auto io=rawmqtt::failureView();usb("MQTT_LIFECYCLE creations=%lu memory_stops=%lu ack_timeout_stops=%lu last_stop=%s\nMQTT_IO failures=%lu stage=%s errno=%d fd=%d at_ms=%lu elapsed_ms=%lu requested=%lu sent=%lu rssi=%d heap=%lu largest=%lu\n",static_cast<unsigned long>(life.creations),static_cast<unsigned long>(life.memoryStops),static_cast<unsigned long>(life.ackTimeoutStops),life.lastStop,static_cast<unsigned long>(io.count),io.stage[0]?io.stage:"none",io.error,io.fd,static_cast<unsigned long>(io.atMs),static_cast<unsigned long>(io.elapsedMs),static_cast<unsigned long>(io.requested),static_cast<unsigned long>(io.sent),io.rssi,static_cast<unsigned long>(io.heap),static_cast<unsigned long>(io.largest));}
      else if(!strcmp(line,"mqtt probe")){if(controlSnapshot().armed)usb("ERR lock before network probe\n");else mqttRequestProbe();}
      else if(!strcmp(line,"wifi ap"))networkRequestAction(NetworkAction::OpenAp);
      else if(!strcmp(line,"wifi forget")){if(controlSnapshot().armed)usb("ERR lock first\n");else networkRequestAction(NetworkAction::Forget);}
      else if(!strcmp(line,"ble info")){auto b=bleView();usb("BLE name=%s passkey=%06lu ready=%u connected=%u secure=%u\n",b.name,static_cast<unsigned long>(b.passkey),b.ready,b.connected,b.secure);}
      else if(!strcmp(line,"help"))usb("status | diag | logs | logs init | show 1 | show 2 | arm | disarm | on 1 | off 1 | off all\ndaily 1 07:00:00-08:00:00,09:00:00-13:00:00\ncycle 1 3 0.5/0.3,2/1 (seconds; 0 repeats = infinite)\npwm 1 50 50 | pwm 1 20000 50 | pwm 1 off (runtime allowed)\nresume 1 advance 3600 60 | resume 1 pause 3600 60 | resume 0 advance 0 60\nnasresume on | nasresume off (lock)\npwmset 1 enable ON | pwmset 1 duty 50 | pwmset 1 frequency 1000\nwifi info | wifi radio | wifi sleep off | wifi sleep on (USB; lock; until reset) | wifi key (local secret display) | wifi ap | wifi forget | ble info | mqtt info | mqtt off | mqtt on | mqtt probe | test\n");
      else if(used&&!submit(line,Origin::Usb))usb("ERR command queue busy\n");used=0;overflow=false;
    }else if(!overflow){if(c<32||c>126||used>=sizeof(line)-1)overflow=true;else line[used++]=c;}
  }
}
void serviceButtons() {
  static bool raw[3]={true,true,true}, stable[3]={true,true,true};static uint32_t changed[3]={};
  for(uint8_t i=0;i<3;++i){bool r=digitalRead(BUTTON_PIN[i])!=LOW;if(r!=raw[i]){raw[i]=r;changed[i]=millis();}
    if(stable[i]!=r&&static_cast<uint32_t>(millis()-changed[i])>=40){stable[i]=r;if(!r){if(i==2){page=(page+1)%5;lastPage=millis();}else{char c[12];snprintf(c,sizeof(c),"%s %u",controlSnapshot().output[i]?"off":"on",i+1);submit(c,Origin::Button);}}}
  }
}
void display() {
  if(!oledReady||static_cast<uint32_t>(millis()-lastDisplay)<250)return;lastDisplay=millis();
  if(static_cast<uint32_t>(millis()-lastPage)>=6000){lastPage=millis();page=(page+1)%5;}
  const auto s=controlSnapshot();oled.clearDisplay();oled.setTextSize(1);oled.setTextColor(SSD1306_WHITE);oled.setCursor(0,0);
  if(page==0){oled.println(s.clockText[0]?s.clockText:"TIME UNSYNC");if(s.sensorValid){char t[20],h[20];decimal::sample(t,sizeof(t),s.temperature);decimal::sample(h,sizeof(h),s.humidity);oled.printf("T:%sC H:%s%%\n",t,h);}else oled.println("DHT11 invalid");
    for(uint8_t i=0;i<2;++i)oled.printf("L%u %s %s\n",i+1,s.output[i]?"ON":"OFF",modeName(s.config[i].mode));oled.println(s.armed?"ARMED":"LOCKED");oled.println(s.resumeWaiting?"WAIT NTP TO RESUME":s.clockSource==ClockSource::Ntp?"Clock: NTP":"Clock: MANUAL/UNSYNC");
  }else if(page==1||page==2){uint8_t ch=page-1;const auto &c=s.config[ch];const auto &p=s.progress[ch];oled.printf("L%u %s %s\n",ch+1,s.output[ch]?"ON":"OFF",modeName(c.mode));
    if(c.mode==program::Mode::Cycle){oled.printf("Step %u/%u\n",p.row+1,c.stepCount);char on[24],off[24],left[24];decimal::seconds(on,sizeof(on),c.steps[p.row].onMs);decimal::seconds(off,sizeof(off),c.steps[p.row].offMs);decimal::seconds(left,sizeof(left),p.remainingMs);oled.printf("ON %ss OFF %ss\n",on,off);oled.printf("Round %llu/%s\n",p.completed,c.repeats?String(c.repeats).c_str():"INF");oled.printf("Left %ss%s\n",left,p.finished?" DONE":"");}
    else if(c.mode==program::Mode::Daily){uint8_t row=(millis()/2000)%c.dailyCount;auto w=c.daily[row];oled.printf("Daily row %u/%u\n",row+1,c.dailyCount);oled.printf("ON  %02lu:%02lu:%02lu\n",w.on/3600,(w.on/60)%60,w.on%60);oled.printf("OFF %02lu:%02lu:%02lu\n",w.off/3600,(w.off/60)%60,w.off%60);}
    oled.printf("PWM:%s",c.pwm?"ON ":"OFF");if(c.pwm)oled.printf("%uHz %u%%",c.frequency,c.duty);oled.println();oled.println(s.armed?"RUN":"LOCKED");
  }else if(page==3){const auto n=networkView();const auto b=bleView();oled.println(n.connected?"WiFi:CONNECTED":"WiFi:DISCONNECTED");oled.println(n.connected?n.ip:n.apIp);oled.println("SSID:");
    const char *name=n.connected?n.ssid:n.apName;
    unicode.setFont(u8g2_font_wqy12_t_gb2312);const int16_t width=unicode.getUTF8Width(name);
    const int16_t scroll=width>128?static_cast<int16_t>(((millis()-lastPage)/60)%(width+32)):0;
    unicode.setCursor(-scroll,35);unicode.print(name);if(width>128){unicode.setCursor(width+32-scroll,35);unicode.print(name);}
    oled.setCursor(0,40);oled.printf("BLE:%s\n",b.secure?"SECURE":b.connected?"PAIRING":"READY");oled.printf("PIN:%06lu\n",static_cast<unsigned long>(b.passkey));oled.printf("MQTT:%s LIMIT:%u",mqttView().connected?"ON":"OFF",s.limit);
  }else{oled.printf("Recovery:%s\n",s.recovery.enabled?"ON":"OFF");oled.println(s.recovery.countOutage?"Outage: ADVANCE":"Outage: PAUSE");oled.printf("Restart >%lus\n",static_cast<unsigned long>(s.recovery.restartAfterSeconds));oled.printf("Save every %lus\n",static_cast<unsigned long>(s.recovery.checkpointSeconds));char gap[24];decimal::seconds(gap,sizeof(gap),s.recoveryGapMs);oled.printf("Est.gap:%ss\n",gap);oled.println(s.resumeWaiting?"Waiting for NTP":s.recovered?"Recovered":"No boot recovery");}
  oled.display();
}
}
bool controlEnqueue(const ControlCommand &c){return commands&&xQueueSend(commands,&c,0)==pdTRUE;}
ControlSnapshot controlSnapshot(){ControlSnapshot s;portENTER_CRITICAL(&stateMux);s=shared;portEXIT_CRITICAL(&stateMux);return s;}
void controlSensor(float t,float h,bool valid,bool ready){uint64_t sampled=monoMs();auto clock=controlSnapshot().clockSource;uint64_t epoch=clock!=ClockSource::Unsynced?epochMs():0;portENTER_CRITICAL(&stateMux);sensor={t,h,valid,ready,sampled,epoch,clock==ClockSource::Ntp};portEXIT_CRITICAL(&stateMux);}
void applicationSetup(){
  loopTask=xTaskGetCurrentTaskHandle();
  for(uint8_t pin:LIGHT_PIN){pinMode(pin,OUTPUT);digitalWrite(pin,LOW);}Serial.begin(115200);Serial.setTxTimeoutMs(5);delay(1000);
  setenv("TZ","CST-8",1);tzset();logicPassed=program::selfTest();loadSettings();if(!storageReady)logicPassed=false;
  for(uint8_t i=0;i<2;++i)if(!configurePwm(i))logicPassed=false;
  commands=xQueueCreate(4,sizeof(ControlCommand));publish();
  for(uint8_t pin:BUTTON_PIN)pinMode(pin,INPUT_PULLUP);
  Wire.begin(6,5,400000);Wire.setTimeOut(30);
  for(uint8_t a=0x3c;a<=0x3d;++a){Wire.beginTransmission(a);if(Wire.endTransmission()==0){oledReady=oled.begin(SSD1306_SWITCHCAPVCC,a,true,false);if(oledReady)break;}}
  if(oledReady){unicode.begin(oled);unicode.setFontMode(1);unicode.setFontDirection(0);unicode.setForegroundColor(SSD1306_WHITE);}
  if(!dht.begin())usb("ERR DHT RMT initialization; sensor remains invalid\n");controlSensor(NAN,NAN,false,oledReady);lastSensor=millis();lastPage=millis();
  if(!eventLogStart())usb("ERR diagnostic log task unavailable\n");{auto boot=eventLogView();snprintf(currentBoot,sizeof(currentBoot),"%s",boot.bootId);}if(!mqttStart())usb("ERR MQTT initialization unavailable\n");
  publish();eventEmit("boot","START",controlSnapshot(),true);
  if(!commands||xTaskCreate(controllerTask,"inc-controller",8192,nullptr,2,nullptr)!=pdPASS){logicPassed=false;usb("ERR controller unavailable; LOCKED\n");}
  if(!networkStart())usb("ERR network unavailable\n");if(!bleStart())usb("ERR BLE unavailable\n");
  auto diagnostic=eventLogView();
  usb("BOOT Connected-2.0.7 GPIO SDA6 SCL5 DHT21 L1=4 L2=7 limit=%u logic=%s reset=%s boot=%lu\nUse help, status, diag, mqtt info. First-use log storage: logs init.\n",MAX_ACTIVE_CHANNELS,logicPassed?"PASS":"FAIL",diagnostic.resetReason,static_cast<unsigned long>(diagnostic.bootCount));
}
void applicationLoop(){
  serviceSerial();serviceButtons();
  if(static_cast<uint32_t>(millis()-lastSensor)>=5000){lastSensor=millis();float h=NAN,t=NAN;bool valid=dht.read(t,h);controlSensor(valid?t:NAN,valid?h:NAN,valid,oledReady);}
  mqttService();display();delay(1);
}
