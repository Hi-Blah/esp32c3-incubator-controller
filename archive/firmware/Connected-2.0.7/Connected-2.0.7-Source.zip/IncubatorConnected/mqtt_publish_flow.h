#pragma once
#include <stdint.h>
namespace mqttflow {
enum class Kind:uint8_t{None,Discovery,Availability,State,Record,Progress,RecoveryRequest};
struct Flow {Kind kind=Kind::None;int id=0;uint64_t ordinal=0;uint32_t sentAt=0,nextAt=0,epoch=0,retryMs=500;
 constexpr bool ready(uint32_t now,uint32_t free,uint32_t largest,uint32_t outbox)const{return id==0&&static_cast<int32_t>(now-nextAt)>=0&&free>=8192&&largest>=2048&&outbox==0;}
 constexpr void accepted(int message,Kind k,uint64_t order,uint32_t now,uint32_t generation){id=message;kind=k;ordinal=order;sentAt=now;epoch=generation;retryMs=500;}
 constexpr bool acknowledged(int message)const{return id>0&&message==id;}
 constexpr void clear(){id=0;kind=Kind::None;ordinal=0;}
 constexpr void succeeded(uint32_t now){clear();nextAt=now+200;retryMs=500;}
 constexpr void failed(uint32_t now){nextAt=now+retryMs;if(retryMs<30000)retryMs=retryMs>15000?30000:retryMs*2;}
 constexpr bool expired(uint32_t now)const{return id>0&&static_cast<uint32_t>(now-sentAt)>=30000;}
};
}
