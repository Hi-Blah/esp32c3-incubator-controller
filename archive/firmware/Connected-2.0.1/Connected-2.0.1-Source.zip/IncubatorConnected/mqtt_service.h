#pragma once
#include "control_service.h"
struct MqttView {
  bool enabled, connected, credentialsSaved;
  uint16_t port;
  uint32_t retainedCommandsRejected;
  int lastError;
  char host[97], username[33], lastReply[96];
};
bool mqttStart();
void mqttService();
MqttView mqttView();
bool mqttConfigure(bool enabled,const char *host,uint16_t port,const char *username,const char *password,char *error,size_t size);
void mqttAnswer(const ControlReply &reply);
