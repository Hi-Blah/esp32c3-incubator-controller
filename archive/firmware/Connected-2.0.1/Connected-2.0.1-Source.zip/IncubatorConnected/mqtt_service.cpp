#include "mqtt_service.h"
#include "event_log.h"
#include "format_decimal.h"
#include <mqtt_client.h>
#include <Preferences.h>
#include <esp_timer.h>
#include <freertos/queue.h>
#include <atomic>
#include <math.h>
namespace {
constexpr uint32_t SCHEMA=0xC3064001;
struct Config { uint32_t schema; bool enabled; uint16_t port; char host[97],username[33],password[128]; };
Config stored={},active={};
portMUX_TYPE configMux=portMUX_INITIALIZER_UNLOCKED,viewMux=portMUX_INITIALIZER_UNLOCKED;
MqttView view={};
std::atomic<bool> changed(false),connected(false),announce(false);
esp_mqtt_client_handle_t client=nullptr;
QueueHandle_t acknowledgements=nullptr;
char suffix[7]={},base[40]={},stateTopic[64]={},availability[64]={},commandsTopic[64]={},clientId[40]={};
uint8_t discoveryIndex=0;
uint32_t nextCommand=0,lastState=0,lastEnvironment=0,lastAttempt=0;
uint64_t pendingOrdinal=0;
int pendingMessage=-1;
uint32_t pendingSince=0;
uint32_t signature=0;
bool announced=false;
// Discovery and state publishing run serially on Arduino loopTask; enqueue copies the payload.
char publishBuffer[1600]={},discoveryOptions[1000]={};
uint64_t monoMs(){return static_cast<uint64_t>(esp_timer_get_time())/1000;}
void setReply(const char *text){portENTER_CRITICAL(&viewMux);snprintf(view.lastReply,sizeof(view.lastReply),"%s",text);portEXIT_CRITICAL(&viewMux);}
bool valid(const Config &c){
  if(c.schema!=SCHEMA||!c.port||!memchr(c.host,0,sizeof(c.host))||!memchr(c.username,0,sizeof(c.username))||!memchr(c.password,0,sizeof(c.password))||!c.host[0])return false;
  for(const char *p=c.host;*p;++p)if(!isalnum(static_cast<unsigned char>(*p))&&*p!='.'&&*p!='-')return false;
  for(const char *p=c.username;*p;++p)if(static_cast<unsigned char>(*p)<32||*p==127)return false;
  return !c.enabled || (c.username[0]&&c.password[0]);
}
void incoming(esp_mqtt_event_handle_t event){
  static char topic[96]={},payload[64]={};static size_t received=0,total=0;static bool retained=false;
  if(event->current_data_offset==0){
    received=total=0;
    if(!event->topic||event->topic_len<=0||event->topic_len>=static_cast<int>(sizeof(topic))||event->total_data_len<=0||event->total_data_len>=static_cast<int>(sizeof(payload)))return;
    memcpy(topic,event->topic,event->topic_len);topic[event->topic_len]=0;total=event->total_data_len;retained=event->retain;
  }
  if(!total||event->current_data_offset!=static_cast<int>(received)||event->data_len<0||received+event->data_len>total){total=0;return;}
  memcpy(payload+received,event->data,event->data_len);received+=event->data_len;if(received!=total)return;payload[total]=0;total=0;
  if(!strcmp(topic,"homeassistant/status")){if(!strcmp(payload,"online"))announce.store(true);return;}
  const size_t baseLength=strlen(base);if(strncmp(topic,base,baseLength)||strncmp(topic+baseLength,"/command/",9))return;
  if(retained){portENTER_CRITICAL(&viewMux);++view.retainedCommandsRejected;portEXIT_CRITICAL(&viewMux);setReply("ERR retained command ignored");return;}
  if(strcmp(payload,"ON")&&strcmp(payload,"OFF")){setReply("ERR command payload must be ON or OFF");return;}
  const char *target=topic+baseLength+9;ControlCommand c={};c.origin=Origin::Mqtt;c.id=++nextCommand;c.expiresMs=monoMs()+2000;
  if(!strcmp(target,"light1")||!strcmp(target,"light2"))snprintf(c.text,sizeof(c.text),"%s %u",!strcmp(payload,"ON")?"on":"off",target[5]=='1'?1:2);
  else if(!strcmp(target,"arm"))snprintf(c.text,sizeof(c.text),"%s",!strcmp(payload,"ON")?"arm":"disarm");
  else return;
  if(!controlEnqueue(c))setReply("ERR controller queue busy");
}
void callback(void *,esp_event_base_t,int32_t id,void *data){
  auto e=static_cast<esp_mqtt_event_handle_t>(data);
  if(id==MQTT_EVENT_CONNECTED){connected.store(true);announce.store(true);portENTER_CRITICAL(&viewMux);view.lastError=0;portEXIT_CRITICAL(&viewMux);esp_mqtt_client_subscribe(client,commandsTopic,1);esp_mqtt_client_subscribe(client,"homeassistant/status",1);}
  else if(id==MQTT_EVENT_DISCONNECTED)connected.store(false);
  else if(id==MQTT_EVENT_DATA)incoming(e);
  else if(id==MQTT_EVENT_PUBLISHED){int message=e->msg_id;if(acknowledgements)xQueueSend(acknowledgements,&message,0);}
  else if(id==MQTT_EVENT_ERROR){int error=-1;if(e->error_handle)error=e->error_handle->error_type==MQTT_ERROR_TYPE_CONNECTION_REFUSED?static_cast<int>(e->error_handle->connect_return_code):e->error_handle->esp_transport_sock_errno;portENTER_CRITICAL(&viewMux);view.lastError=error;portEXIT_CRITICAL(&viewMux);}
}
int enqueue(const char *topic,const char *payload,int qos,bool retain){
  if(!client||!connected.load())return -1;
  return esp_mqtt_client_enqueue(client,topic,payload,0,qos,retain,true);
}
bool discover(unsigned index){
  const char *components[]={"light","light","sensor","sensor","switch"};
  const char *names[]={"光源1","光源2","温度","湿度","运行许可"};
  const char *objects[]={"light1","light2","temperature","humidity","arm"};
  char topic[96];auto &options=discoveryOptions;auto &payload=publishBuffer;options[0]=0;
  snprintf(topic,sizeof(topic),"homeassistant/%s/incubator_%s/%s/config",components[index],suffix,objects[index]);
  if(index<2||index==4){
    const char *field=index==4?"armed":index==0?"l1":"l2";
    snprintf(options,sizeof(options),R"JSON("command_topic":"%s/command/%s","state_topic":"%s","%s":"{{ 'ON' if value_json.%s else 'OFF' }}","payload_on":"ON","payload_off":"OFF","qos":1,"retain":false,"availability_topic":"%s","payload_available":"online","payload_not_available":"offline")JSON",base,objects[index],stateTopic,index==4?"value_template":"state_value_template",field,availability);
  }else{
    snprintf(options,sizeof(options),R"JSON("state_topic":"%s","value_template":"{{ value_json.%s }}","device_class":"%s","state_class":"measurement","unit_of_measurement":"%s","availability_mode":"all","availability":[{"topic":"%s","payload_available":"online","payload_not_available":"offline"},{"topic":"%s","value_template":"{{ 'online' if value_json.sensor_valid else 'offline' }}","payload_available":"online","payload_not_available":"offline"}])JSON",stateTopic,objects[index],objects[index],index==2?"°C":"%",availability,stateTopic);
  }
  int n=snprintf(payload,sizeof(payload),R"JSON({"name":"%s","unique_id":"incubator_%s_%s",%s,"device":{"identifiers":["incubator_%s"],"name":"光照培养箱","manufacturer":"DIY","model":"ESP32-C3 SuperMini","sw_version":"Connected-2.0.1"}})JSON",names[index],suffix,objects[index],options,suffix);
  return n>0&&static_cast<size_t>(n)<sizeof(payload)&&enqueue(topic,payload,1,true)>=0;
}
void publishState(const ControlSnapshot &s){
  auto log=eventLogView();char t[20],h[20];decimal::sample(t,sizeof(t),s.temperature,s.sensorValid);decimal::sample(h,sizeof(h),s.humidity,s.sensorValid);
  char time[32]="null";if(s.clockText[0])snprintf(time,sizeof(time),R"JSON("%s")JSON",s.clockText);
  auto &payload=publishBuffer;int n=snprintf(payload,sizeof(payload),R"JSON({"firmware":"Connected-2.0.1","boot_id":"%s","time":%s,"time_source":"%s","uptime_ms":%llu,"armed":%s,"limit":%u,"l1":%s,"l2":%s,"mode1":%u,"mode2":%u,"step1":%u,"step2":%u,"rounds1":%llu,"rounds2":%llu,"left1_ms":%llu,"left2_ms":%llu,"pwm1":%s,"pwm2":%s,"frequency1":%u,"frequency2":%u,"duty1":%u,"duty2":%u,"sensor_valid":%s,"temperature":%s,"humidity":%s,"sampled_uptime_ms":%llu,"sample_epoch_ms":%llu,"sample_time_trusted":%s,"reset_reason":"%s","boot_count":%lu,"power_or_external_count":%lu,"watchdog_count":%lu,"log_ready":%s,"pending_events":%u,"dropped_events":%lu,"log_write_failures":%lu,"last_saved_epoch_ms":%llu,"estimated_gap_ms":%llu})JSON",log.bootId,time,s.clockSource==ClockSource::Ntp?"NTP":s.clockSource==ClockSource::Manual?"MANUAL":"UNSYNC",s.uptimeMs,s.armed?"true":"false",s.limit,s.output[0]?"true":"false",s.output[1]?"true":"false",static_cast<unsigned>(s.config[0].mode),static_cast<unsigned>(s.config[1].mode),s.progress[0].row+1,s.progress[1].row+1,s.progress[0].completed,s.progress[1].completed,s.progress[0].remainingMs,s.progress[1].remainingMs,s.config[0].pwm?"true":"false",s.config[1].pwm?"true":"false",s.config[0].frequency,s.config[1].frequency,s.config[0].duty,s.config[1].duty,s.sensorValid?"true":"false",t,h,s.sampledAtMs,s.sampleEpochMs,s.sampleTimeTrusted?"true":"false",log.resetReason,static_cast<unsigned long>(log.bootCount),static_cast<unsigned long>(log.powerLikeStarts),static_cast<unsigned long>(log.watchdogStarts),log.ready?"true":"false",log.pending,static_cast<unsigned long>(log.dropped),static_cast<unsigned long>(log.writeFailures),s.checkpointEpochMs,s.recoveryGapMs);
  if(n>0&&static_cast<size_t>(n)<sizeof(payload))enqueue(stateTopic,payload,0,true);
}
void applyConfiguration(){
  if(client){if(connected.load())esp_mqtt_client_publish(client,availability,"offline",0,1,1);esp_mqtt_client_stop(client);esp_mqtt_client_destroy(client);client=nullptr;}
  connected.store(false);pendingOrdinal=0;pendingMessage=-1;announced=false;discoveryIndex=0;int ack;while(xQueueReceive(acknowledgements,&ack,0)==pdTRUE){}
  portENTER_CRITICAL(&configMux);active=stored;portEXIT_CRITICAL(&configMux);
  if(!active.enabled)return;
  esp_mqtt_client_config_t c={};c.broker.address.hostname=active.host;c.broker.address.port=active.port;c.broker.address.transport=MQTT_TRANSPORT_OVER_TCP;
  c.credentials.username=active.username;c.credentials.authentication.password=active.password;c.credentials.client_id=clientId;
  c.session.protocol_ver=MQTT_PROTOCOL_V_3_1_1;c.session.keepalive=45;c.session.last_will.topic=availability;c.session.last_will.msg="offline";c.session.last_will.qos=1;c.session.last_will.retain=1;
  c.network.timeout_ms=2000;c.network.reconnect_timeout_ms=10000;c.task.stack_size=6144;c.task.priority=1;c.buffer.size=1536;c.buffer.out_size=1536;c.outbox.limit=8192;
  client=esp_mqtt_client_init(&c);
  if(!client||esp_mqtt_client_register_event(client,static_cast<esp_mqtt_event_id_t>(ESP_EVENT_ANY_ID),callback,nullptr)!=ESP_OK||esp_mqtt_client_start(client)!=ESP_OK){connected.store(false);setReply("ERR MQTT client start failed");}
}
}
bool mqttStart(){
  acknowledgements=xQueueCreate(16,sizeof(int));if(!acknowledgements)return false;
  snprintf(suffix,sizeof(suffix),"%06lx",static_cast<unsigned long>(ESP.getEfuseMac()&0xffffff));snprintf(base,sizeof(base),"incubator/%s",suffix);snprintf(stateTopic,sizeof(stateTopic),"%s/state",base);snprintf(availability,sizeof(availability),"%s/availability",base);snprintf(commandsTopic,sizeof(commandsTopic),"%s/command/#",base);snprintf(clientId,sizeof(clientId),"incubator-%s",suffix);
  stored.schema=SCHEMA;stored.port=1883;snprintf(stored.host,sizeof(stored.host),"192.0.2.10");snprintf(stored.username,sizeof(stored.username),"incubator_device");
  Preferences p;if(p.begin("inc-mqtt",true)){Config saved={};if(p.getBytesLength("config")==sizeof(saved)&&p.getBytes("config",&saved,sizeof(saved))==sizeof(saved)&&valid(saved))stored=saved;p.end();}
  view.enabled=stored.enabled;view.port=stored.port;view.credentialsSaved=stored.password[0];snprintf(view.host,sizeof(view.host),"%s",stored.host);snprintf(view.username,sizeof(view.username),"%s",stored.username);changed.store(true);return true;
}
MqttView mqttView(){MqttView v;portENTER_CRITICAL(&viewMux);v=view;portEXIT_CRITICAL(&viewMux);v.connected=connected.load();return v;}
bool mqttConfigure(bool enabled,const char *host,uint16_t port,const char *username,const char *password,char *error,size_t size){
  Config next;portENTER_CRITICAL(&configMux);next=stored;portEXIT_CRITICAL(&configMux);
  if(!host||!username||!password||strlen(host)>=sizeof(next.host)||strlen(username)>=sizeof(next.username)||strlen(password)>=sizeof(next.password)){snprintf(error,size,"ERR MQTT field length");return false;}
  next.enabled=enabled;next.port=port;snprintf(next.host,sizeof(next.host),"%s",host);snprintf(next.username,sizeof(next.username),"%s",username);if(*password)snprintf(next.password,sizeof(next.password),"%s",password);
  if(!valid(next)){snprintf(error,size,"ERR broker host, port, username or password");return false;}
  Preferences p;bool ok=p.begin("inc-mqtt",false)&&p.putBytes("config",&next,sizeof(next))==sizeof(next);p.end();if(!ok){snprintf(error,size,"ERR MQTT config write failed");return false;}
  portENTER_CRITICAL(&configMux);stored=next;portEXIT_CRITICAL(&configMux);
  portENTER_CRITICAL(&viewMux);view.enabled=next.enabled;view.port=next.port;view.credentialsSaved=next.password[0];snprintf(view.host,sizeof(view.host),"%s",next.host);snprintf(view.username,sizeof(view.username),"%s",next.username);portEXIT_CRITICAL(&viewMux);changed.store(true);return true;
}
void mqttAnswer(const ControlReply &r){setReply(r.text);if(Serial)Serial.printf("MQTT command %s\n",r.text);}
void mqttService(){
  if(!acknowledgements)return;
  if(changed.exchange(false))applyConfiguration();
  const uint32_t now=millis();const auto s=controlSnapshot();
  // Capture history even while the broker is unreachable; transport runs independently.
  if(static_cast<uint32_t>(now-lastEnvironment)>=60000){lastEnvironment=now;eventEmit("environment","sample",s,false);}
  if(!connected.load())return;
  if(announce.exchange(false)){discoveryIndex=0;announced=false;}
  if(!announced){if(discoveryIndex<5){if(discover(discoveryIndex))++discoveryIndex;return;}publishState(controlSnapshot());if(enqueue(availability,"online",1,true)>=0)announced=true;return;}
  uint32_t current=s.output[0]|(s.output[1]<<1)|(s.armed<<2)|(s.sensorValid<<3);
  current=current*31+s.config[0].frequency+s.config[0].duty*20001UL+s.config[0].pwm;
  current=current*31+s.config[1].frequency+s.config[1].duty*20001UL+s.config[1].pwm;
  if(s.sensorValid)current=current*31+static_cast<uint32_t>((s.temperature+100)*10)+static_cast<uint32_t>(s.humidity*10);
  if(static_cast<uint32_t>(now-lastState)>=1000||current!=signature){publishState(s);lastState=now;signature=current;}
  int ack;while(xQueueReceive(acknowledgements,&ack,0)==pdTRUE)if(ack==pendingMessage&&pendingOrdinal){eventAck(pendingOrdinal);pendingMessage=-1;pendingOrdinal=0;}
  // Retry the durable record if an outbox item expired without an ACK. Event IDs enable NAS deduplication.
  if(pendingOrdinal&&static_cast<uint32_t>(now-pendingSince)>=30000){pendingMessage=-1;pendingOrdinal=0;}
  if(!pendingOrdinal&&static_cast<uint32_t>(now-lastAttempt)>=100){lastAttempt=now;EventPacket packet={};if(eventPeek(packet)){char topic[64];snprintf(topic,sizeof(topic),"%s/%s",base,strstr(packet.json,R"JSON("kind":"environment")JSON")?"telemetry":"events");int id=enqueue(topic,packet.json,1,false);if(id>=0){pendingOrdinal=packet.ordinal;pendingMessage=id;pendingSince=now;}}}
}
