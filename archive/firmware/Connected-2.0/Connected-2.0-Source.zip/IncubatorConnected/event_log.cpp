#include "event_log.h"
#include <LittleFS.h>
#include <Preferences.h>
#include <esp_system.h>
#include <esp_random.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
#include <atomic>
#include <math.h>
namespace {
constexpr uint32_t MAGIC=0xC3063001;
constexpr size_t QUEUE_SLOTS=64,HISTORY_SLOTS=32;
struct Record {uint32_t magic,crc;uint64_t ordinal;uint16_t length;uint8_t preserve;char json[1024];};
QueueHandle_t incoming=nullptr,acks=nullptr;
SemaphoreHandle_t files=nullptr;
Preferences prefs;
std::atomic<bool> initialize(false),printHistory(false);
portMUX_TYPE viewMux=portMUX_INITIALIZER_UNLOCKED;
EventLogView view={};
uint64_t orders[QUEUE_SLOTS]={},history[HISTORY_SLOTS]={},nextOrder=1;
uint32_t sequence=0;
portMUX_TYPE sequenceMux=portMUX_INITIALIZER_UNLOCKED;
uint32_t checksum(const char *p,size_t length){uint32_t v=2166136261UL;for(size_t i=0;i<length;++i)v=(v^static_cast<uint8_t>(p[i]))*16777619UL;return v;}
const char *resetName(esp_reset_reason_t r){switch(r){case ESP_RST_POWERON:return "POWER_OR_EXTERNAL";case ESP_RST_SW:return "SOFTWARE";case ESP_RST_PANIC:return "PANIC";case ESP_RST_INT_WDT:return "INTERRUPT_WDT";case ESP_RST_TASK_WDT:return "TASK_WDT";case ESP_RST_WDT:return "OTHER_WDT";case ESP_RST_BROWNOUT:return "BROWNOUT";case ESP_RST_DEEPSLEEP:return "DEEP_SLEEP";default:return "UNKNOWN";}}
void countFailure(){portENTER_CRITICAL(&viewMux);++view.writeFailures;portEXIT_CRITICAL(&viewMux);}
void countDrop(){portENTER_CRITICAL(&viewMux);++view.dropped;portEXIT_CRITICAL(&viewMux);}
void path(char *b,size_t size,bool archive,size_t index,bool temporary=false){snprintf(b,size,"/%c%02u.%s",archive?'h':'q',static_cast<unsigned>(index),temporary?"tmp":"dat");}
bool read(const char *name,Record &r){File f=LittleFS.open(name,"r");if(!f||f.size()!=sizeof(r))return false;bool ok=f.read(reinterpret_cast<uint8_t*>(&r),sizeof(r))==sizeof(r);f.close();return ok&&r.magic==MAGIC&&r.ordinal&&r.length<sizeof(r.json)&&r.json[r.length]==0&&r.crc==checksum(r.json,r.length);}
bool write(bool archive,size_t slot,Record &r){char target[16],tmp[16];path(target,sizeof(target),archive,slot);path(tmp,sizeof(tmp),archive,slot,true);File f=LittleFS.open(tmp,"w");if(!f)return false;bool ok=f.write(reinterpret_cast<const uint8_t*>(&r),sizeof(r))==sizeof(r);f.flush();f.close();if(!ok)return false;return LittleFS.rename(tmp,target);}
void scan(){nextOrder=1;memset(orders,0,sizeof(orders));memset(history,0,sizeof(history));for(unsigned group=0;group<2;++group){size_t n=group?HISTORY_SLOTS:QUEUE_SLOTS;for(size_t i=0;i<n;++i){char name[16],tmp[16];path(name,sizeof(name),group,i);path(tmp,sizeof(tmp),group,i,true);Record old={},candidate={};bool haveOld=read(name,old),haveTemp=read(tmp,candidate);if(haveTemp&&(!haveOld||candidate.ordinal>old.ordinal)){if(LittleFS.rename(tmp,name)){old=candidate;haveOld=true;}else countFailure();}if(haveOld){(group?history[i]:orders[i])=old.ordinal;if(old.ordinal>=nextOrder)nextOrder=old.ordinal+1;}}}}
void updatePending(){uint16_t n=0;for(auto v:orders)if(v)++n;portENTER_CRITICAL(&viewMux);view.pending=n;portEXIT_CRITICAL(&viewMux);}
void dump(){if(!Serial)return;for(unsigned printed=0;printed<8;++printed){uint64_t limit=UINT64_MAX;size_t selected=HISTORY_SLOTS;static uint64_t previous=0;if(printed==0)previous=UINT64_MAX;for(size_t i=0;i<HISTORY_SLOTS;++i)if(history[i]&&history[i]<previous&&(selected==HISTORY_SLOTS||history[i]>limit)){selected=i;limit=history[i];}if(selected==HISTORY_SLOTS)break;previous=limit;char name[16];path(name,sizeof(name),true,selected);Record r={};if(read(name,r)){Serial.println(r.json);}}}
void worker(void*){uint32_t savedDropped=0,savedFailures=0,lastCounterSave=millis();for(;;){
  if(initialize.exchange(false)){xSemaphoreTake(files,portMAX_DELAY);bool ready=eventLogView().ready;if(!ready){ready=LittleFS.begin(true,"/littlefs",5,"spiffs");if(ready)scan();}portENTER_CRITICAL(&viewMux);view.ready=ready;portEXIT_CRITICAL(&viewMux);updatePending();xSemaphoreGive(files);if(Serial)Serial.printf("LOG_STORAGE ready=%u\n",ready);}
  if(eventLogView().ready){
    uint64_t ack;while(xQueueReceive(acks,&ack,0)==pdTRUE){xSemaphoreTake(files,portMAX_DELAY);size_t slot=ack%QUEUE_SLOTS;if(orders[slot]==ack){char name[16];path(name,sizeof(name),false,slot);if(LittleFS.remove(name))orders[slot]=0;else countFailure();}updatePending();xSemaphoreGive(files);}
    Record r={};if(xQueueReceive(incoming,&r,pdMS_TO_TICKS(20))==pdTRUE){xSemaphoreTake(files,portMAX_DELAY);r.ordinal=nextOrder++;size_t slot=r.ordinal%QUEUE_SLOTS;if(orders[slot])countDrop();if(write(false,slot,r))orders[slot]=r.ordinal;else countFailure();if(r.preserve){size_t oldest=0;for(size_t i=1;i<HISTORY_SLOTS;++i)if(history[i]<history[oldest])oldest=i;if(write(true,oldest,r))history[oldest]=r.ordinal;else countFailure();}updatePending();xSemaphoreGive(files);}
    if(printHistory.exchange(false)){xSemaphoreTake(files,portMAX_DELAY);dump();xSemaphoreGive(files);}
  }else vTaskDelay(pdMS_TO_TICKS(100));
  if(static_cast<uint32_t>(millis()-lastCounterSave)>=60000){auto v=eventLogView();if(prefs.isKey("boot")){if(v.dropped!=savedDropped)prefs.putUInt("dropped",v.dropped);if(v.writeFailures!=savedFailures)prefs.putUInt("failures",v.writeFailures);}savedDropped=v.dropped;savedFailures=v.writeFailures;lastCounterSave=millis();}
}}
}
bool eventLogStart(){files=xSemaphoreCreateMutex();incoming=xQueueCreate(6,sizeof(Record));acks=xQueueCreate(8,sizeof(uint64_t));if(!files||!incoming||!acks)return false;
  auto reason=esp_reset_reason();bool havePrefs=prefs.begin("inc-diag",false);if(havePrefs){view.bootCount=prefs.getUInt("boot",0)+1;view.watchdogStarts=prefs.getUInt("wdt",0)+((reason==ESP_RST_INT_WDT||reason==ESP_RST_TASK_WDT||reason==ESP_RST_WDT)?1:0);view.powerLikeStarts=prefs.getUInt("power",0)+(reason==ESP_RST_POWERON?1:0);view.dropped=prefs.getUInt("dropped",0);view.writeFailures=prefs.getUInt("failures",0);prefs.putUInt("boot",view.bootCount);prefs.putUInt("wdt",view.watchdogStarts);prefs.putUInt("power",view.powerLikeStarts);}
  snprintf(view.bootId,sizeof(view.bootId),"%06lx-%lu-%08lx",static_cast<unsigned long>(ESP.getEfuseMac()&0xffffff),static_cast<unsigned long>(view.bootCount),static_cast<unsigned long>(esp_random()));snprintf(view.resetReason,sizeof(view.resetReason),"%s",resetName(reason));
  view.ready=LittleFS.begin(false,"/littlefs",5,"spiffs");if(view.ready){scan();updatePending();}
  return xTaskCreate(worker,"inc-log",4096,nullptr,1,nullptr)==pdPASS;
}
void eventEmit(const char *kind,const char *detail,const ControlSnapshot &s,bool preserve){if(!incoming)return;Record r={};r.magic=MAGIC;r.preserve=preserve;auto v=eventLogView();uint32_t id;portENTER_CRITICAL(&sequenceMux);id=++sequence;portEXIT_CRITICAL(&sequenceMux);
  char t[20]="null",h[20]="null";if(s.sensorValid){snprintf(t,sizeof(t),"%.1f",s.temperature);snprintf(h,sizeof(h),"%.1f",s.humidity);}char epoch[32]="null";if(s.clockSource!=ClockSource::Unsynced&&s.clockText[0])snprintf(epoch,sizeof(epoch),R"JSON("%s")JSON",s.clockText);
  int n=snprintf(r.json,sizeof(r.json),R"JSON({"event_id":"%s-%lu","boot_id":"%s","kind":"%s","detail":"%s","time":%s,"time_trusted":%s,"uptime_ms":%llu,"reset_reason":"%s","boot_count":%lu,"power_or_external_count":%lu,"watchdog_count":%lu,"last_saved_epoch_ms":%llu,"estimated_gap_ms":%llu,"armed":%s,"l1":%s,"l2":%s,"elapsed1_ms":%llu,"elapsed2_ms":%llu,"sensor_valid":%s,"temperature":%s,"humidity":%s,"sample_epoch_ms":%llu,"sample_time_trusted":%s,"recovery_enabled":%s,"count_outage":%s,"restart_after_s":%lu,"checkpoint_s":%lu,"frequency1":%u,"frequency2":%u,"duty1":%u,"duty2":%u,"pwm1":%s,"pwm2":%s})JSON",v.bootId,static_cast<unsigned long>(id),v.bootId,kind,detail?detail:"",epoch,s.clockSource==ClockSource::Ntp?"true":"false",s.uptimeMs,v.resetReason,static_cast<unsigned long>(v.bootCount),static_cast<unsigned long>(v.powerLikeStarts),static_cast<unsigned long>(v.watchdogStarts),s.checkpointEpochMs,s.recoveryGapMs,s.armed?"true":"false",s.output[0]?"true":"false",s.output[1]?"true":"false",s.progress[0].elapsedMs,s.progress[1].elapsedMs,s.sensorValid?"true":"false",t,h,s.sampleEpochMs,s.sampleTimeTrusted?"true":"false",s.recovery.enabled?"true":"false",s.recovery.countOutage?"true":"false",static_cast<unsigned long>(s.recovery.restartAfterSeconds),static_cast<unsigned long>(s.recovery.checkpointSeconds),s.config[0].frequency,s.config[1].frequency,s.config[0].duty,s.config[1].duty,s.config[0].pwm?"true":"false",s.config[1].pwm?"true":"false");
  if(n<0||static_cast<size_t>(n)>=sizeof(r.json)){countDrop();return;}r.length=n;r.crc=checksum(r.json,r.length);if(xQueueSend(incoming,&r,0)!=pdTRUE)countDrop();
}
EventLogView eventLogView(){EventLogView v;portENTER_CRITICAL(&viewMux);v=view;portEXIT_CRITICAL(&viewMux);return v;}
bool eventPeek(EventPacket &packet){if(!files||!eventLogView().ready||xSemaphoreTake(files,0)!=pdTRUE)return false;size_t selected=QUEUE_SLOTS;for(size_t i=0;i<QUEUE_SLOTS;++i)if(orders[i]&&(selected==QUEUE_SLOTS||orders[i]<orders[selected]))selected=i;bool ok=false;if(selected<QUEUE_SLOTS){char name[16];path(name,sizeof(name),false,selected);Record r={};if(read(name,r)){packet.ordinal=r.ordinal;memcpy(packet.json,r.json,sizeof(packet.json));ok=true;}else{orders[selected]=0;countFailure();updatePending();}}xSemaphoreGive(files);return ok;}
void eventAck(uint64_t ordinal){if(acks)xQueueSend(acks,&ordinal,0);}
void eventLogInitialize(){initialize.store(true);}
void eventLogPrint(){printHistory.store(true);}
