#pragma once
#include <stdint.h>

namespace incubator {
enum class Mode : uint8_t { Manual = 0, Daily = 1, Cycle = 2 };
constexpr uint32_t MAX_PHASE_SECONDS = 7UL * 24UL * 3600UL;

struct Config {
  Mode mode;
  uint16_t onMinute;
  uint16_t offMinute;
  uint32_t onSeconds;
  uint32_t offSeconds;
};
struct Runtime {
  bool manualOn;
  uint64_t cycleAnchorMs;
};

inline bool valid(const Config &c) {
  return static_cast<uint8_t>(c.mode) <= 2 && c.onMinute < 1440 &&
         c.offMinute < 1440 && c.onMinute != c.offMinute &&
         c.onSeconds >= 1 && c.onSeconds <= MAX_PHASE_SECONDS &&
         c.offSeconds >= 1 && c.offSeconds <= MAX_PHASE_SECONDS;
}

inline bool dailyOn(uint16_t nowMinute, uint16_t start, uint16_t stop) {
  if (nowMinute >= 1440 || start >= 1440 || stop >= 1440 || start == stop)
    return false;
  if (start < stop) return nowMinute >= start && nowMinute < stop;
  return nowMinute >= start || nowMinute < stop;
}

inline bool requested(const Config &c, const Runtime &r, uint64_t nowMs,
                      bool clockValid, uint16_t nowMinute) {
  if (!valid(c)) return false;
  if (c.mode == Mode::Manual) return r.manualOn;
  if (c.mode == Mode::Daily)
    return clockValid && dailyOn(nowMinute, c.onMinute, c.offMinute);
  if (nowMs < r.cycleAnchorMs) return false;
  const uint64_t onMs = static_cast<uint64_t>(c.onSeconds) * 1000ULL;
  const uint64_t period = onMs + static_cast<uint64_t>(c.offSeconds) * 1000ULL;
  return (nowMs - r.cycleAnchorMs) % period < onMs;
}

inline uint32_t remainingSeconds(const Config &c, const Runtime &r,
                                 uint64_t nowMs) {
  if (!valid(c) || c.mode != Mode::Cycle || nowMs < r.cycleAnchorMs) return 0;
  const uint64_t onMs = static_cast<uint64_t>(c.onSeconds) * 1000ULL;
  const uint64_t period = onMs + static_cast<uint64_t>(c.offSeconds) * 1000ULL;
  const uint64_t phase = (nowMs - r.cycleAnchorMs) % period;
  const uint64_t left = phase < onMs ? onMs - phase : period - phase;
  return static_cast<uint32_t>((left + 999ULL) / 1000ULL);
}

// Keep a running requested channel first; new ties prefer channel 1.
// Hardware writes must turn old outputs OFF before new outputs turn ON.
inline void limitedOutputs(const bool want[2], const bool previous[2],
                           bool armed, uint8_t limit, bool out[2]) {
  out[0] = false; out[1] = false;
  if (!armed) return;
  uint8_t count = 0;
  for (uint8_t i = 0; i < 2 && count < limit; ++i)
    if (want[i] && previous[i]) { out[i] = true; ++count; }
  for (uint8_t i = 0; i < 2 && count < limit; ++i)
    if (want[i] && !out[i]) { out[i] = true; ++count; }
}

// Run on the ESP32 before allowing any output to be armed.
inline bool selfTest() {
  for (uint16_t m = 0; m < 1440; ++m) {
    if (dailyOn(m, 480, 1200) != (m >= 480 && m < 1200)) return false;
    if (dailyOn(m, 1200, 480) != (m >= 1200 || m < 480)) return false;
    if (dailyOn(m, 480, 480)) return false;
  }
  Config c = {Mode::Daily, 480, 1200, 5, 3};
  Runtime r = {false, 1000};
  if (requested(c, r, 1000, false, 600)) return false;
  c.mode = Mode::Cycle;
  if (requested(c, r, 999, false, 0)) return false;
  if (!requested(c, r, 1000, false, 0)) return false;
  if (!requested(c, r, 5999, false, 0)) return false;
  if (requested(c, r, 6000, false, 0)) return false;
  if (requested(c, r, 8999, false, 0)) return false;
  if (!requested(c, r, 9000, false, 0)) return false;
  if (remainingSeconds(c, r, 5999) != 1) return false;
  if (remainingSeconds(c, r, 6000) != 3) return false;
  r.cycleAnchorMs = 4294967290ULL;
  if (requested(c, r, r.cycleAnchorMs + 5000ULL, false, 0)) return false;
  if (!requested(c, r, r.cycleAnchorMs + 8000ULL, false, 0)) return false;
  c.onSeconds = 0;
  if (valid(c) || requested(c, r, r.cycleAnchorMs, false, 0)) return false;
  for (uint8_t mask = 0; mask < 4; ++mask) {
    for (uint8_t oldMask = 0; oldMask < 4; ++oldMask) {
      const bool want[2] = {bool(mask & 1), bool(mask & 2)};
      const bool previous[2] = {bool(oldMask & 1), bool(oldMask & 2)};
      bool out[2];
      limitedOutputs(want, previous, false, 2, out);
      if (out[0] || out[1]) return false;
      limitedOutputs(want, previous, true, 1, out);
      if ((out[0] && out[1]) || (out[0] && !want[0]) || (out[1] && !want[1]))
        return false;
      if (!out[0] && !out[1] && (want[0] || want[1])) return false;
      if (want[0] && want[1] && oldMask == 2 && !out[1]) return false;
      limitedOutputs(want, previous, true, 2, out);
      if (out[0] != want[0] || out[1] != want[1]) return false;
    }
  }
  return true;
}
}  // namespace incubator
