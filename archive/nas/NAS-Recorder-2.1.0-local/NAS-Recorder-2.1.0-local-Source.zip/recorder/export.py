import argparse
from record_store import Store
p=argparse.ArgumentParser(description="Export recorded sensor samples to CSV")
p.add_argument("--db",default="/records/incubator.sqlite3")
p.add_argument("--output",default="/records/temperature_humidity.csv")
a=p.parse_args()
s=Store(a.db)
try:
 s.export_samples(a.output)
 print("Exported",a.output)
finally:
 s.close()
