import json,subprocess,sys,tempfile,unittest
from pathlib import Path
class Tests(unittest.TestCase):
 def test_preserves_deployed_image_secret_paths_and_data(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'compose.local.yaml';cfg={'services':{'recorder':{'image':'my-existing-pinned-image','user':'123:456','volumes':['/existing/records:/records','/private/password:/run/secrets/mqtt_password:ro'],'networks':['original'],'environment':{'CUSTOM':'kept'}}},'networks':{'original':{'external':True}}};p.write_text(json.dumps(cfg));old=p.read_bytes();tool=Path(__file__).with_name('upgrade_compose.py')
   subprocess.run([sys.executable,str(tool),'--file',str(p),'--apply'],check=True,capture_output=True);new=json.loads(p.read_text());r=new['services']['recorder']
   self.assertEqual(r['image'],'my-existing-pinned-image');self.assertEqual(r['user'],'123:456');self.assertEqual(r['networks'],['original']);self.assertEqual(r['environment'],{'CUSTOM':'kept'});self.assertEqual(new['networks'],cfg['networks']);self.assertTrue(set(cfg['services']['recorder']['volumes']).issubset(r['volumes']));self.assertEqual(list(Path(d).glob('*.before-*'))[0].read_bytes(),old)
   subprocess.run([sys.executable,str(tool),'--file',str(p),'--apply'],check=True,capture_output=True);self.assertEqual(json.loads(p.read_text()),new)
 def test_non_json_yaml_fails_without_change(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'compose.local.yaml';p.write_text('services:\n  recorder:\n    image: my-image\n');before=p.read_bytes();r=subprocess.run([sys.executable,str(Path(__file__).with_name('upgrade_compose.py')),'--file',str(p),'--apply'],capture_output=True);self.assertNotEqual(r.returncode,0);self.assertEqual(p.read_bytes(),before)
