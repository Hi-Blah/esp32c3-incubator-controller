"""Add NAS-analysis mounts/port while preserving the current local image, secrets and paths."""
import argparse,json,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');p.add_argument('--file',default='compose.local.yaml');args=p.parse_args();path=Path(args.file)
try:cfg=json.loads(path.read_text(encoding='utf-8-sig'))
except json.JSONDecodeError:raise SystemExit('Existing file is YAML rather than JSON: merge mounts/port from template manually; no file changed.')
r=cfg['services']['recorder'];old_image=r.get('image');vol=r.setdefault('volumes',[])
for name in ('nas_analysis.py','analysis_transport.py','dashboard.py','dashboard.html','test_nas_analysis.py','test_dashboard.py','test_analysis_transport.py','device_gateway.py','device.html','test_device_gateway.py'):
 dest='/app/'+name
 if not any(isinstance(v,str) and v.split(':')[1:2]==[dest] for v in vol):vol.append('./'+name+':'+dest+':ro')
ports=r.setdefault('ports',[])
if not any(isinstance(v,str) and v.rsplit(':',1)[-1].split('/')[0]=='8080' for v in ports):ports.append(chr(36)+'{RECORDER_DASHBOARD_PORT:-8790}:8080')
assert r.get('image')==old_image
if args.apply:
 backup=path.with_name(path.name+'.before-2.2.2-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(time.time_ns()));backup.write_bytes(path.read_bytes());target=path.with_name(path.name+'.pending');target.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n',encoding='utf8');target.replace(path);print('Updated mounts and port; image/secrets/record paths preserved. Backup:',backup.name)
else:print(json.dumps(cfg,ensure_ascii=False,indent=2))
