"""Optional SMTP dispatcher. SMTP settings/password remain local; no NAS private API."""
import argparse
import json
import logging
import smtplib
import sqlite3
import ssl
import time
from email.message import EmailMessage
from pathlib import Path

logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s")
def configuration(path):
    c=json.loads(Path(path).read_text(encoding="utf-8"))
    if type(c.get("enabled")) is not bool:
        raise ValueError("enabled must be boolean")
    if not c["enabled"]:
        return c
    if c.get("security") not in ("ssl","starttls"):
        raise ValueError("security must be ssl or starttls")
    if type(c.get("port")) is not int or not 1<=c["port"]<=65535:
        raise ValueError("SMTP port")
    for k in ("host","from","to","username","password_file"):
        if not isinstance(c.get(k),str) or not c[k] or any(x in c[k] for x in "\r\n"):
            raise ValueError("missing or invalid SMTP field")
    if "@" not in c["from"] or "@" not in c["to"]:
        raise ValueError("email address")
    return c

def send(c, subject, body):
    password=Path(c["password_file"]).read_text(encoding="utf-8").rstrip("\r\n")
    if not password or "\n" in password or "\r" in password:
        raise ValueError("password must be one line")
    m=EmailMessage();m["From"]=c["from"];m["To"]=c["to"]
    m["Subject"]=subject;m.set_content(body+"\n\n来自NAS培养箱记录服务。")
    context=ssl.create_default_context()
    connection=smtplib.SMTP_SSL if c["security"]=="ssl" else smtplib.SMTP
    kwargs={"host":c["host"],"port":c["port"],"timeout":15}
    if c["security"]=="ssl":
        kwargs["context"]=context
    with connection(**kwargs) as smtp:
        if c["security"]=="starttls":
            smtp.ehlo();smtp.starttls(context=context);smtp.ehlo()
        smtp.login(c["username"],password)
        smtp.send_message(m)

def dispatch(db,c,now,deliver=send):
    if not c["enabled"]:
        return False
    row=db.execute("SELECT id,category,channel,subject,body,attempts,created_ms FROM notifications WHERE status='pending' AND due_ms<=? ORDER BY due_ms,id LIMIT1".replace("LIMIT1","LIMIT 1"),(now,)).fetchone()
    if not row:
        return False
    number,category,ch,subject,body,attempts,created=row
    from datetime import datetime,timezone,timedelta
    stamp=datetime.fromtimestamp(created/1000,timezone(timedelta(hours=8))).isoformat(timespec="seconds")
    body="观测时间（UTC+8）："+stamp+"\n"+body
    key=category+":"+str(ch)
    prior=db.execute("SELECT sent_ms FROM notification_cooldown WHERE key=?",(key,)).fetchone()
    cooldown=int(c.get("cooldown_seconds",600))*1000
    if prior and now-prior[0]<cooldown:
        with db:
            db.execute("UPDATE notifications SET status='suppressed',last_error='cooldown' WHERE id=?",(number,))
        return True
    try:
        deliver(c,subject,body)
    except (OSError,smtplib.SMTPException,ValueError) as exc:
        count=attempts+1
        with db:
            db.execute("UPDATE notifications SET status=?,attempts=?,due_ms=?,last_error=? WHERE id=?",
                       ("failed" if count>=12 else "pending",count,now+min(3600000,60000*2**min(count,6)),type(exc).__name__,number))
        logging.warning("Notification %s retry/failed (%s)",number,type(exc).__name__)
        return True
    with db:
        db.execute("UPDATE notifications SET status='sent',attempts=?,sent_ms=?,last_error=NULL WHERE id=?",(attempts+1,now,number))
        db.execute("INSERT INTO notification_cooldown VALUES(?,?) ON CONFLICT(key) DO UPDATE SET sent_ms=excluded.sent_ms",(key,now))
    logging.info("Notification %s sent",number)
    return True

def main():
    p=argparse.ArgumentParser();p.add_argument("--config",default="/app/smtp.json")
    p.add_argument("--db",default="/records/incubator.sqlite3");p.add_argument("--once",action="store_true")
    a=p.parse_args();c=configuration(a.config)
    if not c["enabled"]:
        logging.info("SMTP disabled; notifications remain stored locally")
        return
    if not Path(a.db).is_file():
        raise RuntimeError("Start the updated recorder first")
    db=sqlite3.connect(a.db,timeout=3)
    try:
        while True:
            dispatch(db,c,time.time_ns()//1000000)
            if a.once: break
            time.sleep(5)
    finally:
        db.close()
if __name__=="__main__":main()
