import unittest
import test_optical_store as helpers
import notifier, optical_store
class Tests(unittest.TestCase):
 setUp=helpers.Tests.setUp
 tearDown=helpers.Tests.tearDown
 def deliver(self,*args):self.sent+=1
 def make(self):
  self.sent=0;optical_store.enqueue(self.s.db,"a","photo",1,100,"fault","test");self.s.db.commit()
 def test_disabled_no_send(self):
  self.make();self.assertFalse(notifier.dispatch(self.s.db,{"enabled":False},200,self.deliver));self.assertEqual(self.sent,0)
 def test_dispatch(self):
  self.make();self.assertTrue(notifier.dispatch(self.s.db,{"enabled":True},200,self.deliver));self.assertEqual(self.sent,1);self.assertEqual(self.s.db.execute("SELECT status FROM notifications").fetchone()[0],"sent")
 def test_failure_retry(self):
  self.make()
  def fail(*args):raise OSError("sensitive error")
  notifier.dispatch(self.s.db,{"enabled":True},200,fail);r=self.s.db.execute("SELECT status,attempts,last_error FROM notifications").fetchone();self.assertEqual(r,("pending",1,"OSError"));self.assertFalse(notifier.dispatch(self.s.db,{"enabled":True},201,self.deliver))
 def test_cooldown(self):
  self.make();notifier.dispatch(self.s.db,{"enabled":True},200,self.deliver);optical_store.enqueue(self.s.db,"b","photo",1,300,"fault","test");notifier.dispatch(self.s.db,{"enabled":True},300,self.deliver);self.assertEqual(self.sent,1)
if __name__=="__main__":unittest.main()
